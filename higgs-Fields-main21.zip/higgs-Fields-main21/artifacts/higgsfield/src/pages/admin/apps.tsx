import { useState, useRef, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from "@/components/ui/sheet";
import {
  Loader2,
  Upload,
  Link2,
  X,
  Search,
  Sparkles,
  Wand2,
  Image as ImageIcon,
  Video,
  Music,
  CheckCircle2,
  AlertCircle,
  Pencil,
  Eye,
  Sliders,
  Layers,
  Cpu,
  RefreshCw,
} from "lucide-react";
import {
  useListAdminFeatureApps,
  usePatchAdminFeatureApp,
  useListAdminModels,
  useRequestUploadUrl,
  type AdminFeatureApp,
  type AdminModel,
} from "@workspace/api-client-react";
import { toast } from "@/hooks/use-toast";
import { AdminShell } from "./shell";

const PAGE_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

// ── Icon resolver ─────────────────────────────────────────────────────────────
const ICON_MAP: Record<string, typeof Sparkles> = {
  Sparkles,
  Wand2,
  Image: ImageIcon,
  Video,
  Music,
  Eye,
  Sliders,
  Layers,
  Cpu,
  RefreshCw,
};

function renderAppIcon(key: string, className = "w-5 h-5") {
  const IconComponent = ICON_MAP[key] || Sparkles;
  return <IconComponent className={className} />;
}

// ── Category badge color ──────────────────────────────────────────────────────
function categoryBadge(cat?: string | null) {
  if (cat === "image") return "bg-violet-500/15 text-violet-400 border-violet-500/30";
  if (cat === "video") return "bg-blue-500/15 text-blue-400 border-blue-500/30";
  if (cat === "audio") return "bg-emerald-500/15 text-emerald-400 border-emerald-500/30";
  return "bg-white/[0.06] text-white/40 border-white/10";
}

// ── Ready Helper ──────────────────────────────────────────────────────────────
function getReadyStatus(app: AdminFeatureApp) {
  const hasModel = app.modelId !== null && app.modelId !== undefined;
  const hasCost = app.creditCost !== null && app.creditCost !== undefined;
  const isReady = hasModel && hasCost;

  let reason = "";
  if (!hasModel && !hasCost) {
    reason = "Missing model & credit cost";
  } else if (!hasModel) {
    reason = "Missing model";
  } else if (!hasCost) {
    reason = "Missing credit cost";
  }

  return { isReady, reason };
}

// ── Image Asset Upload / Paste Component ──────────────────────────────────────
function ImageUploadField({
  label,
  description,
  value,
  onChange,
}: {
  label: string;
  description?: string;
  value: string | null;
  onChange: (url: string | null) => void;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteUrl, setPasteUrl] = useState("");
  const requestUploadUrl = useRequestUploadUrl();

  async function handleFile(file: File) {
    setUploading(true);
    try {
      const res = await requestUploadUrl.mutateAsync({
        data: { name: file.name, size: file.size, contentType: file.type },
      });
      const put = await fetch(res.uploadURL, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type },
      });
      if (!put.ok) throw new Error(`Upload failed: ${put.status}`);
      const uploadedPath = `/api/storage${res.objectPath}`;
      onChange(uploadedPath);
      toast({ title: `${label} uploaded` });
    } catch (err) {
      toast({
        title: "Upload failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  }

  function handleSaveUrl() {
    if (!pasteUrl.trim()) return;
    onChange(pasteUrl.trim());
    setPasteUrl("");
    setPasteMode(false);
    toast({ title: `${label} URL updated` });
  }

  const previewSrc = value
    ? value.startsWith("/api/storage")
      ? `${PAGE_BASE}${value}`
      : value
    : null;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div>
          <Label className="text-xs font-semibold text-white/70 uppercase tracking-wider">
            {label}
          </Label>
          {description && <p className="text-xs text-white/40 mt-0.5">{description}</p>}
        </div>
        {value && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => onChange(null)}
            className="h-7 text-xs text-red-400 hover:text-red-300 hover:bg-red-500/10 px-2"
          >
            <X className="w-3 h-3 mr-1" />
            Remove
          </Button>
        )}
      </div>

      <div className="flex items-center gap-3">
        {previewSrc ? (
          <div className="w-16 h-16 rounded-lg border border-white/10 overflow-hidden bg-black shrink-0 relative group">
            <img src={previewSrc} alt={label} className="w-full h-full object-cover" />
          </div>
        ) : (
          <div className="w-16 h-16 rounded-lg border border-dashed border-white/15 flex items-center justify-center shrink-0 bg-white/[0.02] text-white/20">
            <ImageIcon className="w-6 h-6" />
          </div>
        )}

        <div className="flex-1 space-y-1.5 min-w-0">
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="border-white/15 text-white/80 hover:bg-white/5 h-8 text-xs"
            >
              {uploading ? (
                <Loader2 className="w-3 h-3 animate-spin mr-1.5" />
              ) : (
                <Upload className="w-3 h-3 mr-1.5" />
              )}
              Upload Image
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setPasteMode((v) => !v)}
              className={cn(
                "border-white/15 text-white/80 hover:bg-white/5 h-8 text-xs",
                pasteMode && "border-primary/50 text-primary",
              )}
            >
              <Link2 className="w-3 h-3 mr-1.5" />
              Paste URL
            </Button>
          </div>
          {value && (
            <p className="text-[11px] text-white/40 truncate max-w-sm" title={value}>
              {value}
            </p>
          )}
        </div>
      </div>

      {pasteMode && (
        <div className="flex gap-2 pt-1">
          <Input
            placeholder="https://.../image.jpg"
            value={pasteUrl}
            onChange={(e) => setPasteUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSaveUrl();
              if (e.key === "Escape") setPasteMode(false);
            }}
            className="bg-white/[0.04] border-white/10 text-white text-xs h-8"
            autoFocus
          />
          <Button
            type="button"
            size="sm"
            onClick={handleSaveUrl}
            disabled={!pasteUrl.trim()}
            className="bg-primary text-black font-semibold hover:bg-primary/90 h-8 text-xs shrink-0"
          >
            Apply
          </Button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp,image/gif"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
          e.target.value = "";
        }}
      />
    </div>
  );
}

// ── Edit Sheet Component ──────────────────────────────────────────────────────
function EditAppSheet({
  app,
  models,
  open,
  onOpenChange,
  onSaved,
}: {
  app: AdminFeatureApp | null;
  models: AdminModel[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
}) {
  const patchMutation = usePatchAdminFeatureApp();
  const [saving, setSaving] = useState(false);

  // Form State
  const [name, setName] = useState("");
  const [menuCategory, setMenuCategory] = useState<string>("none");
  const [menuDescription, setMenuDescription] = useState("");
  const [iconKey, setIconKey] = useState("Sparkles");
  const [isActive, setIsActive] = useState(true);
  const [sortOrder, setSortOrder] = useState("0");
  const [modelId, setModelId] = useState<string>("none");
  const [promptTemplate, setPromptTemplate] = useState("");
  const [freeUsesPerUser, setFreeUsesPerUser] = useState("0");
  const [creditCost, setCreditCost] = useState("");
  const [heroTitle, setHeroTitle] = useState("");
  const [heroSubtitle, setHeroSubtitle] = useState("");
  const [slot1Key, setSlot1Key] = useState("");
  const [slot1Label, setSlot1Label] = useState("");
  const [slot1Help, setSlot1Help] = useState("");
  const [slot2Key, setSlot2Key] = useState("");
  const [slot2Label, setSlot2Label] = useState("");
  const [slot2Help, setSlot2Help] = useState("");
  const [imageInputMode, setImageInputMode] = useState<"array" | "separate">("array");
  const [imageFieldName, setImageFieldName] = useState("images");
  const [showcaseImageUrl, setShowcaseImageUrl] = useState<string | null>(null);
  const [showcaseInsetUrl, setShowcaseInsetUrl] = useState<string | null>(null);
  const selectedModel = models.find((model) => String(model.id) === modelId);
  const usesRunningHub = selectedModel?.adapter === "runninghub";

  // Sync form when app changes
  const prevAppIdRef = useRef<number | null>(null);
  if (app && app.id !== prevAppIdRef.current) {
    prevAppIdRef.current = app.id;
    setName(app.name);
    setMenuCategory(app.menuCategory || "none");
    setMenuDescription(app.menuDescription || "");
    setIconKey(app.iconKey || "Sparkles");
    setIsActive(app.isActive);
    setSortOrder(String(app.sortOrder));
    setModelId(app.modelId ? String(app.modelId) : "none");
    setPromptTemplate(app.promptTemplate || "");
    setFreeUsesPerUser(String(app.freeUsesPerUser));
    setCreditCost(app.creditCost !== null && app.creditCost !== undefined ? String(app.creditCost) : "");
    setHeroTitle(app.heroTitle || "");
    setHeroSubtitle(app.heroSubtitle || "");
    setSlot1Key(app.slot1Key || "");
    setSlot1Label(app.slot1Label || "");
    setSlot1Help(app.slot1Help || "");
    setSlot2Key(app.slot2Key || "");
    setSlot2Label(app.slot2Label || "");
    setSlot2Help(app.slot2Help || "");
    setImageInputMode((app.imageInputMode as "array" | "separate") || "array");
    setImageFieldName(app.imageFieldName || "images");
    setShowcaseImageUrl(app.showcaseImageUrl ?? null);
    setShowcaseInsetUrl(app.showcaseInsetUrl ?? null);
  }

  async function handleSave() {
    if (!app) return;
    if (!name.trim()) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    if (!promptTemplate.trim()) {
      toast({ title: "Prompt template is required", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const parsedCost = creditCost.trim() === "" ? null : parseInt(creditCost.trim(), 10);
      const parsedModel = modelId === "none" ? null : parseInt(modelId, 10);
      const parsedSort = parseInt(sortOrder, 10) || 0;
      const parsedFree = parseInt(freeUsesPerUser, 10) || 0;

      await patchMutation.mutateAsync({
        id: app.id,
        data: {
          name: name.trim(),
          menuCategory: menuCategory === "none" ? null : menuCategory,
          menuDescription: menuDescription.trim(),
          iconKey: iconKey.trim() || "Sparkles",
          isActive,
          sortOrder: parsedSort,
          modelId: parsedModel,
          promptTemplate: promptTemplate.trim(),
          freeUsesPerUser: parsedFree,
          creditCost: parsedCost,
          heroTitle: heroTitle.trim(),
          heroSubtitle: heroSubtitle.trim(),
          slot1Key: slot1Key.trim() || "target_image",
          slot1Label: slot1Label.trim() || "Target Image",
          slot1Help: slot1Help.trim(),
          slot2Key: slot2Key.trim() || "swap_image",
          slot2Label: slot2Label.trim() || "Your Photo",
          slot2Help: slot2Help.trim(),
          imageInputMode,
          imageFieldName: imageFieldName.trim() || "images",
          showcaseImageUrl,
          showcaseInsetUrl,
        },
      });

      toast({ title: "Feature app saved successfully" });
      onSaved();
      onOpenChange(false);
    } catch (err) {
      toast({
        title: "Save failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  }

  if (!app) return null;

  const { isReady, reason } = getReadyStatus(app);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="w-full sm:max-w-2xl bg-[#141414] border-white/10 text-white p-0 flex flex-col h-full overflow-hidden"
      >
        <SheetHeader className="px-6 py-4 border-b border-white/10 shrink-0">
          <div className="flex items-center justify-between pr-8">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-primary/10 text-primary border border-primary/20">
                {renderAppIcon(iconKey)}
              </div>
              <div>
                <SheetTitle className="text-lg font-bold text-white flex items-center gap-2">
                  {name || "Edit App"}
                  <span className="text-xs font-normal text-white/40 font-mono">({app.slug})</span>
                </SheetTitle>
                <SheetDescription className="text-xs text-white/40">
                  Configure execution model, pricing, slots, and layout
                </SheetDescription>
              </div>
            </div>

            {isReady ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Ready
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                <AlertCircle className="w-3.5 h-3.5" />
                Not Ready
              </span>
            )}
          </div>
        </SheetHeader>

        {/* Scrollable form body */}
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
          {/* Readiness banner if not ready */}
          {!isReady && (
            <div className="p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
              <div>
                <span className="font-semibold">App is hidden from users: </span>
                {reason}. Assign an active model and credit cost below so this feature appears in the menu and can be run.
              </div>
            </div>
          )}

          {/* Section 1: General Info */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white/40 border-b border-white/[0.08] pb-1.5">
              General Information
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-white/70">App Name</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
                />
              </div>

              <div>
                <Label className="text-xs text-white/70">Slug (URL identifier)</Label>
                <Input
                  value={app.slug}
                  disabled
                  className="bg-white/[0.02] border-white/5 text-white/40 text-sm h-9 mt-1 font-mono cursor-not-allowed"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-xs text-white/70">Menu Category</Label>
                <Select value={menuCategory} onValueChange={setMenuCategory}>
                  <SelectTrigger className="bg-white/[0.04] border-white/10 text-white h-9 mt-1 text-xs">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10 text-white">
                    <SelectItem value="none">None (Hidden from Category Menus)</SelectItem>
                    <SelectItem value="image">Image</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="audio">Audio</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-xs text-white/70">Icon Key</Label>
                <Select value={iconKey} onValueChange={setIconKey}>
                  <SelectTrigger className="bg-white/[0.04] border-white/10 text-white h-9 mt-1 text-xs">
                    <div className="flex items-center gap-2">
                      {renderAppIcon(iconKey, "w-4 h-4 text-primary")}
                      <span>{iconKey}</span>
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10 text-white">
                    {Object.keys(ICON_MAP).map((k) => (
                      <SelectItem key={k} value={k}>
                        <div className="flex items-center gap-2">
                          {renderAppIcon(k, "w-3.5 h-3.5 text-primary")}
                          <span>{k}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-xs text-white/70">Sort Order</Label>
                <Input
                  type="number"
                  min="0"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value)}
                  className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
                />
              </div>
            </div>

            <div>
              <Label className="text-xs text-white/70">Menu Description</Label>
              <Input
                value={menuDescription}
                onChange={(e) => setMenuDescription(e.target.value)}
                placeholder="Short tagline shown in navigation menu dropdowns..."
                className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-white/[0.02] border border-white/[0.06]">
              <div>
                <Label className="text-xs font-semibold text-white">Active Status</Label>
                <p className="text-xs text-white/40">When disabled, this feature app cannot be accessed or run.</p>
              </div>
              <Switch checked={isActive} onCheckedChange={setIsActive} />
            </div>
          </div>

          {/* Section 2: Model & Pricing */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white/40 border-b border-white/[0.08] pb-1.5">
              Model & Credit Pricing
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-white/70">Generation Model</Label>
                <Select value={modelId} onValueChange={setModelId}>
                  <SelectTrigger className="bg-white/[0.04] border-white/10 text-white h-9 mt-1 text-xs">
                    <SelectValue placeholder="Select Model" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10 text-white max-h-60">
                    <SelectItem value="none">
                      <span className="text-amber-400 font-medium">None (Not configured)</span>
                    </SelectItem>
                    {models
                      .filter((m) => m.isActive)
                      .map((m) => (
                        <SelectItem key={m.id} value={String(m.id)}>
                          {m.name} ({m.adapter}) · {m.modelId}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-white/35 mt-1">
                  Model executing the prompt and processing inputs.
                </p>
              </div>

              <div>
                <Label className="text-xs text-white/70">Credit Cost</Label>
                <Input
                  type="number"
                  min="0"
                  placeholder="e.g. 50 (Leave blank for not set)"
                  value={creditCost}
                  onChange={(e) => setCreditCost(e.target.value)}
                  className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
                />
                <p className="text-[11px] text-white/35 mt-1">
                  Charged per generation run. Blank = "Not ready".
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-white/70">Free Uses Per User</Label>
                <Input
                  type="number"
                  min="0"
                  value={freeUsesPerUser}
                  onChange={(e) => setFreeUsesPerUser(e.target.value)}
                  className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
                />
                <p className="text-[11px] text-white/35 mt-1">
                  Number of complimentary runs granted to each user.
                </p>
              </div>
            </div>

            <div>
              <Label className="text-xs text-white/70">Prompt Template</Label>
              <Textarea
                rows={3}
                value={promptTemplate}
                onChange={(e) => setPromptTemplate(e.target.value)}
                placeholder="The system instructions passed to the provider adapter..."
                className="bg-white/[0.04] border-white/10 text-white text-xs mt-1 font-mono"
              />
              <p className="text-[11px] text-white/35 mt-1">
                Internal prompt template. Never exposed to public endpoints.
              </p>
            </div>
          </div>

          {/* Section 3: Hero & Showcase Assets */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white/40 border-b border-white/[0.08] pb-1.5">
              Page Hero & Showcase Assets
            </h3>

            <div>
              <Label className="text-xs text-white/70">Hero Title</Label>
              <Input
                value={heroTitle}
                onChange={(e) => setHeroTitle(e.target.value)}
                placeholder="e.g. INSTANT FACE SWAP IN A SINGLE CLICK"
                className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1"
              />
            </div>

            <div>
              <Label className="text-xs text-white/70">Hero Subtitle</Label>
              <Textarea
                rows={2}
                value={heroSubtitle}
                onChange={(e) => setHeroSubtitle(e.target.value)}
                placeholder="Subtitle copy displayed below the hero title..."
                className="bg-white/[0.04] border-white/10 text-white text-xs mt-1"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
              <ImageUploadField
                label="Showcase Main Image"
                description="Result photo preview"
                value={showcaseImageUrl}
                onChange={setShowcaseImageUrl}
              />
              <ImageUploadField
                label="Showcase Inset Image"
                description="Small source thumbnail inset"
                value={showcaseInsetUrl}
                onChange={setShowcaseInsetUrl}
              />
            </div>
          </div>

          {/* Section 4: Image Input Mapping */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-white/40 border-b border-white/[0.08] pb-1.5">
              Provider Image Input Mapping
            </h3>

            {usesRunningHub && (
              <div className="rounded-lg border border-white/[0.08] bg-white/[0.02] p-4 space-y-3">
                <p className="text-xs text-white/55">Inputs are mapped in the order configured on this workflow model.</p>
                {(selectedModel.executionConfig?.inputs ?? []).map((input, index) => (
                  <div key={`${input.nodeId}-${input.fieldName}-${index}`} className="flex items-center gap-3 rounded-md bg-white/[0.03] px-3 py-2 text-xs">
                    <span className="text-white/35">{index + 1}</span>
                    <span className="text-white/80">{input.label}</span>
                    <span className="ml-auto font-mono text-white/50">{input.nodeId} · {input.fieldName}</span>
                  </div>
                ))}
              </div>
            )}

            {!usesRunningHub && <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-white/70">Image Input Mode</Label>
                <Select
                  value={imageInputMode}
                  onValueChange={(v: "array" | "separate") => setImageInputMode(v)}
                >
                  <SelectTrigger className="bg-white/[0.04] border-white/10 text-white h-9 mt-1 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10 text-white">
                    <SelectItem value="array">Array Mode (Single list of images)</SelectItem>
                    <SelectItem value="separate">Separate Fields (Distinct keys)</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-white/35 mt-1">
                  How images are formatted when passed to the provider adapter.
                </p>
              </div>

              {imageInputMode === "array" && (
                <div>
                  <Label className="text-xs text-white/70">Image Field Name</Label>
                  <Input
                    value={imageFieldName}
                    onChange={(e) => setImageFieldName(e.target.value)}
                    placeholder="e.g. images"
                    className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1 font-mono"
                  />
                  <p className="text-[11px] text-white/35 mt-1">
                    Payload key for the image array (e.g. <code>images: [target, face]</code>).
                  </p>
                </div>
              )}
            </div>}

            {/* Slot 1 */}
            <div className="p-3.5 rounded-lg bg-white/[0.02] border border-white/[0.06] space-y-3">
              <span className="text-xs font-bold text-white/80 flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px]">1</span>
                Slot 1 (Target Image)
              </span>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-[11px] text-white/60">UI Label</Label>
                  <Input
                    value={slot1Label}
                    onChange={(e) => setSlot1Label(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1"
                  />
                </div>
                <div>
                  <Label className="text-[11px] text-white/60">Help Text</Label>
                  <Input
                    value={slot1Help}
                    onChange={(e) => setSlot1Help(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1"
                  />
                </div>
                {!usesRunningHub && <div>
                  <Label className="text-[11px] text-white/60">Provider Key</Label>
                  <Input
                    value={slot1Key}
                    onChange={(e) => setSlot1Key(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1 font-mono"
                  />
                </div>}
              </div>
            </div>

            {/* Slot 2 */}
            <div className="p-3.5 rounded-lg bg-white/[0.02] border border-white/[0.06] space-y-3">
              <span className="text-xs font-bold text-white/80 flex items-center gap-1.5">
                <span className="w-5 h-5 rounded-full bg-white/10 flex items-center justify-center text-[10px]">2</span>
                Slot 2 (Face Image)
              </span>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-[11px] text-white/60">UI Label</Label>
                  <Input
                    value={slot2Label}
                    onChange={(e) => setSlot2Label(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1"
                  />
                </div>
                <div>
                  <Label className="text-[11px] text-white/60">Help Text</Label>
                  <Input
                    value={slot2Help}
                    onChange={(e) => setSlot2Help(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1"
                  />
                </div>
                {!usesRunningHub && <div>
                  <Label className="text-[11px] text-white/60">Provider Key</Label>
                  <Input
                    value={slot2Key}
                    onChange={(e) => setSlot2Key(e.target.value)}
                    className="bg-white/[0.04] border-white/10 text-white text-xs h-8 mt-1 font-mono"
                  />
                </div>}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <SheetFooter className="px-6 py-3.5 border-t border-white/10 bg-[#171717] shrink-0 flex items-center justify-between">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => onOpenChange(false)}
            className="text-white/60 hover:text-white text-xs"
          >
            Cancel
          </Button>

          <Button
            type="button"
            size="sm"
            onClick={handleSave}
            disabled={saving}
            className="bg-primary text-black font-bold hover:bg-primary/90 text-xs px-4"
          >
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : null}
            Save Changes
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}

// ── App Card Item ─────────────────────────────────────────────────────────────
function FeatureAppCard({
  app,
  models,
  onEdit,
  onRefresh,
}: {
  app: AdminFeatureApp;
  models: AdminModel[];
  onEdit: () => void;
  onRefresh: () => void;
}) {
  const patchMutation = usePatchAdminFeatureApp();
  const [toggling, setToggling] = useState(false);

  const model = models.find((m) => m.id === app.modelId);
  const { isReady, reason } = getReadyStatus(app);

  async function handleToggleActive(checked: boolean) {
    setToggling(true);
    try {
      await patchMutation.mutateAsync({
        id: app.id,
        data: { isActive: checked },
      });
      toast({
        title: checked ? `"${app.name}" enabled` : `"${app.name}" disabled`,
      });
      onRefresh();
    } catch (err) {
      toast({
        title: "Update failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setToggling(false);
    }
  }

  return (
    <div className="bg-[#141414] border border-white/[0.08] hover:border-white/15 rounded-xl transition-all p-4.5 space-y-4">
      <div className="flex items-start justify-between gap-4">
        {/* Left: Icon & Names */}
        <div className="flex items-center gap-3.5 min-w-0">
          <div className="w-11 h-11 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-primary shrink-0 shadow-inner">
            {renderAppIcon(app.iconKey, "w-5 h-5")}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-bold text-white truncate">{app.name}</h2>
              <span className="text-xs font-mono text-white/40">/apps/{app.slug}</span>
              <span
                className={cn(
                  "text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider border",
                  categoryBadge(app.menuCategory),
                )}
              >
                {app.menuCategory || "None"}
              </span>
            </div>

            <p className="text-xs text-white/45 mt-0.5 line-clamp-1">
              {app.menuDescription || app.heroSubtitle || "No description provided."}
            </p>
          </div>
        </div>

        {/* Right: Status & Actions */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Readiness badge */}
          {isReady ? (
            <span
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
              title="Configured with model and credit cost. Visible on site."
            >
              <CheckCircle2 className="w-3 h-3" />
              Ready
            </span>
          ) : (
            <span
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-500/15 text-amber-400 border border-amber-500/30 cursor-help"
              title={reason}
            >
              <AlertCircle className="w-3 h-3" />
              Not Ready
            </span>
          )}

          {/* Active Switch */}
          <div className="flex items-center gap-2 pl-2 border-l border-white/10">
            <Switch
              checked={app.isActive}
              disabled={toggling}
              onCheckedChange={handleToggleActive}
              aria-label="Toggle active status"
            />
          </div>

          {/* Edit Button */}
          <Button
            size="sm"
            variant="outline"
            onClick={onEdit}
            className="border-white/15 text-white/80 hover:text-white hover:bg-white/5 h-8 text-xs font-medium gap-1.5"
          >
            <Pencil className="w-3 h-3 text-primary" />
            Edit
          </Button>
        </div>
      </div>

      {/* Not Ready Explanation banner */}
      {!isReady && (
        <div className="p-2.5 rounded-lg bg-amber-500/[0.08] border border-amber-500/20 text-amber-300/90 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>
              <strong>Not appearing on website: </strong>
              {reason}.
            </span>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={onEdit}
            className="h-6 text-xs text-amber-300 hover:text-amber-200 hover:bg-amber-500/20 px-2"
          >
            Configure Now
          </Button>
        </div>
      )}

      {/* Metadata Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1 text-xs border-t border-white/[0.06]">
        <div>
          <span className="text-white/40 block text-[11px]">Execution Model</span>
          <span className={cn("font-medium", model ? "text-white/80" : "text-amber-400")}>
            {model ? `${model.name} (${model.adapter})` : "None"}
          </span>
        </div>

        <div>
          <span className="text-white/40 block text-[11px]">Credit Cost</span>
          <span className={cn("font-medium", app.creditCost !== null && app.creditCost !== undefined ? "text-white/80" : "text-amber-400")}>
            {app.creditCost !== null && app.creditCost !== undefined ? `${app.creditCost} credits` : "Not set"}
          </span>
        </div>

        <div>
          <span className="text-white/40 block text-[11px]">Free Uses</span>
          <span className="font-medium text-white/80">
            {app.freeUsesPerUser > 0 ? `${app.freeUsesPerUser} free / user` : "0 (Paid only)"}
          </span>
        </div>

        <div>
          <span className="text-white/40 block text-[11px]">Input Mode</span>
          <span className="font-mono text-white/80">
            {app.imageInputMode === "separate" ? "Separate keys" : `Array (${app.imageFieldName})`}
          </span>
        </div>
      </div>
    </div>
  );
}

// ── Admin Apps Page ───────────────────────────────────────────────────────────
export default function AdminApps() {
  const {
    data: apps = [],
    isLoading: appsLoading,
    error: appsError,
    refetch: refetchApps,
  } = useListAdminFeatureApps();

  const {
    data: models = [],
    isLoading: modelsLoading,
    refetch: refetchModels,
  } = useListAdminModels();

  const [search, setSearch] = useState("");
  const [selectedApp, setSelectedApp] = useState<AdminFeatureApp | null>(null);
  const [editSheetOpen, setEditSheetOpen] = useState(false);

  function handleOpenEdit(app: AdminFeatureApp) {
    setSelectedApp(app);
    setEditSheetOpen(true);
  }

  function handleRefresh() {
    refetchApps();
    refetchModels();
  }

  const filteredApps = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return apps;
    return apps.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.slug.toLowerCase().includes(q) ||
        (a.menuDescription && a.menuDescription.toLowerCase().includes(q)),
    );
  }, [apps, search]);

  const readyCount = apps.filter((a) => a.modelId !== null && a.creditCost !== null).length;

  return (
    <AdminShell>
      <div className="p-6 max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Feature Apps
            </h1>
            <p className="text-sm text-white/40 mt-0.5">
              {appsLoading
                ? "Loading apps..."
                : `${apps.length} application${apps.length !== 1 ? "s" : ""} · ${readyCount} ready for production`}
            </p>
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="text-white/40 hover:text-white h-8 text-xs gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </Button>
        </div>

        {/* Toolbar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/25 pointer-events-none" />
          <Input
            placeholder="Search apps by name, slug, or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 focus-visible:border-white/20"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Loading state */}
        {appsLoading && (
          <div className="flex justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-white/30" />
          </div>
        )}

        {/* Error state */}
        {!appsLoading && appsError && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 text-sm">
            Failed to load feature apps. Please ensure the API server is running, then refresh.
          </div>
        )}

        {/* Empty search */}
        {!appsLoading && !appsError && filteredApps.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-16 text-white/25">
            <Search className="w-8 h-8" />
            <p className="text-sm">No feature apps match "{search}"</p>
          </div>
        )}

        {/* App List */}
        {!appsLoading && !appsError && filteredApps.length > 0 && (
          <div className="space-y-3">
            {filteredApps.map((app) => (
              <FeatureAppCard
                key={app.id}
                app={app}
                models={models}
                onEdit={() => handleOpenEdit(app)}
                onRefresh={refetchApps}
              />
            ))}
          </div>
        )}

        {/* Edit Sheet */}
        <EditAppSheet
          app={selectedApp}
          models={models}
          open={editSheetOpen}
          onOpenChange={setEditSheetOpen}
          onSaved={refetchApps}
        />
      </div>
    </AdminShell>
  );
}
