import { useEffect, useState } from "react";
import { Plus, ArrowUp, ArrowDown, Trash2, Workflow, Loader2, Pencil, X } from "lucide-react";
import { AdminShell } from "./shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type WorkflowInput = { nodeId: string; fieldName: string; label: string; type: string };
type WorkflowRow = {
  id: number; modelId: string; name: string; category: string; isActive: boolean;
  creditCost: number | null; basePriceUsd: number;
  executionConfig: { workflowId: string; inputs: WorkflowInput[] };
};
type FormState = {
  name: string; modelId: string; category: string; workflowId: string;
  basePriceUsd: string; creditCost: string; isActive: boolean; inputs: WorkflowInput[];
};

const emptyForm = (): FormState => ({ name: "", modelId: "", category: "", workflowId: "", basePriceUsd: "", creditCost: "", isActive: false, inputs: [] });
const API_BASE = `${import.meta.env.BASE_URL.replace(/\/$/, "")}/api/admin/workflows`;

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, { ...init, credentials: "include", headers: { "Content-Type": "application/json", ...init?.headers } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body as T;
}

function WorkflowForm({ initial, onClose, onSaved }: { initial?: WorkflowRow; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState<FormState>(() => initial ? {
    name: initial.name, modelId: initial.modelId, category: initial.category,
    workflowId: initial.executionConfig.workflowId, basePriceUsd: String(initial.basePriceUsd),
    creditCost: initial.creditCost === null ? "" : String(initial.creditCost), isActive: initial.isActive,
    inputs: (initial.executionConfig?.inputs ?? []).map((input) => ({ ...input })),
  } : emptyForm());
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function update<K extends keyof FormState>(key: K, value: FormState[K]) { setForm((current) => ({ ...current, [key]: value })); }
  function updateInput(index: number, key: keyof WorkflowInput, value: string) {
    setForm((current) => ({ ...current, inputs: current.inputs.map((input, i) => i === index ? { ...input, [key]: value } : input) }));
  }
  function moveInput(index: number, offset: number) {
    setForm((current) => {
      const target = index + offset;
      if (target < 0 || target >= current.inputs.length) return current;
      const inputs = [...current.inputs];
      [inputs[index], inputs[target]] = [inputs[target], inputs[index]];
      return { ...current, inputs };
    });
  }
  async function save(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    const { creditCost, isActive, ...workflowFields } = form;
    const parsedCreditCost = creditCost.trim() === "" ? null : Number(creditCost);
    if (initial && parsedCreditCost !== null && (!Number.isInteger(parsedCreditCost) || parsedCreditCost < 0)) {
      setError("Credit cost must be a non-negative integer.");
      return;
    }
    if (initial && isActive && parsedCreditCost === null) {
      setError("Set a credit cost before activating this workflow.");
      return;
    }
    const payload = {
      ...workflowFields,
      basePriceUsd: Number(form.basePriceUsd),
      ...(initial ? { creditCost: parsedCreditCost, isActive } : {}),
    };
    setSaving(true);
    try {
      await request<WorkflowRow>(initial ? `${API_BASE}/${encodeURIComponent(initial.modelId)}` : API_BASE, {
        method: initial ? "PATCH" : "POST", body: JSON.stringify(payload),
      });
      onSaved(); onClose();
    } catch (err) { setError(err instanceof Error ? err.message : String(err)); }
    finally { setSaving(false); }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="workflow-form-title">
      <form onSubmit={save} className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 bg-[#111] p-6 space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div><h2 id="workflow-form-title" className="text-xl font-bold">{initial ? "Edit Workflow" : "Add Workflow"}</h2><p className="text-sm text-white/50 mt-1">Configure a RunningHub workflow and the inputs users can provide.</p></div>
          <button type="button" onClick={onClose} aria-label="Close" className="text-white/50 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <label className="text-xs text-white/60 space-y-1.5">Display name<Input required value={form.name} onChange={(e) => update("name", e.target.value)} /></label>
          <label className="text-xs text-white/60 space-y-1.5">Internal slug<Input required pattern="[a-z0-9]+(?:-[a-z0-9]+)*" value={form.modelId} onChange={(e) => update("modelId", e.target.value)} /></label>
          <label className="text-xs text-white/60 space-y-1.5">Category<select required style={{ colorScheme: "dark" }} className="block w-full h-10 rounded-md bg-white/[0.04] border border-white/10 px-3 text-white" value={form.category} onChange={(e) => update("category", e.target.value)}><option style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value="" disabled>Choose category</option><option style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value="image">Image</option><option style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value="video">Video</option><option style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value="audio">Audio</option></select></label>
          <label className="text-xs text-white/60 space-y-1.5">Workflow ID<Input required value={form.workflowId} onChange={(e) => update("workflowId", e.target.value)} /></label>
          <label className="text-xs text-white/60 space-y-1.5 sm:col-span-2">Provider base price (USD)<Input required type="number" min="0" step="any" value={form.basePriceUsd} onChange={(e) => update("basePriceUsd", e.target.value)} /><span className="block text-white/35">Enter the provider cost you have verified. Platform credit pricing is configured separately.</span></label>
{initial && <label className="text-xs text-white/60 space-y-1.5">Credit Cost (credits)<Input type="number" min="0" step="1" value={form.creditCost} onChange={(event) => { setError(""); update("creditCost", event.target.value); }} /><span className="block text-white/35">Leave blank to keep this workflow unpriced.</span></label>}
{initial && <div className="flex items-center justify-between rounded-md border border-white/10 px-3 py-2"><div><p className="text-xs text-white/80">Active</p><p className="text-[11px] text-white/40">Only activate after setting a credit cost.</p></div><Switch checked={form.isActive} onCheckedChange={(checked) => { if (checked && form.creditCost.trim() === "") { setError("Set a credit cost before activating this workflow."); return; } setError(""); update("isActive", checked); }} aria-label="Activate workflow" /></div>}
        </div>
        <section className="space-y-3">
          <div className="flex items-center justify-between"><div><h3 className="font-semibold">Input mappings</h3><p className="text-xs text-white/40">Order matches the inputs shown in the generation form.</p></div><Button type="button" variant="outline" size="sm" onClick={() => update("inputs", [...form.inputs, { nodeId: "", fieldName: "", label: "", type: "" }])}><Plus className="w-4 h-4 mr-1" /> Add input</Button></div>
          {form.inputs.map((input, index) => <div key={index} className="rounded-xl border border-white/10 p-3 grid sm:grid-cols-[1fr_1fr_1fr_140px_auto] gap-2 items-end">
            <label className="text-[11px] text-white/50 space-y-1">Node ID<Input required value={input.nodeId} onChange={(e) => updateInput(index, "nodeId", e.target.value)} /></label>
            <label className="text-[11px] text-white/50 space-y-1">Field name<Input required value={input.fieldName} onChange={(e) => updateInput(index, "fieldName", e.target.value)} /></label>
            <label className="text-[11px] text-white/50 space-y-1">Label<Input required value={input.label} onChange={(e) => updateInput(index, "label", e.target.value)} /></label>
            <label className="text-[11px] text-white/50 space-y-1">Type<select required style={{ colorScheme: "dark" }} className="block w-full h-10 rounded-md bg-white/[0.04] border border-white/10 px-2 text-white" value={input.type} onChange={(e) => updateInput(index, "type", e.target.value)}><option style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value="" disabled>Choose type</option>{["prompt", "image", "video", "audio", "text", "textarea", "number", "toggle"].map((type) => <option key={type} style={{ backgroundColor: "#171717", color: "#f5f5f5" }} value={type}>{type}</option>)}</select></label>
          <div className="flex gap-1"><Button type="button" variant="ghost" size="icon" aria-label="Move input up" disabled={index === 0} onClick={() => moveInput(index, -1)}><ArrowUp className="w-4 h-4" /></Button><Button type="button" variant="ghost" size="icon" aria-label="Move input down" disabled={index === form.inputs.length - 1} onClick={() => moveInput(index, 1)}><ArrowDown className="w-4 h-4" /></Button><Button type="button" variant="ghost" size="icon" aria-label="Remove input" onClick={() => update("inputs", form.inputs.filter((_, i) => i !== index))}><Trash2 className="w-4 h-4 text-red-300" /></Button></div>
          </div>)}
          {form.inputs.length === 0 && <p className="rounded-xl border border-dashed border-white/10 py-8 text-center text-sm text-white/35">Add an input mapping to configure this workflow.</p>}
        </section>
        {error && <p role="alert" className="text-sm text-red-300">{error}</p>}
        <div className="flex justify-between items-center border-t border-white/10 pt-4">{initial ? <p className="text-xs text-amber-200/70">Current workflow state: {form.isActive ? "Active" : "Inactive"} · {form.creditCost.trim() === "" ? "No credit price" : `${form.creditCost} credits`}.</p> : <p className="text-xs text-amber-200/70">New workflows save inactive with no credit price.</p>}<div className="flex gap-2"><Button type="button" variant="ghost" onClick={onClose}>Cancel</Button><Button type="submit" disabled={saving}>{saving && <Loader2 className="w-4 h-4 animate-spin mr-2" />}{initial ? "Save changes" : "Create workflow"}</Button></div></div>
      </form>
    </div>
  );
}

export default function AdminWorkflows() {
  const [rows, setRows] = useState<WorkflowRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<WorkflowRow | null | undefined>(undefined);
  const [deleting, setDeleting] = useState<WorkflowRow | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState("");
  const [deleteError, setDeleteError] = useState("");
  const [deleteSaving, setDeleteSaving] = useState(false);
  async function refresh() { setLoading(true); setError(""); try { setRows(await request<WorkflowRow[]>(API_BASE)); } catch (err) { setError(err instanceof Error ? err.message : String(err)); } finally { setLoading(false); } }
  useEffect(() => { void refresh(); }, []);
  function openDeleteDialog(row: WorkflowRow) {
    setDeleting(row);
    setDeleteConfirmation("");
    setDeleteError("");
  }
  async function handleDeleteWorkflow() {
    if (!deleting || (deleteConfirmation !== deleting.name && deleteConfirmation !== deleting.modelId)) return;
    setDeleteSaving(true);
    setDeleteError("");
    try {
      await request<{ deleted: boolean }>(`${API_BASE}/${encodeURIComponent(deleting.modelId)}`, {
        method: "DELETE",
        body: JSON.stringify({ confirmation: deleteConfirmation }),
      });
      setRows((current) => current.filter((row) => row.id !== deleting.id));
      toast({ title: "Workflow deleted", description: `${deleting.name} was permanently deleted.` });
      setDeleting(null);
      setDeleteConfirmation("");
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : String(err));
    } finally {
      setDeleteSaving(false);
    }
  }

  return <AdminShell><div className="max-w-6xl mx-auto p-6 lg:p-10 space-y-6">
    <header className="flex items-start justify-between gap-4"><div><div className="flex items-center gap-2 text-primary mb-2"><Workflow className="w-5 h-5" /><span className="text-xs uppercase tracking-wider font-semibold">Model library</span></div><h1 className="text-3xl font-black">Workflows</h1><p className="text-sm text-white/50 mt-2">Manage RunningHub workflows saved in the model library.</p></div><Button onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-2" /> Add Workflow</Button></header>
    {loading ? <div className="py-20 flex justify-center text-white/40"><Loader2 className="animate-spin" /></div> : error ? <div role="alert" className="rounded-xl border border-red-500/20 p-5 text-red-200">{error}</div> : rows.length === 0 ? <div className="rounded-2xl border border-dashed border-white/10 py-16 text-center"><Workflow className="w-8 h-8 text-white/25 mx-auto mb-3" /><p className="text-white/60">No workflows have been added.</p><Button className="mt-4" variant="outline" onClick={() => setEditing(null)}><Plus className="w-4 h-4 mr-2" /> Add Workflow</Button></div> : <div className="grid gap-3">{rows.map((row) => <article key={row.id} className="rounded-xl border border-white/10 bg-white/[0.02] p-5 flex items-center gap-4"><div className="flex-1 min-w-0"><div className="flex items-center gap-2 flex-wrap"><h2 className="font-bold truncate">{row.name}</h2><span className={`text-[10px] uppercase rounded px-2 py-1 ${row.isActive ? "bg-emerald-500/10 text-emerald-300" : "bg-amber-500/10 text-amber-200"}`}>{row.isActive ? "Active" : "Inactive"}</span></div><p className="text-xs text-white/40 mt-1">{row.modelId} · {row.category} · {row.executionConfig?.inputs?.length ?? 0} inputs · {row.creditCost === null ? "No credit price" : `${row.creditCost} credits`}</p><p className="text-[11px] text-white/30 mt-1">Workflow ID: {row.executionConfig?.workflowId}</p></div><div className="flex shrink-0 items-center gap-2"><Button variant="outline" size="sm" onClick={() => setEditing(row)}><Pencil className="w-3.5 h-3.5 mr-1.5" /> Edit</Button><Button type="button" variant="ghost" size="icon" aria-label={`Delete ${row.name}`} className="text-red-300 hover:bg-red-500/10 hover:text-red-200" onClick={() => openDeleteDialog(row)}><Trash2 className="w-4 h-4" /></Button></div></article>)}</div>}
    {editing !== undefined && <WorkflowForm initial={editing ?? undefined} onClose={() => setEditing(undefined)} onSaved={() => void refresh()} />}
    <Dialog open={deleting !== null} onOpenChange={(open) => { if (!open && !deleteSaving) { setDeleting(null); setDeleteConfirmation(""); setDeleteError(""); } }}>
      {deleting && <DialogContent className="border-white/10 bg-[#141414] text-white">
        <DialogHeader>
          <DialogTitle>Delete workflow?</DialogTitle>
          <DialogDescription className="text-white/60">
            This permanently deletes <span className="font-semibold text-white">{deleting.name}</span>. This action cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <label htmlFor="workflow-delete-confirmation" className="text-sm text-white/80">Type this exact display name or slug to confirm:</label>
          <p className="break-all rounded-md border border-white/10 bg-white/[0.03] px-3 py-2 text-sm">{deleting.name}</p>
          <p className="break-all rounded-md border border-white/10 bg-white/[0.03] px-3 py-2 text-sm">{deleting.modelId}</p>
          <Input id="workflow-delete-confirmation" autoComplete="off" value={deleteConfirmation} onChange={(event) => setDeleteConfirmation(event.target.value)} />
        </div>
        {deleteError && <p role="alert" className="text-sm text-red-300">{deleteError}</p>}
        <DialogFooter>
          <Button type="button" variant="outline" disabled={deleteSaving} onClick={() => { setDeleting(null); setDeleteConfirmation(""); setDeleteError(""); }}>Cancel</Button>
          <Button type="button" variant="destructive" disabled={deleteSaving || (deleteConfirmation !== deleting.name && deleteConfirmation !== deleting.modelId)} onClick={() => void handleDeleteWorkflow()}>
            {deleteSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Delete permanently
          </Button>
        </DialogFooter>
      </DialogContent>}
    </Dialog>
  </div></AdminShell>;
}
