import { useState, useRef, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Loader2,
  Upload,
  Link2,
  Check,
  X,
  ChevronDown,
  ChevronUp,
  Image as ImageIcon,
  Search,
  Filter,
  Plus,
  RefreshCw,
  AlertTriangle,
  Layers,
  Sparkles,
} from "lucide-react";
import {
  useListAdminModels,
  usePatchAdminModel,
  useSetAdminModelThumbnailUrl,
  useRequestUploadUrl,
  useGetAdminCatalog,
  useAddModelFromCatalog,
  useSyncAdminModels,
  useApproveModelSchema,
  getListAdminModelsQueryKey,
  getGetAdminCatalogQueryKey,
} from "@workspace/api-client-react";
import type { AdminModel, CatalogEntry } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { AdminShell } from "./shell";

const PAGE_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

// ── Adapter color ──────────────────────────────────────────────────────────────
const ADAPTER_BG: Record<string, string> = {
  wavespeed: "#0EA5E9",
  openai: "#10A37F",
  openrouter: "#6366F1",
  elevenlabs: "#E44D26",
  anthropic: "#D97706",
  kling: "#7C3AED",
  google: "#4285F4",
  fal: "#FF6B35",
};

function adapterColor(slug: string) {
  if (ADAPTER_BG[slug]) return ADAPTER_BG[slug];
  let h = 0;
  for (let i = 0; i < slug.length; i++) h = (h * 31 + slug.charCodeAt(i)) & 0xffffff;
  return `#${h.toString(16).padStart(6, "0")}`;
}

const BADGE_OPTIONS = ["", "NEW", "TRENDING", "HOT", "TOP"] as const;

function categoryColor(cat: string) {
  if (cat === "image") return "bg-violet-500/15 text-violet-400";
  if (cat === "video") return "bg-blue-500/15 text-blue-400";
  if (cat === "audio") return "bg-emerald-500/15 text-emerald-400";
  return "bg-white/[0.06] text-white/40";
}

function badgeColor(b: string | null) {
  if (b === "NEW") return "bg-primary/15 text-primary";
  if (b === "TRENDING") return "bg-orange-500/15 text-orange-400";
  if (b === "HOT") return "bg-red-500/15 text-red-400";
  if (b === "TOP") return "bg-purple-500/15 text-purple-400";
  return "";
}

// ── Schema Diff Modal ─────────────────────────────────────────────────────────

interface SchemaField {
  key: string;
  label?: string;
  type?: string;
  required?: boolean;
}

function SchemaDiffModal({
  model,
  isOpen,
  onClose,
  onResolved,
}: {
  model: AdminModel;
  isOpen: boolean;
  onClose: () => void;
  onResolved: (updated: AdminModel) => void;
}) {
  const [submitting, setSubmitting] = useState(false);
  const approveMutation = useApproveModelSchema();

  const currentFields: SchemaField[] = (model as any)?.paramsSchema?.fields || [];
  const pendingFields: SchemaField[] = (model as any)?.pendingSchemaUpdate?.fields || [];

  const currentMap = useMemo(() => new Map(currentFields.map((f) => [f.key, f])), [currentFields]);
  const pendingMap = useMemo(() => new Map(pendingFields.map((f) => [f.key, f])), [pendingFields]);

  const addedFields = pendingFields.filter((f) => !currentMap.has(f.key));
  const removedFields = currentFields.filter((f) => !pendingMap.has(f.key));
  const changedFields = pendingFields.filter((f) => {
    const curr = currentMap.get(f.key);
    return curr && (curr.type !== f.type || curr.required !== f.required);
  });

  async function handleAction(action: "approve" | "dismiss") {
    setSubmitting(true);
    try {
      const updated = await approveMutation.mutateAsync({
        modelId: model.modelId,
        data: { action },
      });
      toast({
        title: action === "approve" ? "Schema approved and applied" : "Incoming schema update dismissed",
        description: `Pending schema review cleared for ${model.name}.`,
      });
      onResolved(updated);
      onClose();
    } catch (err) {
      toast({
        title: "Action failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl bg-[#141414] border-white/10 text-white p-6">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <DialogTitle className="text-lg font-bold text-white">
                Review Schema Update — {model.name}
              </DialogTitle>
              <DialogDescription className="text-xs text-white/50">
                This model is in use by a Feature App. The provider published an updated schema during catalog sync.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 text-xs text-amber-300 space-y-1">
          <p className="font-semibold">⚠️ Feature App Protection Active</p>
          <p className="text-amber-300/80">
            Per system guardrails, schema changes for models locked to feature apps are never applied silently. Review the changes below before deciding to overwrite or discard.
          </p>
        </div>

        {/* Diff summary */}
        <div className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-4">
            {/* Current Stored Schema */}
            <div className="border border-white/10 rounded-lg p-3 bg-white/[0.02]">
              <div className="text-[11px] font-bold text-white/40 uppercase tracking-wider mb-2">
                Current Stored Schema ({currentFields.length} fields)
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {currentFields.length === 0 ? (
                  <span className="text-white/30 italic">No parameters defined</span>
                ) : (
                  currentFields.map((f) => (
                    <div
                      key={f.key}
                      className={cn(
                        "flex items-center justify-between p-1.5 rounded text-[11px]",
                        removedFields.some((r) => r.key === f.key)
                          ? "bg-red-500/15 text-red-300 border border-red-500/20"
                          : "bg-white/[0.04] text-white/70"
                      )}
                    >
                      <span className="font-mono font-medium">{f.key}</span>
                      <span className="text-white/40 text-[10px]">{f.type}{f.required ? " · req" : ""}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Incoming Provider Schema */}
            <div className="border border-white/10 rounded-lg p-3 bg-white/[0.02]">
              <div className="text-[11px] font-bold text-white/40 uppercase tracking-wider mb-2">
                Incoming Provider Schema ({pendingFields.length} fields)
              </div>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {pendingFields.length === 0 ? (
                  <span className="text-white/30 italic">No parameters defined</span>
                ) : (
                  pendingFields.map((f) => (
                    <div
                      key={f.key}
                      className={cn(
                        "flex items-center justify-between p-1.5 rounded text-[11px]",
                        addedFields.some((a) => a.key === f.key)
                          ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/20"
                          : changedFields.some((c) => c.key === f.key)
                          ? "bg-blue-500/15 text-blue-300 border border-blue-500/20"
                          : "bg-white/[0.04] text-white/70"
                      )}
                    >
                      <span className="font-mono font-medium">{f.key}</span>
                      <span className="text-white/40 text-[10px]">{f.type}{f.required ? " · req" : ""}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Change description chips */}
          <div className="flex flex-wrap gap-2 pt-1">
            {addedFields.map((f) => (
              <span key={f.key} className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                + Added: {f.key} ({f.type})
              </span>
            ))}
            {removedFields.map((f) => (
              <span key={f.key} className="text-[10px] px-2 py-0.5 rounded bg-red-500/20 text-red-300 border border-red-500/30">
                - Removed: {f.key}
              </span>
            ))}
            {changedFields.map((f) => (
              <span key={f.key} className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                ~ Modified: {f.key}
              </span>
            ))}
            {addedFields.length === 0 && removedFields.length === 0 && changedFields.length === 0 && (
              <span className="text-white/40 text-xs italic">No structural field differences detected.</span>
            )}
          </div>
        </div>

        <DialogFooter className="flex items-center justify-between gap-3 pt-4 border-t border-white/[0.08]">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => handleAction("dismiss")}
            disabled={submitting}
            className="text-white/50 hover:text-white hover:bg-white/10 text-xs"
          >
            {submitting ? <Loader2 className="w-3 h-3 animate-spin mr-1.5" /> : null}
            Dismiss (Keep Current Schema)
          </Button>

          <Button
            type="button"
            size="sm"
            onClick={() => handleAction("approve")}
            disabled={submitting}
            className="bg-primary text-black font-bold hover:bg-primary/90 text-xs"
          >
            {submitting ? <Loader2 className="w-3 h-3 animate-spin mr-1.5" /> : null}
            Approve &amp; Overwrite Schema
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Thumbnail Upload ───────────────────────────────────────────────────────────

function ThumbnailUpload({
  model,
  onUpdated,
}: {
  model: AdminModel;
  onUpdated: (updated: AdminModel) => void;
}) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [pasteMode, setPasteMode] = useState(false);
  const [pasteUrl, setPasteUrl] = useState("");
  const [pasting, setPasting] = useState(false);
  const requestUploadUrl = useRequestUploadUrl();
  const patchModel = usePatchAdminModel();
  const setThumbnailUrl = useSetAdminModelThumbnailUrl();

  async function handleFile(file: File) {
    setUploading(true);
    try {
      const res = await requestUploadUrl.mutateAsync({
        data: { name: file.name, size: file.size, contentType: file.type },
      });
      const put = await fetch(res.uploadURL, {
        method: "PUT",
        body: file,
        headers: { "Content-Type": file.type },
      });
      if (!put.ok) throw new Error(`Upload failed: ${put.status}`);
      const thumbnailPath = `/api/storage${res.objectPath}`;
      const updated = await patchModel.mutateAsync({
        modelId: model.modelId,
        data: { thumbnailUrl: thumbnailPath },
      });
      toast({ title: "Thumbnail updated" });
      onUpdated(updated);
    } catch (err) {
      toast({
        title: "Upload failed",
        description: String(err),
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  }

  async function handlePasteUrl() {
    if (!pasteUrl.trim()) return;
    setPasting(true);
    try {
      const updated = await setThumbnailUrl.mutateAsync({
        modelId: model.modelId,
        data: { url: pasteUrl.trim() },
      });
      setPasteMode(false);
      setPasteUrl("");
      toast({ title: "Thumbnail updated" });
      onUpdated(updated);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast({ title: "Import failed", description: msg, variant: "destructive" });
    } finally {
      setPasting(false);
    }
  }

  async function handleClear() {
    try {
      const updated = await patchModel.mutateAsync({
        modelId: model.modelId,
        data: { thumbnailUrl: null },
      });
      toast({ title: "Thumbnail removed" });
      onUpdated(updated);
    } catch {
      toast({ title: "Failed to remove thumbnail", variant: "destructive" });
    }
  }

  const thumbSrc = model.thumbnailUrl
    ? model.thumbnailUrl.startsWith("/api/storage")
      ? `${PAGE_BASE}${model.thumbnailUrl}`
      : model.thumbnailUrl
    : null;

  return (
    <div className="space-y-2">
      <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
        Thumbnail
      </Label>

      <div className="flex items-center gap-3">
        <div className="w-16 h-16 rounded-xl border border-white/[0.08] bg-white/[0.03] flex items-center justify-center shrink-0 overflow-hidden">
          {thumbSrc ? (
            <img
              src={thumbSrc}
              alt={model.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <ImageIcon className="w-6 h-6 text-white/20" />
          )}
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading || pasting}
            className="border-white/15 text-white/70 hover:bg-white/5 h-8 text-xs"
          >
            {uploading ? (
              <Loader2 className="w-3 h-3 animate-spin mr-1" />
            ) : (
              <Upload className="w-3 h-3 mr-1" />
            )}
            Upload
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setPasteMode((v) => !v)}
            disabled={uploading || pasting}
            className={cn(
              "border-white/15 text-white/70 hover:bg-white/5 h-8 text-xs",
              pasteMode && "border-primary/50 text-primary",
            )}
          >
            <Link2 className="w-3 h-3 mr-1" />
            Paste URL
          </Button>
          {model.thumbnailUrl && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleClear}
              disabled={uploading || pasting}
              className="h-8 text-xs text-red-400/60 hover:text-red-400 hover:bg-red-500/10"
            >
              <X className="w-3 h-3 mr-1" />
              Remove
            </Button>
          )}
        </div>
      </div>

      {pasteMode && (
        <div className="flex gap-2">
          <Input
            placeholder="https://…/thumbnail.jpg"
            value={pasteUrl}
            onChange={(e) => setPasteUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handlePasteUrl();
              if (e.key === "Escape") {
                setPasteMode(false);
                setPasteUrl("");
              }
            }}
            className="bg-white/[0.04] border-white/10 text-white text-xs h-8"
            autoFocus
          />
          <Button
            type="button"
            size="sm"
            onClick={handlePasteUrl}
            disabled={!pasteUrl.trim() || pasting}
            className="bg-primary text-black font-bold hover:bg-primary/90 h-8 text-xs shrink-0"
          >
            {pasting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              setPasteMode(false);
              setPasteUrl("");
            }}
            className="h-8 text-white/40 hover:text-white shrink-0"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp,image/gif,image/svg+xml"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}

// ── Model Card ─────────────────────────────────────────────────────────────────

function ModelCard({
  model: initialModel,
}: {
  model: AdminModel;
}) {
  const [model, setModel] = useState(initialModel);
  const [expanded, setExpanded] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showDiffModal, setShowDiffModal] = useState(false);

  // Editable field state
  const [name, setName] = useState(model.name);
  const [description, setDescription] = useState(model.description);
  const [badge, setBadge] = useState(model.badge ?? "");
  const [sortOrder, setSortOrder] = useState(String(model.sortOrder));
  const [creditCost, setCreditCost] = useState(model.creditCost !== null ? String(model.creditCost) : "");

  const patchModel = usePatchAdminModel();

  const hasDetailChanges =
    name.trim() !== model.name ||
    description !== model.description ||
    badge !== (model.badge ?? "") ||
    sortOrder !== String(model.sortOrder) ||
    creditCost !== (model.creditCost !== null ? String(model.creditCost) : "");

  async function toggleActive() {
    // Guard: Prevent activating an unpriced model
    if (!model.isActive && model.creditCost === null) {
      toast({
        title: "Credit cost required",
        description: "You must set a valid credit cost before activating this model.",
        variant: "destructive",
      });
      setExpanded(true);
      return;
    }

    setToggling(true);
    try {
      const updated = await patchModel.mutateAsync({
        modelId: model.modelId,
        data: { isActive: !model.isActive },
      });
      setModel(updated);
      toast({
        title: updated.isActive
          ? `${model.name} enabled`
          : `${model.name} disabled — hidden from public listing`,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast({ title: "Update failed", description: msg, variant: "destructive" });
    } finally {
      setToggling(false);
    }
  }

  async function toggleCatalogVisibility() {
    setToggling(true);
    try {
      const updated = await patchModel.mutateAsync({
        modelId: model.modelId,
        data: { showInCatalog: !model.showInCatalog },
      });
      setModel(updated);
      toast({
        title: updated.showInCatalog
          ? `${model.name} shown in model menu`
          : `${model.name} hidden from model menu`,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast({ title: "Visibility update failed", description: msg, variant: "destructive" });
    } finally {
      setToggling(false);
    }
  }

  async function saveDetails() {
    const so = parseInt(sortOrder, 10);
    const cc = creditCost.trim() === "" ? undefined : parseInt(creditCost, 10);

    if (isNaN(so) || so < 0) {
      toast({ title: "Sort order must be a non-negative integer", variant: "destructive" });
      return;
    }
    if (cc !== undefined && (isNaN(cc) || cc < 0)) {
      toast({ title: "Credit cost must be a non-negative integer", variant: "destructive" });
      return;
    }
    if (!name.trim()) {
      toast({ title: "Name cannot be empty", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const updated = await patchModel.mutateAsync({
        modelId: model.modelId,
        data: {
          name: name.trim(),
          description,
          badge: badge || null,
          sortOrder: so,
          creditCost: cc,
        },
      });
      setModel(updated);
      setName(updated.name);
      setDescription(updated.description);
      setBadge(updated.badge ?? "");
      setSortOrder(String(updated.sortOrder));
      setCreditCost(updated.creditCost !== null ? String(updated.creditCost) : "");
      toast({ title: "Model updated" });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast({ title: "Save failed", description: msg, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  function discardDetails() {
    setName(model.name);
    setDescription(model.description);
    setBadge(model.badge ?? "");
    setSortOrder(String(model.sortOrder));
    setCreditCost(model.creditCost !== null ? String(model.creditCost) : "");
  }

  const thumbSrc = model.thumbnailUrl
    ? model.thumbnailUrl.startsWith("/api/storage")
      ? `${PAGE_BASE}${model.thumbnailUrl}`
      : model.thumbnailUrl
    : null;

  const color = adapterColor(model.adapter);

  return (
    <>
      <div
        className={cn(
          "bg-[#141414] border rounded-xl transition-colors overflow-hidden",
          model.isDelisted ? "border-amber-500/30 bg-amber-500/[0.02]" : expanded ? "border-white/[0.12]" : "border-white/[0.08]",
        )}
      >
        {/* Card header */}
        <div className="flex items-center gap-3 px-4 py-3">
          {/* Thumbnail */}
          <div className="w-12 h-12 rounded-lg border border-white/[0.08] flex items-center justify-center shrink-0 overflow-hidden bg-white/[0.03]">
            {thumbSrc ? (
              <img src={thumbSrc} alt={model.name} className="w-full h-full object-cover" />
            ) : (
              <div
                className="w-full h-full flex items-center justify-center text-xs font-black text-black/60"
                style={{ backgroundColor: color }}
              >
                {model.adapter.slice(0, 2).toUpperCase()}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-semibold text-white truncate">
                {model.name}
              </span>

              {model.isDelisted && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wide bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  Delisted by Provider
                </span>
              )}

              {model.creditCost === null && (
                <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/20">
                  Unpriced / Not Ready
                </span>
              )}

              {model.badge && (
                <span
                  className={cn(
                    "text-[10px] font-bold px-1.5 py-0.5 rounded-full uppercase tracking-wide",
                    badgeColor(model.badge),
                  )}
                >
                  {model.badge}
                </span>
              )}

              {/* Review Schema Diff Pill if pendingSchemaUpdate is active */}
              {model.pendingSchemaUpdate && (
                <button
                  type="button"
                  onClick={() => setShowDiffModal(true)}
                  className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 hover:bg-blue-500/30 transition-colors animate-pulse"
                >
                  <AlertTriangle className="w-2.5 h-2.5" />
                  Review Schema Diff
                </button>
              )}
            </div>

            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
              <span
                className={cn(
                  "text-[10px] px-1.5 py-0.5 rounded-full font-medium capitalize",
                  categoryColor(model.category),
                )}
              >
                {model.category}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium text-white/50 bg-white/[0.06]">
                {model.adapter}
              </span>
              {model.creditCost !== null ? (
                <span className="text-[10px] text-white/40 font-mono">
                  {model.creditCost} credits
                </span>
              ) : (
                <span className="text-[10px] text-amber-400/60 font-mono">
                  No cost set
                </span>
              )}
              {model.providerBasePriceUsd != null && (
                <span className="text-[10px] text-white/25">
                  · Prov: ${model.providerBasePriceUsd.toFixed(3)}
                </span>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <span className="text-xs text-white/30">{model.isActive ? "Active" : "Inactive"}</span>
              <Switch
                checked={model.isActive}
                onCheckedChange={toggleActive}
                disabled={toggling}
                aria-label="Enable model"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-white/50">Show in model menu</span>
              <Switch
                checked={model.showInCatalog}
                onCheckedChange={toggleCatalogVisibility}
                disabled={toggling}
                aria-label={`Show ${model.name} in model menu`}
              />
            </div>
            <button
              onClick={() => setExpanded((v) => !v)}
              className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/5 transition-colors"
              aria-label={expanded ? "Collapse" : "Expand settings"}
            >
              {expanded ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>

        {/* Expanded settings */}
        {expanded && (
          <div className="border-t border-white/[0.08] p-5 space-y-5">
            {model.isDelisted && (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-300">
                ⚠️ <strong>This model was removed from the provider's live catalog.</strong> It remains in your database to preserve user generation history, but cannot receive new generations.
              </div>
            )}

            {/* Thumbnail */}
            <ThumbnailUpload
              model={model}
              onUpdated={(updated) => setModel(updated)}
            />

            <div className="h-px bg-white/[0.06]" />

            {/* Name */}
            <div>
              <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                Name
              </Label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1.5 max-w-md"
              />
            </div>

            {/* Description */}
            <div>
              <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                Description
              </Label>
              <p className="text-xs text-white/30 mt-0.5 mb-1.5">
                Shown on model cards and tool detail pages.
              </p>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-white/[0.04] border-white/10 text-white text-sm max-w-lg"
                rows={2}
              />
            </div>

            {/* Badge + Sort + Credits row */}
            <div className="flex flex-wrap gap-4">
              {/* Badge picker */}
              <div>
                <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                  Badge
                </Label>
                <Select value={badge} onValueChange={setBadge}>
                  <SelectTrigger className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1.5 w-36">
                    <SelectValue placeholder="None" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1a1a] border-white/10">
                    {BADGE_OPTIONS.map((b) => (
                      <SelectItem
                        key={b || "__none__"}
                        value={b}
                        className="text-white focus:bg-white/10 focus:text-white"
                      >
                        {b || "None"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sort order */}
              <div>
                <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                  Sort Order
                </Label>
                <Input
                  type="number"
                  min={0}
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value)}
                  className="bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1.5 w-24"
                />
              </div>

              {/* Credit cost */}
              <div>
                <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider">
                  Credits / Gen
                </Label>
                <Input
                  type="number"
                  min={0}
                  placeholder="Unset"
                  value={creditCost}
                  onChange={(e) => setCreditCost(e.target.value)}
                  className={cn(
                    "bg-white/[0.04] border-white/10 text-white text-sm h-9 mt-1.5 w-28",
                    creditCost === "" && "border-amber-500/40 text-amber-300"
                  )}
                />
                {creditCost === "" && (
                  <p className="text-[10px] text-amber-400/70 mt-1">
                    Must be set to activate
                  </p>
                )}
              </div>
            </div>

            {/* Read-only info */}
            <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-white/25 pt-1">
              <span>
                <span className="text-white/40">Model ID:</span> {model.modelId}
              </span>
              <span>
                <span className="text-white/40">Provider path:</span>{" "}
                <code className="font-mono text-white/50">{model.providerModelPath}</code>
              </span>
              <span>
                <span className="text-white/40">Provider cost:</span>{" "}
                ${model.providerBasePriceUsd != null ? model.providerBasePriceUsd.toFixed(4) : model.basePriceUsd.toFixed(4)}
              </span>
              <span>
                <span className="text-white/40">Source:</span>{" "}
                {model.isSynced ? "Catalog Synced" : "Manual Seed"}
              </span>
              {model.lastSyncedAt && (
                <span>
                  <span className="text-white/40">Last Synced:</span>{" "}
                  {new Date(model.lastSyncedAt).toLocaleString()}
                </span>
              )}
            </div>

            {/* Save / discard */}
            {hasDetailChanges && (
              <div className="flex items-center gap-3 pt-1">
                <Button
                  onClick={saveDetails}
                  disabled={saving}
                  size="sm"
                  className="h-9 bg-primary text-black font-bold hover:bg-primary/90"
                >
                  {saving ? (
                    <><Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" />Saving…</>
                  ) : (
                    <>Save changes</>
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={discardDetails}
                  disabled={saving}
                  className="text-white/40 hover:text-white h-9"
                >
                  Discard
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Diff Review Modal */}
      {model.pendingSchemaUpdate && (
        <SchemaDiffModal
          model={model}
          isOpen={showDiffModal}
          onClose={() => setShowDiffModal(false)}
          onResolved={(updated) => setModel(updated)}
        />
      )}
    </>
  );
}

// ── Filter chip helper ─────────────────────────────────────────────────────────

function FilterChip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border",
        active
          ? "bg-primary text-black border-primary"
          : "text-white/50 border-white/[0.08] hover:text-white hover:border-white/20 bg-transparent",
      )}
    >
      {label}
    </button>
  );
}

// ── Provider Catalog Browser Component ────────────────────────────────────────

function CatalogBrowser({
  onModelAdded,
}: {
  onModelAdded: (model: AdminModel) => void;
}) {
  const queryClient = useQueryClient();
  const [selectedProvider, setSelectedProvider] = useState("wavespeed");
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [addingPath, setAddingPath] = useState<string | null>(null);
  const [syncing, setSyncing] = useState(false);

  const {
    data: catalog = [],
    isLoading,
    error,
    refetch,
  } = useGetAdminCatalog(selectedProvider, {
    query: {
      queryKey: getGetAdminCatalogQueryKey(selectedProvider),
      staleTime: 60 * 1000,
    },
  });

  const addModelMutation = useAddModelFromCatalog();
  const syncModelsMutation = useSyncAdminModels();

  const filteredCatalog = useMemo(() => {
    const q = search.toLowerCase().trim();
    return catalog.filter((item) => {
      if (categoryFilter !== "all" && item.category !== categoryFilter) return false;
      if (q && !item.name.toLowerCase().includes(q) && !item.providerModelPath.toLowerCase().includes(q) && !item.description.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [catalog, search, categoryFilter]);

  async function handleAdd(item: CatalogEntry) {
    setAddingPath(item.providerModelPath);
    try {
      const created = await addModelMutation.mutateAsync({
        data: {
          providerSlug: selectedProvider,
          providerModelPath: item.providerModelPath,
          category: item.category,
        },
      });

      toast({
        title: "Added to library",
        description: `"${created.name}" is now in your models library as inactive (creditCost: null). Set a price and activate when ready.`,
      });

      // Invalidate queries so both views update
      queryClient.invalidateQueries({ queryKey: getListAdminModelsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetAdminCatalogQueryKey(selectedProvider) });
      onModelAdded(created);
    } catch (err) {
      toast({
        title: "Failed to add model",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setAddingPath(null);
    }
  }

  async function handleSync() {
    setSyncing(true);
    try {
      const summary = await syncModelsMutation.mutateAsync({
        providerSlug: selectedProvider,
      });

      toast({
        title: `Sync Complete for ${selectedProvider}`,
        description: `Synced: ${summary.synced} · Delisted: ${summary.delisted} · Pending Review: ${summary.pendingReview.length} · Unchanged: ${summary.unchanged}`,
      });

      queryClient.invalidateQueries({ queryKey: getListAdminModelsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetAdminCatalogQueryKey(selectedProvider) });
    } catch (err) {
      toast({
        title: "Sync failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setSyncing(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Top Controls: Provider selector & Sync action */}
      <div className="flex items-center justify-between gap-4 p-4 rounded-xl border border-white/[0.08] bg-[#141414]">
        <div className="flex items-center gap-3">
          <Label className="text-xs font-semibold text-white/50 uppercase tracking-wider shrink-0">
            Provider:
          </Label>
          <Select value={selectedProvider} onValueChange={setSelectedProvider}>
            <SelectTrigger className="bg-white/[0.04] border-white/10 text-white text-xs h-8 w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-[#1a1a1a] border-white/10 text-white">
              <SelectItem value="wavespeed">WaveSpeed AI</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleSync}
            disabled={syncing || isLoading}
            className="border-white/15 text-white/70 hover:bg-white/5 h-8 text-xs font-medium"
          >
            {syncing ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" />
            ) : (
              <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
            )}
            Sync Library with {selectedProvider}
          </Button>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => refetch()}
            disabled={isLoading}
            className="text-white/40 hover:text-white h-8 text-xs"
          >
            Refresh Catalog
          </Button>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/25 pointer-events-none" />
          <Input
            placeholder="Search live provider catalog by name, model path, or description…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 focus-visible:border-white/20 text-xs"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <FilterChip
            label="All Categories"
            active={categoryFilter === "all"}
            onClick={() => setCategoryFilter("all")}
          />
          <FilterChip
            label="Images"
            active={categoryFilter === "image"}
            onClick={() => setCategoryFilter("image")}
          />
          <FilterChip
            label="Videos"
            active={categoryFilter === "video"}
            onClick={() => setCategoryFilter("video")}
          />
          <FilterChip
            label="Audio"
            active={categoryFilter === "audio"}
            onClick={() => setCategoryFilter("audio")}
          />
        </div>
      </div>

      {/* Loading state */}
      {isLoading && (
        <div className="flex flex-col items-center justify-center py-20 gap-3 text-white/40">
          <Loader2 className="w-7 h-7 animate-spin text-primary" />
          <p className="text-xs">Fetching live models from {selectedProvider} API…</p>
        </div>
      )}

      {/* Error state */}
      {!isLoading && error && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-5 text-red-400 text-sm space-y-2">
          <p className="font-semibold">Unable to fetch live catalog for {selectedProvider}.</p>
          <p className="text-xs text-red-400/80">
            {error instanceof Error ? error.message : String(error)}
          </p>
          <p className="text-xs text-white/40 pt-1">
            Make sure your platform API key is saved and verified in <a href="/admin/providers" className="text-primary underline">Admin → Providers</a>.
          </p>
        </div>
      )}

      {/* Empty state */}
      {!isLoading && !error && filteredCatalog.length === 0 && (
        <div className="flex flex-col items-center gap-2 py-16 text-white/25">
          <Search className="w-8 h-8" />
          <p className="text-sm">No provider models match your search</p>
        </div>
      )}

      {/* Catalog items list */}
      {!isLoading && !error && filteredCatalog.length > 0 && (
        <div className="space-y-2.5">
          <div className="text-xs text-white/40 px-1">
            Showing {filteredCatalog.length} of {catalog.length} available models from {selectedProvider}
          </div>

          {filteredCatalog.map((item) => {
            const fields: SchemaField[] = (item.paramsSchema as any)?.fields || [];

            return (
              <div
                key={item.providerModelPath}
                className="bg-[#141414] border border-white/[0.08] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-white/15 transition-colors"
              >
                <div className="space-y-1.5 flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">
                      {item.name}
                    </span>
                    <span
                      className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded-full font-medium capitalize",
                        categoryColor(item.category),
                      )}
                    >
                      {item.category}
                    </span>
                    <span className="text-[10px] text-white/40 font-mono bg-white/[0.04] px-1.5 py-0.5 rounded">
                      ${item.providerBasePriceUsd.toFixed(3)} / gen
                    </span>
                    {item.inLibrary && (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                        In Library
                      </span>
                    )}
                  </div>

                  <p className="text-xs font-mono text-white/40 truncate">
                    {item.providerModelPath}
                  </p>

                  {item.description && (
                    <p className="text-xs text-white/50 line-clamp-2 max-w-xl">
                      {item.description}
                    </p>
                  )}

                  {/* Schema fields preview */}
                  {fields.length > 0 && (
                    <div className="flex items-center gap-1.5 flex-wrap pt-1">
                      <span className="text-[10px] text-white/30">Inputs:</span>
                      {fields.slice(0, 6).map((f) => (
                        <span
                          key={f.key}
                          className="text-[10px] px-1.5 py-0.5 rounded bg-white/[0.03] text-white/60 border border-white/[0.06] font-mono"
                        >
                          {f.key}
                          <span className="text-white/30 text-[9px] ml-1">({f.type})</span>
                        </span>
                      ))}
                      {fields.length > 6 && (
                        <span className="text-[10px] text-white/30">+{fields.length - 6} more</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Add to library action button */}
                <div className="shrink-0 flex items-center gap-2 self-start sm:self-center">
                  {item.inLibrary ? (
                    <Button
                      variant="outline"
                      size="sm"
                      disabled
                      className="border-white/10 text-white/40 h-8 text-xs cursor-not-allowed"
                    >
                      <Check className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                      In Library
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      onClick={() => handleAdd(item)}
                      disabled={addingPath === item.providerModelPath}
                      className="bg-primary text-black font-bold hover:bg-primary/90 h-8 text-xs"
                    >
                      {addingPath === item.providerModelPath ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" />
                      ) : (
                        <Plus className="w-3.5 h-3.5 mr-1.5" />
                      )}
                      Add to Library
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function AdminModels() {
  const { data: models = [], isLoading, error, refetch } = useListAdminModels();

  const [activeTab, setActiveTab] = useState<"library" | "catalog">("library");
  const [search, setSearch] = useState("");
  const [adapterFilter, setAdapterFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  // Derive unique adapter and category values from real data
  const adapters = useMemo(
    () => [...new Set(models.map((m) => m.adapter))].sort(),
    [models],
  );
  const categories = useMemo(
    () => [...new Set(models.map((m) => m.category))].sort(),
    [models],
  );

  // Combined filter: search × adapter × category
  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return models.filter((m) => {
      if (adapterFilter !== "all" && m.adapter !== adapterFilter) return false;
      if (categoryFilter !== "all" && m.category !== categoryFilter) return false;
      if (q && !m.name.toLowerCase().includes(q) && !m.description.toLowerCase().includes(q) && !m.providerModelPath.toLowerCase().includes(q))
        return false;
      return true;
    });
  }, [models, search, adapterFilter, categoryFilter]);

  // Count models needing schema review
  const pendingReviewCount = useMemo(
    () => models.filter((m) => m.pendingSchemaUpdate !== null).length,
    [models]
  );

  return (
    <AdminShell>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-black text-white">Model Management</h1>
            <p className="text-sm text-white/40 mt-0.5">
              Configure models, sync provider catalogs, and manage generation parameters.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => refetch()}
              className="text-white/40 hover:text-white h-8 text-xs"
            >
              Refresh
            </Button>
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2 p-1 bg-white/[0.04] border border-white/[0.08] rounded-xl w-fit">
          <button
            type="button"
            onClick={() => setActiveTab("library")}
            className={cn(
              "px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2",
              activeTab === "library"
                ? "bg-white/10 text-white shadow-sm"
                : "text-white/40 hover:text-white hover:bg-white/[0.04]"
            )}
          >
            <Layers className="w-3.5 h-3.5" />
            Configured Models ({models.length})
            {pendingReviewCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-blue-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                {pendingReviewCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("catalog")}
            className={cn(
              "px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-2",
              activeTab === "catalog"
                ? "bg-white/10 text-white shadow-sm"
                : "text-white/40 hover:text-white hover:bg-white/[0.04]"
            )}
          >
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            Browse Provider Catalog
          </button>
        </div>

        {/* Tab 1: Configured Models in Library */}
        {activeTab === "library" && (
          <div className="space-y-4">
            {/* Toolbar */}
            <div className="space-y-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/25 pointer-events-none" />
                <Input
                  placeholder="Search library models by name, slug, or provider path…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/25 focus-visible:border-white/20 text-xs"
                />
                {search && (
                  <button
                    onClick={() => setSearch("")}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/30 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Adapter filter */}
              {adapters.length > 1 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <Filter className="w-3.5 h-3.5 text-white/30 shrink-0" />
                  <FilterChip
                    label="All providers"
                    active={adapterFilter === "all"}
                    onClick={() => setAdapterFilter("all")}
                  />
                  {adapters.map((a) => (
                    <FilterChip
                      key={a}
                      label={a}
                      active={adapterFilter === a}
                      onClick={() => setAdapterFilter(adapterFilter === a ? "all" : a)}
                    />
                  ))}
                </div>
              )}

              {/* Category filter */}
              {categories.length > 1 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="w-3.5 shrink-0" />
                  <FilterChip
                    label="All types"
                    active={categoryFilter === "all"}
                    onClick={() => setCategoryFilter("all")}
                  />
                  {categories.map((c) => (
                    <FilterChip
                      key={c}
                      label={c}
                      active={categoryFilter === c}
                      onClick={() =>
                        setCategoryFilter(categoryFilter === c ? "all" : c)
                      }
                    />
                  ))}
                </div>
              )}
            </div>

            {/* States */}
            {isLoading && (
              <div className="flex justify-center py-16">
                <Loader2 className="w-6 h-6 animate-spin text-white/30" />
              </div>
            )}

            {!isLoading && error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 text-sm">
                Failed to load models. Check that the API server is running, then refresh.
              </div>
            )}

            {!isLoading && !error && filtered.length === 0 && (
              <div className="flex flex-col items-center gap-2 py-16 text-white/25">
                <Search className="w-8 h-8" />
                <p className="text-sm">No models match the current filters</p>
              </div>
            )}

            {/* Model cards */}
            {!isLoading && !error && filtered.length > 0 && (
              <div className="space-y-2">
                {filtered.map((model) => (
                  <ModelCard key={model.modelId} model={model} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Live Provider Catalog Browser */}
        {activeTab === "catalog" && (
          <CatalogBrowser
            onModelAdded={() => {
              setActiveTab("library");
            }}
          />
        )}
      </div>
    </AdminShell>
  );
}
