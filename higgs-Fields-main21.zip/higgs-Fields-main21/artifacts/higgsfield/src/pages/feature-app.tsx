import { useState, useRef, useEffect, useCallback } from "react";
import { useParams, Link } from "wouter";
import {
  useGetFeatureApp,
  getGetFeatureAppQueryKey,
  useRunFeatureApp,
  useGetGeneration,
  getGetGenerationQueryKey,
  useRequestUploadUrl,
} from "@workspace/api-client-react";
import type { PublicFeatureAppDetail, Generation } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "@/hooks/use-toast";
import { useUser, useClerk } from "@clerk/react";
import {
  Upload,
  Loader2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  Download,
  X,
  Image as ImageIcon,
  Zap,
  RefreshCw,
  Clock,
  HelpCircle,
  ShieldCheck,
  Wand2,
  Layers,
  ArrowRight,
} from "lucide-react";

const PAGE_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

function resolveUrl(url: string) {
  if (url.startsWith("/api/storage") || url.startsWith("/api/public")) {
    return `${PAGE_BASE}${url}`;
  }
  return url;
}

// ── Upload Frame Component with Drag-Drop, Click & Paste ──────────────────────
function UploadFrame({
  label,
  help,
  value,
  onChange,
  onPathChange,
  disabled,
}: {
  label: string;
  help: string;
  value: string | null;
  onChange: (preview: string | null) => void;
  onPathChange: (path: string | null) => void;
  disabled?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [uploading, setUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const requestUpload = useRequestUploadUrl();

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file",
          description: "Please upload an image file (JPEG, PNG, or WEBP).",
          variant: "destructive",
        });
        return;
      }
      setUploading(true);
      try {
        const res = await requestUpload.mutateAsync({
          data: { name: file.name, size: file.size, contentType: file.type },
        });
        const put = await fetch(res.uploadURL, {
          method: "PUT",
          body: file,
          headers: { "Content-Type": file.type },
        });
        if (!put.ok) throw new Error(`Upload failed: ${put.status}`);
        onChange(URL.createObjectURL(file));
        onPathChange(res.objectPath);
        toast({ title: `${label} uploaded` });
      } catch (err) {
        toast({
          title: "Upload failed",
          description: err instanceof Error ? err.message : String(err),
          variant: "destructive",
        });
      } finally {
        setUploading(false);
      }
    },
    [requestUpload, onChange, onPathChange, label],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      if (disabled || uploading) return;
      const file = e.dataTransfer.files[0];
      if (file) handleFile(file);
    },
    [handleFile, disabled, uploading],
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  // Paste support: when container is focused or hovered, Ctrl+V pastes image
  const handlePaste = useCallback(
    (e: React.ClipboardEvent) => {
      if (disabled || uploading) return;
      const items = e.clipboardData.items;
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith("image/")) {
          const file = items[i].getAsFile();
          if (file) {
            e.preventDefault();
            handleFile(file);
            break;
          }
        }
      }
    },
    [disabled, uploading, handleFile],
  );

  return (
    <div
      ref={containerRef}
      tabIndex={0}
      onPaste={handlePaste}
      className="flex-1 min-w-0 outline-none focus-visible:ring-1 focus-visible:ring-primary/50 rounded-xl"
    >
      <div className="mb-2">
        <p className="text-sm font-semibold text-white">{label}</p>
        {help && <p className="text-xs text-white/45 mt-0.5">{help}</p>}
      </div>

      {value ? (
        <div className="relative group rounded-xl overflow-hidden border border-white/15 bg-black aspect-[3/4] sm:aspect-square flex items-center justify-center">
          <img src={value} alt={label} className="w-full h-full object-cover" />

          {!disabled && (
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => inputRef.current?.click()}
                className="bg-black/60 border-white/20 text-white text-xs hover:bg-black/80 h-8"
              >
                Replace
              </Button>
              <Button
                type="button"
                size="sm"
                variant="destructive"
                onClick={() => {
                  onChange(null);
                  onPathChange(null);
                }}
                className="h-8 px-2 text-xs"
                title="Remove image"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}

          {uploading && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          )}
        </div>
      ) : (
        <div
          role="button"
          tabIndex={0}
          onClick={() => !disabled && !uploading && inputRef.current?.click()}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={cn(
            "w-full aspect-[3/4] sm:aspect-square rounded-xl border-2 border-dashed",
            "flex flex-col items-center justify-center gap-3 transition-all cursor-pointer select-none",
            isDragOver
              ? "border-primary bg-primary/10"
              : disabled
              ? "border-white/10 cursor-not-allowed opacity-50"
              : "border-white/20 hover:border-primary/60 hover:bg-primary/[0.03]",
          )}
        >
          {uploading ? (
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          ) : (
            <>
              <div className="w-12 h-12 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center text-white/40">
                <Upload className="w-5 h-5" />
              </div>
              <div className="text-center px-4">
                <p className="text-sm font-medium text-white/80">Click, drag, or paste image</p>
                <p className="text-xs text-white/35 mt-0.5">Ctrl+V to paste · JPEG, PNG, WEBP</p>
              </div>
            </>
          )}
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/jpg,image/png,image/webp"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.target.value = "";
        }}
      />
    </div>
  );
}

// ── Result Display Panel with Polling & Elapsed Timer ─────────────────────────
function ResultPanel({
  generationId,
  appName,
  onCreateAnother,
  onRetry,
}: {
  generationId: number;
  appName: string;
  onCreateAnother: () => void;
  onRetry: () => void;
}) {
  const [elapsed, setElapsed] = useState(0);

  const { data: generation, isLoading } = useGetGeneration(generationId, {
    query: {
      queryKey: getGetGenerationQueryKey(generationId),
      refetchInterval: (q) => {
        const status = (q.state.data as Generation | undefined)?.status;
        if (status === "completed" || status === "failed") {
          return false;
        }
        return 2000;
      },
    },
  });

  const isTerminal =
    generation?.status === "completed" ||
    generation?.status === "failed";

  // Elapsed timer while processing
  useEffect(() => {
    if (isTerminal) return;
    const interval = setInterval(() => {
      setElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isTerminal]);

  const formatElapsed = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  if (isLoading || !generation) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-3 py-12">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
        <p className="text-sm text-white/50">Initializing generation...</p>
      </div>
    );
  }

  const { status, outputUrls, errorMessage } = generation;

  // Processing state with spinner, shimmer & elapsed time
  if (status === "pending" || status === "processing") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-4 py-12 text-center">
        <div className="relative w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
        <div className="space-y-1">
          <p className="text-base font-semibold text-white">Swapping faces...</p>
          <div className="flex items-center justify-center gap-1.5 text-xs text-white/50 font-mono">
            <Clock className="w-3.5 h-3.5" />
            <span>Elapsed: {formatElapsed(elapsed)}</span>
          </div>
        </div>
        <div className="w-48 h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div className="h-full bg-primary animate-pulse w-3/4 rounded-full" />
        </div>
      </div>
    );
  }

  // Failed state with Try Again button
  if (status === "failed") {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-4 py-8 text-center">
        <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-400">
          <AlertCircle className="w-7 h-7" />
        </div>
        <div className="space-y-1 max-w-sm">
          <p className="text-base font-bold text-red-400 capitalize">Generation {status}</p>
          <p className="text-xs text-white/50">
            {errorMessage || "The AI model encountered an error while processing your images."}
          </p>
        </div>
        <Button
          onClick={onRetry}
          variant="outline"
          size="sm"
          className="border-white/15 text-white/80 hover:text-white hover:bg-white/10 gap-1.5 text-xs mt-2"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Try Again
        </Button>
      </div>
    );
  }

  // Completed state with prominent image, Download & Create Another buttons
  if (status === "completed" && outputUrls.length > 0) {
    const mainOutput = outputUrls[0];
    const isVideo = mainOutput.match(/\.(mp4|mov|webm)$/i);

    return (
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400">
            <CheckCircle2 className="w-4 h-4" />
            <span className="text-sm font-semibold">Face Swap Complete</span>
          </div>
          <span className="text-xs text-white/40 font-mono">ID #{generationId}</span>
        </div>

        <div className="rounded-xl overflow-hidden border border-white/15 bg-black aspect-square flex items-center justify-center group relative shadow-2xl">
          {isVideo ? (
            <video
              src={resolveUrl(mainOutput)}
              controls
              className="w-full h-full object-cover"
              autoPlay
              loop
              muted
              playsInline
            />
          ) : (
            <img
              src={resolveUrl(mainOutput)}
              alt="Face Swap Result"
              className="w-full h-full object-cover"
            />
          )}
        </div>

        <div className="flex items-center gap-3">
          <Button
            asChild
            className="flex-1 bg-primary text-black font-bold hover:bg-primary/90 text-xs h-9 gap-1.5 shadow-[0_0_20px_rgba(206,255,0,0.25)]"
          >
            <a href={resolveUrl(mainOutput)} download="face-swap.png" target="_blank" rel="noreferrer">
              <Download className="w-4 h-4" />
              Download Image
            </a>
          </Button>

          <Button
            variant="outline"
            onClick={onCreateAnother}
            className="border-white/15 text-white/80 hover:text-white hover:bg-white/10 text-xs h-9 gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Create Another
          </Button>
        </div>
      </div>
    );
  }

  return null;
}

// ── Showcase Column with Before -> After Preview ──────────────────────────────
function ShowcaseHero({ app }: { app: PublicFeatureAppDetail }) {
  if (!app.showcaseImageUrl) {
    return (
      <div className="relative w-full aspect-square rounded-2xl border border-white/[0.08] bg-[#141414] flex flex-col items-center justify-center gap-3 p-8 text-center">
        <div className="w-16 h-16 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-white/30">
          <Wand2 className="w-8 h-8" />
        </div>
        <div>
          <h3 className="text-base font-bold text-white">{app.name} Preview</h3>
          <p className="text-xs text-white/40 mt-1 max-w-xs">
            Experience studio-grade, seamless face replacements powered by advanced generative AI.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full aspect-square rounded-2xl overflow-hidden border border-white/10 bg-black shadow-2xl group">
      <img
        src={resolveUrl(app.showcaseImageUrl)}
        alt="Showcase result"
        className="w-full h-full object-cover"
      />

      {app.showcaseInsetUrl && (
        <div className="absolute bottom-4 right-4 flex items-center gap-2 p-1.5 rounded-2xl bg-black/80 backdrop-blur-md border border-white/15 shadow-2xl">
          <div className="w-14 h-14 rounded-xl overflow-hidden border border-white/20">
            <img
              src={resolveUrl(app.showcaseInsetUrl)}
              alt="Source Face"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="pr-3 pl-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-primary block">
              Source Face
            </span>
            <span className="text-xs text-white/70">Original Identity</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Main Page Component ───────────────────────────────────────────────────────
export default function FeatureAppPage() {
  const { slug } = useParams<{ slug: string }>();
  const { isSignedIn } = useUser();
  const { openSignIn } = useClerk();

  const {
    data: app,
    isLoading: appLoading,
    isError,
  } = useGetFeatureApp(slug ?? "", {
    query: {
      queryKey: getGetFeatureAppQueryKey(slug ?? ""),
      enabled: !!slug,
    },
  });

  const runMutation = useRunFeatureApp();

  const [targetPreview, setTargetPreview] = useState<string | null>(null);
  const [targetPath, setTargetPath] = useState<string | null>(null);
  const [facePreview, setFacePreview] = useState<string | null>(null);
  const [facePath, setFacePath] = useState<string | null>(null);
  const [generationId, setGenerationId] = useState<number | null>(null);
  const [running, setRunning] = useState(false);

  // Update dynamic page title and meta
  useEffect(() => {
    if (app?.name) {
      document.title = `${app.name} — Higgsfield AI`;
    }
  }, [app?.name]);

  const canRun =
    !running &&
    targetPath !== null &&
    facePath !== null &&
    app?.isReady === true &&
    isSignedIn;

  async function handleRunClick() {
    if (!isSignedIn) {
      openSignIn();
      return;
    }
    if (!app || !targetPath || !facePath) return;

    setRunning(true);
    try {
      const res = await runMutation.mutateAsync({
        slug: app.slug,
        data: {
          targetImagePath: targetPath,
          faceImagePath: facePath,
        },
      });
      setGenerationId(res.generationId);
      const charged = res.creditsCharged;
      toast({
        title:
          charged === 0
            ? "Generation started (Free use)"
            : `Generation started · ${charged} credits charged`,
      });
    } catch (err: unknown) {
      const message =
        err instanceof Error
          ? err.message
          : (err as { response?: { data?: { message?: string } } })?.response?.data?.message ??
            String(err);
      toast({ title: "Generation failed", description: message, variant: "destructive" });
    } finally {
      setRunning(false);
    }
  }

  function handleCreateAnother() {
    setGenerationId(null);
  }

  // Dynamic button label
  const buttonLabel = (() => {
    if (app && !app.isReady) return "Coming soon";
    if (!isSignedIn) return "Sign in to Generate";
    if (running) return "Starting generation...";

    const freeLeft = app?.freeUsesRemaining ?? null;
    if (freeLeft !== null && freeLeft > 0) {
      return `${app?.name || "Swap Face"} — Free`;
    }
    if (app?.creditCost !== null && app?.creditCost !== undefined) {
      return `${app.name || "Swap Face"} — ${app.creditCost} credits`;
    }
    return app?.name || "Swap Face";
  })();

  if (appLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-white/30" />
      </div>
    );
  }

  if (isError || !app) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center px-4">
        <div className="text-6xl font-black text-primary">404</div>
        <h2 className="text-2xl font-bold text-white">Feature App Not Found</h2>
        <p className="text-muted-foreground">This feature application doesn't exist or has been removed.</p>
        <Link href="/apps">
          <Button className="bg-primary text-black font-bold hover:bg-primary/90">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Apps
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-white/[0.06] bg-gradient-to-b from-white/[0.02] to-transparent">
        <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16">
          <Link
            href="/apps"
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-white/40 hover:text-white mb-6 transition-colors uppercase tracking-wider"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Apps Directory
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left: App Title & Meta */}
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5" />
                {app.menuCategory ? `${app.menuCategory.toUpperCase()} APP` : "FEATURE APP"}
              </div>

              <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
                {app.heroTitle}
              </h1>

              <p className="text-base sm:text-lg text-white/60 leading-relaxed max-w-lg">
                {app.heroSubtitle}
              </p>

              <div className="flex items-center gap-4 pt-2 flex-wrap">
                {app.isReady && app.creditCost !== null && app.creditCost !== undefined && (
                  <div className="flex items-center gap-1.5 text-xs font-medium text-white/70 px-3 py-1.5 rounded-lg bg-white/[0.03] border border-white/[0.08]">
                    <Zap className="w-3.5 h-3.5 text-primary" />
                    <span>Cost: {app.creditCost} credits / run</span>
                  </div>
                )}
                {app.isReady && app.freeUsesPerUser > 0 && (
                  <div className="flex items-center gap-1.5 text-xs font-medium text-emerald-400 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{app.freeUsesPerUser} free uses included</span>
                  </div>
                )}
                {!app.isReady && (
                  <div className="flex items-center gap-1.5 text-xs font-medium text-amber-400 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Coming soon — not yet configured in admin</span>
                  </div>
                )}
              </div>
            </div>

            {/* Right: Showcase Preview */}
            <div>
              <ShowcaseHero app={app} />
            </div>
          </div>
        </div>
      </section>

      {/* Main Interactive Workspace */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8 items-start">
          {/* Left Column: Two Upload Frames & Action Button */}
          <div className="bg-[#141414] border border-white/[0.08] rounded-2xl p-6 space-y-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Layers className="w-5 h-5 text-primary" />
                Input Photos
              </h2>
              <p className="text-xs text-white/40 mt-1">
                Upload your target scene and source face to begin. Both photos are required.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <UploadFrame
                label={app.slot1.label}
                help={app.slot1.help}
                value={targetPreview}
                onChange={setTargetPreview}
                onPathChange={setTargetPath}
                disabled={running}
              />
              <UploadFrame
                label={app.slot2.label}
                help={app.slot2.help}
                value={facePreview}
                onChange={setFacePreview}
                onPathChange={setFacePath}
                disabled={running}
              />
            </div>

            {/* Status alerts & Button */}
            <div className="space-y-3 pt-2">
              {!isSignedIn && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>Sign in with your account to generate face swaps.</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => openSignIn()}
                    className="h-7 text-xs bg-amber-400 text-black font-semibold hover:bg-amber-300"
                  >
                    Sign in
                  </Button>
                </div>
              )}

              {isSignedIn && (!targetPath || !facePath) && (
                <div className="p-3 rounded-xl bg-white/[0.02] border border-white/[0.06] text-white/40 text-xs flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 shrink-0" />
                  <span>Upload both photos above to enable the generation button.</span>
                </div>
              )}

              <Button
                onClick={handleRunClick}
                disabled={!app.isReady || (isSignedIn && (!targetPath || !facePath || running))}
                title={!app.isReady ? "Coming soon" : undefined}
                className={cn(
                  "w-full h-12 text-sm font-bold gap-2 rounded-xl transition-all",
                  canRun
                    ? "bg-primary text-black hover:bg-primary/90 shadow-[0_0_25px_rgba(206,255,0,0.25)]"
                    : "opacity-60 cursor-not-allowed bg-white/10 text-white/60",
                )}
              >
                {running ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
                {buttonLabel}
              </Button>
            </div>
          </div>

          {/* Right Column: Result Display */}
          <div className="bg-[#141414] border border-white/[0.08] rounded-2xl p-6 min-h-[380px] flex flex-col justify-center">
            <h2 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" />
              Generated Output
            </h2>

            {generationId !== null ? (
              <ResultPanel
                generationId={generationId}
                appName={app.name}
                onCreateAnother={handleCreateAnother}
                onRetry={handleRunClick}
              />
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center py-12">
                <div className="w-14 h-14 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center text-white/20">
                  <ImageIcon className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-semibold text-white/70">No result yet</p>
                  <p className="text-xs text-white/35 max-w-[200px]">
                    Upload photos and click "{buttonLabel}" to view your output.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Below the Fold: How it Works (3 Steps) */}
      <section className="border-t border-white/[0.06] bg-white/[0.01] py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center max-w-xl mx-auto mb-12 space-y-2">
            <h2 className="text-2xl sm:text-3xl font-black text-white">How It Works</h2>
            <p className="text-sm text-white/50">
              Create photorealistic, studio-quality face swaps in three effortless steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-[#141414] border border-white/[0.08] space-y-3 relative group hover:border-primary/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center font-black text-sm">
                1
              </div>
              <h3 className="text-base font-bold text-white">Upload Target Photo</h3>
              <p className="text-xs text-white/50 leading-relaxed">
                Choose the original photo or scene with the person whose face you want to replace.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#141414] border border-white/[0.08] space-y-3 relative group hover:border-primary/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center font-black text-sm">
                2
              </div>
              <h3 className="text-base font-bold text-white">Upload Source Face</h3>
              <p className="text-xs text-white/50 leading-relaxed">
                Provide a clear front-facing portrait of the new identity you want inserted into the scene.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#141414] border border-white/[0.08] space-y-3 relative group hover:border-primary/40 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 text-primary flex items-center justify-center font-black text-sm">
                3
              </div>
              <h3 className="text-base font-bold text-white">Instant Swap & Download</h3>
              <p className="text-xs text-white/50 leading-relaxed">
                Our generative pipeline matches lighting, skin tone, and head pose in seconds.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Highlights / FAQ Section */}
      <section className="border-t border-white/[0.06] py-16">
        <div className="max-w-4xl mx-auto px-4 space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-black text-white">Key Features</h2>
            <p className="text-sm text-white/50">Built for creators, marketers, and production studios.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-5 rounded-xl bg-white/[0.02] border border-white/[0.06] flex items-start gap-3.5">
              <div className="p-2 rounded-lg bg-white/5 text-primary shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Identity Preservation</h4>
                <p className="text-xs text-white/50 mt-1">
                  Accurately preserves facial bone structure, eyes, and expressions without artificial smoothing.
                </p>
              </div>
            </div>

            <div className="p-5 rounded-xl bg-white/[0.02] border border-white/[0.06] flex items-start gap-3.5">
              <div className="p-2 rounded-lg bg-white/5 text-primary shrink-0">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Seamless Lighting Blend</h4>
                <p className="text-xs text-white/50 mt-1">
                  Harmonizes shadow direction, color grading, and ambient noise to match the scene.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
