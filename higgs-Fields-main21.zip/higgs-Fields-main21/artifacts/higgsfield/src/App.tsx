import { Component, useEffect, useRef, type ErrorInfo, type ReactNode } from "react";
import { Layout } from "@/components/layout";
import { Route, Switch, useLocation, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ClerkProvider, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { SettingsProvider, useSiteSettings } from "@/lib/settings";
import Home from "@/pages/home";
import Tools from "@/pages/tools";
import ToolDetail from "@/pages/tool-detail";
import CategoryStudio from "@/pages/category-studio";

function ImageStudio() {
  return <CategoryStudio category="image" />;
}
function VideoStudio() {
  return <CategoryStudio category="video" />;
}
function AudioStudio() {
  return <CategoryStudio category="audio" />;
}
import MarketingStudio from "@/pages/marketing-studio";
import Presets from "@/pages/presets";
import Shorts from "@/pages/shorts";
import Apps from "@/pages/apps";
import Pricing from "@/pages/pricing";
import Library from "@/pages/library";
import Account from "@/pages/account";
import ApiKeys from "@/pages/api-keys";
import SignInPage from "@/pages/sign-in";
import SignUpPage from "@/pages/sign-up";
import NotFound from "@/pages/not-found";
import AdminSettings from "@/pages/admin-settings";
import AdminBranding from "@/pages/admin/branding";
import AdminPlatformProviders from "@/pages/admin/platform-providers";
import AdminByokProviders from "@/pages/admin/byok-providers";
import AdminModels from "@/pages/admin/models";
import AdminWorkflows from "@/pages/admin/workflows";
import AdminApps from "@/pages/admin/apps";
import FeatureAppPage from "@/pages/feature-app";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

// REQUIRED — copy verbatim. Resolves the key from window.location.hostname so the
// same build serves multiple Clerk custom domains. Do not inline the env var, leave
// publishableKey undefined, or replace publishableKeyFromHost with anything else.
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

// REQUIRED — copy verbatim. Empty in dev (Clerk hits dev FAPI directly), auto-set
// in prod. Do NOT gate on import.meta.env.PROD / NODE_ENV — the empty dev value
// is intentional, and any branching breaks the prod proxy.
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

// Clerk passes full paths to routerPush/routerReplace, but wouter's
// setLocation prepends the base — strip it to avoid doubling.
function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

if (!clerkPubKey) {
  throw new Error("Missing VITE_CLERK_PUBLISHABLE_KEY in .env file");
}

function buildClerkAppearance(logoUrl: string) {
  return {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}${logoUrl}`,
  },
  variables: {
    colorPrimary: "#CEFF00",
    colorForeground: "#F5F5F5",
    colorMutedForeground: "#A6A6A6",
    colorDanger: "#EF4444",
    colorBackground: "#111111",
    colorInput: "#1C1C1C",
    colorInputForeground: "#F5F5F5",
    colorNeutral: "#2E2E2E",
    fontFamily: "'Inter', sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "bg-[#111111] border border-white/10 rounded-2xl w-[440px] max-w-full overflow-hidden shadow-2xl",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-white text-2xl font-black",
    headerSubtitle: "text-white/60",
    socialButtonsBlockButtonText: "text-white font-medium",
    formFieldLabel: "text-white/80",
    footerActionLink: "text-primary hover:text-primary/80 font-semibold",
    footerActionText: "text-white/50",
    dividerText: "text-white/40",
    identityPreviewEditButton: "text-primary",
    formFieldSuccessText: "text-primary",
    alertText: "text-red-400",
    logoBox: "flex justify-center py-2",
    logoImage: "h-8",
    socialButtonsBlockButton: "border-white/15 bg-white/[0.03] hover:bg-white/[0.08]",
    formButtonPrimary: "bg-primary text-black font-bold hover:bg-primary/90 shadow-[0_0_20px_rgba(206,255,0,0.25)]",
    formFieldInput: "bg-[#1C1C1C] border-white/10 text-white",
    footerAction: "border-t border-white/5 pt-4",
    dividerLine: "bg-white/10",
    alert: "bg-red-500/10 border border-red-500/30",
    otpCodeFieldInput: "bg-[#1C1C1C] border-white/10 text-white",
    formFieldRow: "gap-3",
    main: "gap-5",
  },
  };
}

// Helps user's webview stay up-to-date when the signed-in user changes by invalidating the QueryClient cache.
function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const queryClient = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        queryClient.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, queryClient]);

  return null;
}

function AdminRedirect() {
  const [, nav] = useLocation();
  useEffect(() => { nav("/admin/branding", { replace: true }); }, [nav]);
  return null;
}

class RouteErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("A routed page failed to render", error, info.componentStack);
  }

  render() {
    if (this.state.error) {
      return (
        <main role="alert" className="min-h-[60vh] flex items-center justify-center p-6">
          <div className="max-w-lg rounded-xl border border-red-500/25 bg-red-500/[0.06] p-6 text-white">
            <h1 className="text-lg font-semibold">This page could not be displayed</h1>
            <p className="mt-2 text-sm text-white/65">An unexpected error interrupted this page. Reload to try again.</p>
            <button
              type="button"
              className="mt-5 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-black"
              onClick={() => window.location.reload()}
            >
              Reload page
            </button>
          </div>
        </main>
      );
    }
    return this.props.children;
  }
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/tools" component={Tools} />
      <Route path="/tools/:slug" component={ToolDetail} />
      <Route path="/image" component={ImageStudio} />
      <Route path="/video" component={VideoStudio} />
      <Route path="/audio" component={AudioStudio} />
      <Route path="/marketing-studio" component={MarketingStudio} />
      <Route path="/presets" component={Presets} />
      <Route path="/shorts" component={Shorts} />
      <Route path="/apps" component={Apps} />
      <Route path="/apps/:slug" component={FeatureAppPage} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/library" component={Library} />
      <Route path="/account" component={Account} />
      <Route path="/api-keys" component={ApiKeys} />
      <Route path="/admin" component={AdminRedirect} />
      <Route path="/admin/settings" component={AdminRedirect} />
      <Route path="/admin/branding" component={AdminBranding} />
      <Route path="/admin/providers/platform" component={AdminPlatformProviders} />
      <Route path="/admin/providers/byok" component={AdminByokProviders} />
      <Route path="/admin/models" component={AdminModels} />
      <Route path="/admin/workflows" component={AdminWorkflows} />
      <Route path="/admin/apps" component={AdminApps} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={SignUpPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Clerk's localization strings are static at ClerkProvider construction —
// they can't read from a React context. This tiny wrapper re-renders the
// provider (and therefore Clerk's UI) whenever the database-driven site
// name / default credits change, giving the sign-in/up copy the same
// "instant propagation" as everything else, at the cost of one extra
// component in the tree.
function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  const settings = useSiteSettings();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      appearance={buildClerkAppearance(settings.logo_url)}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "Welcome back",
            subtitle: `Sign in to keep creating with ${settings.site_name}`,
          },
        },
        signUp: {
          start: {
            title: "Create your account",
            subtitle: `Get ${settings.default_credits} free credits to start generating`,
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkQueryClientCacheInvalidator />
        <TooltipProvider>
          <Layout>
          <RouteErrorBoundary>
            <Router />
          </RouteErrorBoundary>
          </Layout>
        <Toaster />
      </TooltipProvider>
    </ClerkProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={basePath}>
        <SettingsProvider>
          <ClerkProviderWithRoutes />
        </SettingsProvider>
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
