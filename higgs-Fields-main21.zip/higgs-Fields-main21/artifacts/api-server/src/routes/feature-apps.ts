import { Router, type IRouter } from "express";
import { and, eq, sql, asc, isNotNull } from "drizzle-orm";
import {
  db,
  featureAppsTable,
  modelsTable,
  generationsTable,
  type FeatureApp,
} from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { requireOwner } from "../middlewares/requireOwner";
import { ObjectStorageService, SIGNED_URL_EXPIRY_SECONDS } from "../lib/objectStorage";
import { executeGenerationPipeline, PipelineError } from "../lib/generation/pipeline";

const router: IRouter = Router();
const objectStorage = new ObjectStorageService();

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Columns exposed to the public — never includes prompt_template, model_id,
 *  image_input_mode, image_field_name, or slot keys. */
function toPublicSummary(app: FeatureApp) {
  return {
    id: app.id,
    slug: app.slug,
    name: app.name,
    menuCategory: app.menuCategory ?? null,
    menuDescription: app.menuDescription,
    iconKey: app.iconKey,
    sortOrder: app.sortOrder,
    heroTitle: app.heroTitle,
    heroSubtitle: app.heroSubtitle,
  };
}

function toPublicDetail(app: FeatureApp, freeUsesRemaining: number | null) {
  return {
    id: app.id,
    slug: app.slug,
    name: app.name,
    menuCategory: app.menuCategory ?? null,
    menuDescription: app.menuDescription,
    iconKey: app.iconKey,
    sortOrder: app.sortOrder,
    isReady: app.modelId !== null && app.creditCost !== null,
    creditCost: app.creditCost ?? null,
    freeUsesPerUser: app.freeUsesPerUser,
    freeUsesRemaining,
    heroTitle: app.heroTitle,
    heroSubtitle: app.heroSubtitle,
    slot1: { label: app.slot1Label, help: app.slot1Help },
    slot2: { label: app.slot2Label, help: app.slot2Help },
    showcaseImageUrl: app.showcaseImageUrl ?? null,
    showcaseInsetUrl: app.showcaseInsetUrl ?? null,
  };
}

function toAdminFeatureApp(app: FeatureApp) {
  return {
    id: app.id,
    slug: app.slug,
    name: app.name,
    menuCategory: app.menuCategory ?? null,
    menuDescription: app.menuDescription,
    iconKey: app.iconKey,
    isActive: app.isActive,
    sortOrder: app.sortOrder,
    modelId: app.modelId ?? null,
    promptTemplate: app.promptTemplate,
    freeUsesPerUser: app.freeUsesPerUser,
    creditCost: app.creditCost ?? null,
    heroTitle: app.heroTitle,
    heroSubtitle: app.heroSubtitle,
    slot1Key: app.slot1Key,
    slot1Label: app.slot1Label,
    slot1Help: app.slot1Help,
    slot2Key: app.slot2Key,
    slot2Label: app.slot2Label,
    slot2Help: app.slot2Help,
    showcaseImageUrl: app.showcaseImageUrl ?? null,
    showcaseInsetUrl: app.showcaseInsetUrl ?? null,
    imageInputMode: app.imageInputMode,
    imageFieldName: app.imageFieldName,
    createdAt: app.createdAt,
    updatedAt: app.updatedAt,
  };
}

// ── GET /feature-apps ─────────────────────────────────────────────────────────
// Returns active, ready feature apps (modelId + creditCost both non-null).
// Filtered by menuCategory if provided. Never returns sensitive admin fields.
router.get("/feature-apps", async (req, res): Promise<void> => {
  const { menuCategory } = req.query as { menuCategory?: string };

  const conditions = [
    eq(featureAppsTable.isActive, true),
    isNotNull(featureAppsTable.modelId),
    isNotNull(featureAppsTable.creditCost),
  ];
  if (menuCategory === "image" || menuCategory === "video" || menuCategory === "audio") {
    conditions.push(eq(featureAppsTable.menuCategory, menuCategory));
  }

  const apps = await db
    .select()
    .from(featureAppsTable)
    .where(and(...conditions))
    .orderBy(asc(featureAppsTable.sortOrder), asc(featureAppsTable.id));

  res.json(apps.map(toPublicSummary));
});

// ── GET /feature-apps/:slug ───────────────────────────────────────────────────
// Returns app detail. For authenticated users, includes freeUsesRemaining.
router.get("/feature-apps/:slug", async (req, res): Promise<void> => {
  const slug = Array.isArray(req.params.slug) ? req.params.slug[0] : req.params.slug;

  const [app] = await db
    .select()
    .from(featureAppsTable)
    .where(and(eq(featureAppsTable.slug, slug), eq(featureAppsTable.isActive, true)));

  if (!app) {
    res.status(404).json({ error: "Feature app not found" });
    return;
  }

  let freeUsesRemaining: number | null = null;
  const userId = req.appUser?.id;
  if (userId !== undefined && app.freeUsesPerUser > 0) {
    const [row] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(generationsTable)
      .where(
        and(
          eq(generationsTable.userId, userId),
          eq(generationsTable.featureAppId, app.id),
          sql`${generationsTable.status} != 'failed'`,
        ),
      );
    const used = row?.count ?? 0;
    freeUsesRemaining = Math.max(0, app.freeUsesPerUser - used);
  }

  res.json(toPublicDetail(app, freeUsesRemaining));
});

// ── POST /feature-apps/:slug/run ──────────────────────────────────────────────
// Submits a generation for a feature app.  Auth required.
router.post("/feature-apps/:slug/run", requireAuth, async (req, res): Promise<void> => {
  const slug = Array.isArray(req.params.slug) ? req.params.slug[0] : req.params.slug;
  const user = req.appUser!;

  // --- 1. Parse body ---
  const { targetImagePath, faceImagePath } = req.body as {
    targetImagePath?: string;
    faceImagePath?: string;
  };
  if (typeof targetImagePath !== "string" || !targetImagePath.trim()) {
    res.status(400).json({ error: "targetImagePath is required" });
    return;
  }
  if (typeof faceImagePath !== "string" || !faceImagePath.trim()) {
    res.status(400).json({ error: "faceImagePath is required" });
    return;
  }

  // --- 2. Verify image ownership ---
  // Both paths must have been uploaded by the signed-in user.
  // The upload route scopes paths to uploads/<userId>/... so we can check
  // the prefix without a DB query.
  const ownsTarget = objectStorage.isUserUploadedObject(targetImagePath, user.id);
  const ownsFace = objectStorage.isUserUploadedObject(faceImagePath, user.id);
  if (!ownsTarget || !ownsFace) {
    res.status(403).json({
      error: "One or both image paths were not uploaded by the current user.",
    });
    return;
  }

  // --- 3. Load feature app ---
  const [app] = await db
    .select()
    .from(featureAppsTable)
    .where(and(eq(featureAppsTable.slug, slug), eq(featureAppsTable.isActive, true)));

  if (!app) {
    res.status(404).json({ error: "Feature app not found" });
    return;
  }

  // --- 4. "Not ready" guard ---
  if (app.modelId === null) {
    res.status(400).json({ error: "This feature app is not ready yet: no model is configured." });
    return;
  }
  if (app.creditCost === null) {
    res.status(400).json({
      error: "This feature app is not ready yet: credit cost has not been set by the administrator.",
    });
    return;
  }

  // --- 5. Load model ---
  const [model] = await db
    .select()
    .from(modelsTable)
    .where(and(eq(modelsTable.id, app.modelId), eq(modelsTable.isActive, true)));

  if (!model) {
    res.status(400).json({ error: "The configured model is unavailable." });
    return;
  }

  // --- 6. Resolve signed URLs for both images (external providers cannot reach /objects/...) ---
  let signedTarget: string;
  let signedFace: string;
  try {
    [signedTarget, signedFace] = await Promise.all([
      objectStorage.getObjectEntitySignedURL(targetImagePath, SIGNED_URL_EXPIRY_SECONDS),
      objectStorage.getObjectEntitySignedURL(faceImagePath, SIGNED_URL_EXPIRY_SECONDS),
    ]);
  } catch (err) {
    req.log.error({ err }, "Failed to generate signed URLs for feature-app images");
    res.status(500).json({ error: "Failed to resolve image URLs. Please try again." });
    return;
  }

  // --- 7. Build provider params ---
  let imageParams: Record<string, unknown>;
  if (model.executionConfig) {
    // Configured workflow inputs are positional; the adapter applies its own
    // provider-specific node and field mappings.
    imageParams = { orderedInputs: [signedTarget, signedFace] };
  } else if (app.imageInputMode === "separate") {
    // Separate fields mode: slot1Key → target, slot2Key → face
    imageParams = {
      [app.slot1Key]: signedTarget,
      [app.slot2Key]: signedFace,
    };
  } else {
    // Array mode (default): imageFieldName → [target, face]
    imageParams = {
      [app.imageFieldName]: [signedTarget, signedFace],
    };
  }

  // --- 8. Run the shared generation pipeline ---
  let generation: Awaited<ReturnType<typeof executeGenerationPipeline>>;
  try {
    generation = await executeGenerationPipeline({
      userId: user.id,
      model,
      prompt: app.promptTemplate,
      params: imageParams,
      useOwnKey: false,
      featureAppId: app.id,
      creditCost: app.creditCost,
      log: req.log,
    });
  } catch (err) {
    if (err instanceof PipelineError) {
      res.status(err.statusCode).json({ error: err.message });
    } else {
      req.log.error({ err }, "Unexpected error in feature-app pipeline");
      res.status(500).json({ error: "Internal server error" });
    }
    return;
  }

  res.status(201).json({
    generationId: generation.id,
    status: generation.status,
    creditsCharged: generation.creditsCharged,
  });
});

// ── GET /admin/feature-apps ───────────────────────────────────────────────────
router.get("/admin/feature-apps", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const apps = await db
    .select()
    .from(featureAppsTable)
    .orderBy(asc(featureAppsTable.sortOrder), asc(featureAppsTable.id));
  res.json(apps.map(toAdminFeatureApp));
});

// ── GET /admin/feature-apps/:id ───────────────────────────────────────────────
router.get("/admin/feature-apps/:id", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "id must be an integer" });
    return;
  }
  const [app] = await db.select().from(featureAppsTable).where(eq(featureAppsTable.id, id));
  if (!app) {
    res.status(404).json({ error: "Feature app not found" });
    return;
  }
  res.json(toAdminFeatureApp(app));
});

// ── PATCH /admin/feature-apps/:id ─────────────────────────────────────────────
// Explicit allow-list. Unknown fields are silently ignored.
// imageInputMode is validated to "array" | "separate".
// imageFieldName and slot keys are validated as non-empty strings.
router.patch("/admin/feature-apps/:id", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(rawId, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "id must be an integer" });
    return;
  }

  const [existing] = await db.select().from(featureAppsTable).where(eq(featureAppsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Feature app not found" });
    return;
  }

  const body = req.body as Record<string, unknown>;
  const patch: Partial<typeof featureAppsTable.$inferInsert> = {};

  if (typeof body.name === "string" && body.name.trim().length > 0) {
    patch.name = body.name.trim();
  }
  if (body.menuCategory === null || (typeof body.menuCategory === "string" && ["image", "video", "audio"].includes(body.menuCategory))) {
    patch.menuCategory = body.menuCategory as string | null;
  }
  if (typeof body.menuDescription === "string") {
    patch.menuDescription = body.menuDescription;
  }
  if (typeof body.iconKey === "string" && body.iconKey.trim().length > 0) {
    patch.iconKey = body.iconKey.trim();
  }
  if (typeof body.isActive === "boolean") {
    patch.isActive = body.isActive;
  }
  if (typeof body.sortOrder === "number" && Number.isInteger(body.sortOrder) && body.sortOrder >= 0) {
    patch.sortOrder = body.sortOrder;
  }
  if (body.modelId === null || (typeof body.modelId === "number" && Number.isInteger(body.modelId) && body.modelId > 0)) {
    patch.modelId = body.modelId as number | null;
  }
  if (typeof body.promptTemplate === "string") {
    patch.promptTemplate = body.promptTemplate;
  }
  if (typeof body.freeUsesPerUser === "number" && Number.isInteger(body.freeUsesPerUser) && body.freeUsesPerUser >= 0) {
    patch.freeUsesPerUser = body.freeUsesPerUser;
  }
  if (body.creditCost === null || (typeof body.creditCost === "number" && Number.isInteger(body.creditCost) && body.creditCost >= 0)) {
    patch.creditCost = body.creditCost as number | null;
  }
  if (typeof body.heroTitle === "string" && body.heroTitle.trim().length > 0) {
    patch.heroTitle = body.heroTitle.trim();
  }
  if (typeof body.heroSubtitle === "string") {
    patch.heroSubtitle = body.heroSubtitle;
  }
  if (typeof body.slot1Key === "string" && body.slot1Key.trim().length > 0) {
    patch.slot1Key = body.slot1Key.trim();
  }
  if (typeof body.slot1Label === "string" && body.slot1Label.trim().length > 0) {
    patch.slot1Label = body.slot1Label.trim();
  }
  if (typeof body.slot1Help === "string") {
    patch.slot1Help = body.slot1Help;
  }
  if (typeof body.slot2Key === "string" && body.slot2Key.trim().length > 0) {
    patch.slot2Key = body.slot2Key.trim();
  }
  if (typeof body.slot2Label === "string" && body.slot2Label.trim().length > 0) {
    patch.slot2Label = body.slot2Label.trim();
  }
  if (typeof body.slot2Help === "string") {
    patch.slot2Help = body.slot2Help;
  }
  if (body.showcaseImageUrl === null || typeof body.showcaseImageUrl === "string") {
    patch.showcaseImageUrl = body.showcaseImageUrl as string | null;
  }
  if (body.showcaseInsetUrl === null || typeof body.showcaseInsetUrl === "string") {
    patch.showcaseInsetUrl = body.showcaseInsetUrl as string | null;
  }
  // Validated enum: must be "array" or "separate"
  if (body.imageInputMode === "array" || body.imageInputMode === "separate") {
    patch.imageInputMode = body.imageInputMode;
  }
  // imageFieldName must be a non-empty string
  if (typeof body.imageFieldName === "string" && body.imageFieldName.trim().length > 0) {
    patch.imageFieldName = body.imageFieldName.trim();
  }

  if (Object.keys(patch).length === 0) {
    res.status(400).json({ error: "No valid fields to update" });
    return;
  }

  // PATCH must always set updatedAt
  patch.updatedAt = new Date();

  const [updated] = await db
    .update(featureAppsTable)
    .set(patch)
    .where(eq(featureAppsTable.id, id))
    .returning();

  res.json(toAdminFeatureApp(updated));
});

export default router;
