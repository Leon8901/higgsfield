import { Router, type IRouter } from "express";
import { and, asc, eq, inArray, notInArray } from "drizzle-orm";
import { db, modelsTable, featureAppsTable, providersTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { requireOwner } from "../middlewares/requireOwner";
import { importAssetFromUrl } from "../lib/media/assetImport";
import { decryptSecret } from "../lib/crypto";
import { fetchProviderCatalog, catalogSlugify } from "../lib/media/catalogSync";

const router: IRouter = Router();

// ── Allowed badge values ───────────────────────────────────────────────────────
const ALLOWED_BADGES = new Set(["NEW", "TRENDING", "HOT", "TOP"]);

// ── Response shape ─────────────────────────────────────────────────────────────
function toAdminModel(m: typeof modelsTable.$inferSelect) {
  return {
    id: m.id,
    modelId: m.modelId,
    name: m.name,
    category: m.category,
    description: m.description,
    badge: m.badge ?? null,
    thumbnailUrl: m.thumbnailUrl ?? null,
    isFeatured: m.isFeatured,
    sortOrder: m.sortOrder,
    showInCatalog: m.showInCatalog,
    isActive: m.isActive,
    adapter: m.adapter,
    providerModelPath: m.providerModelPath,
    executionConfig: m.executionConfig ?? null,
    basePriceUsd: m.basePriceUsd,
    creditCost: m.creditCost,
    providerBasePriceUsd: m.providerBasePriceUsd ?? null,
    isSynced: m.isSynced,
    isDelisted: m.isDelisted,
    delistedAt: m.delistedAt?.toISOString() ?? null,
    lastSyncedAt: m.lastSyncedAt?.toISOString() ?? null,
    pendingSchemaUpdate: m.pendingSchemaUpdate ?? null,
    createdAt: m.createdAt,
    updatedAt: m.updatedAt,
  };
}

// ── GET /admin/models ─────────────────────────────────────────────────────────
// Returns every row from models with all catalog columns including thumbnailUrl.
router.get("/admin/models", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const models = await db
    .select()
    .from(modelsTable)
    .orderBy(asc(modelsTable.sortOrder), asc(modelsTable.id));
  res.json(models.map(toAdminModel));
});

// ── PATCH /admin/models/:modelId ──────────────────────────────────────────────
// Updates editable fields via an explicit allow-list — same pattern as the
// providers PATCH and settings update. Unknown fields are silently ignored;
// invalid values (wrong type, out-of-range) return 400.
router.patch("/admin/models/:modelId", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const modelId = Array.isArray(req.params.modelId) ? req.params.modelId[0] : req.params.modelId;
  const [model] = await db
    .select()
    .from(modelsTable)
    .where(eq(modelsTable.modelId, modelId));
  if (!model) {
    res.status(404).json({ error: `Model "${modelId}" not found` });
    return;
  }

  const body = req.body as Record<string, unknown>;
  const patch: Partial<typeof modelsTable.$inferInsert> = {};

  if (body.thumbnailUrl === null || typeof body.thumbnailUrl === "string") {
    patch.thumbnailUrl = body.thumbnailUrl as string | null;
  }
  if (typeof body.isActive === "boolean") {
    patch.isActive = body.isActive;
  }
  if (typeof body.showInCatalog === "boolean") {
    patch.showInCatalog = body.showInCatalog;
  }
  if (typeof body.isFeatured === "boolean") {
    patch.isFeatured = body.isFeatured;
  }
  if (typeof body.name === "string" && body.name.trim().length > 0) {
    patch.name = body.name.trim();
  }
  if (typeof body.description === "string") {
    patch.description = body.description;
  }
  if (body.badge === null || (typeof body.badge === "string" && ALLOWED_BADGES.has(body.badge))) {
    patch.badge = body.badge as string | null;
  }
  if (typeof body.sortOrder === "number" && Number.isInteger(body.sortOrder) && body.sortOrder >= 0) {
    patch.sortOrder = body.sortOrder;
  }
  if (typeof body.creditCost === "number" && Number.isInteger(body.creditCost) && body.creditCost >= 0) {
    patch.creditCost = body.creditCost;
  }

  if (Object.keys(patch).length === 0) {
    res.status(400).json({ error: "No valid fields to update" });
    return;
  }

  const [updated] = await db
    .update(modelsTable)
    .set(patch)
    .where(eq(modelsTable.modelId, modelId))
    .returning();

  res.json(toAdminModel(updated));
});

// ── POST /admin/models/:modelId/thumbnail ─────────────────────────────────────
// Paste-URL path: fetches a public URL, validates it's a real image (type +
// size), re-hosts it via the shared assetImport utility (third consumer after
// branding and provider icons), and saves the owned /api/storage/… path.
// File-upload path: client uses POST /storage/uploads/request-url to get a
// presigned PUT URL, uploads directly, then calls PATCH /admin/models/:modelId
// with { thumbnailUrl: "/api/storage…" } — no additional endpoint needed.
router.post(
  "/admin/models/:modelId/thumbnail",
  requireAuth,
  requireOwner,
  async (req, res): Promise<void> => {
    const modelId = Array.isArray(req.params.modelId) ? req.params.modelId[0] : req.params.modelId;
    const [model] = await db
      .select()
      .from(modelsTable)
      .where(eq(modelsTable.modelId, modelId));
    if (!model) {
      res.status(404).json({ error: `Model "${modelId}" not found` });
      return;
    }

    const { url } = req.body as { url?: string };
    if (typeof url !== "string" || !url.trim()) {
      res.status(400).json({ error: "url is required" });
      return;
    }

    let thumbnailPath: string;
    try {
      thumbnailPath = await importAssetFromUrl(url.trim());
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : "Asset import failed",
      });
      return;
    }

    const [updated] = await db
      .update(modelsTable)
      .set({ thumbnailUrl: thumbnailPath })
      .where(eq(modelsTable.modelId, modelId))
      .returning();

    res.json(toAdminModel(updated));
  },
);

// ── Helper: load and decrypt the platform API key for a provider ───────────────

async function getProviderKey(
  providerSlug: string,
): Promise<{ apiKey: string } | { error: string; status: number }> {
  const [provider] = await db
    .select({
      encryptedPlatformKey: providersTable.encryptedPlatformKey,
      platformEnabled: providersTable.platformEnabled,
      platformKeyStatus: providersTable.platformKeyStatus,
    })
    .from(providersTable)
    .where(eq(providersTable.slug, providerSlug));

  if (!provider) {
    return { error: `Provider "${providerSlug}" not found`, status: 404 };
  }
  if (!provider.encryptedPlatformKey) {
    return { error: `No platform API key configured for provider "${providerSlug}". Add one in Admin → Providers.`, status: 422 };
  }
  if (provider.platformKeyStatus !== "valid") {
    return { error: `Platform API key for "${providerSlug}" has not been verified. Validate it in Admin → Providers first.`, status: 422 };
  }

  let apiKey: string;
  try {
    apiKey = decryptSecret(provider.encryptedPlatformKey);
  } catch {
    return { error: "Failed to decrypt platform API key.", status: 500 };
  }

  return { apiKey };
}

// ── GET /admin/catalog/:providerSlug ─────────────────────────────────────────
// Returns the provider's live model catalog without making any DB changes.
// Each entry is annotated with `inLibrary: true / false` and, if true, the
// local model's id and modelId, so the frontend can distinguish "Add" vs "Edit".
router.get(
  "/admin/catalog/:providerSlug",
  requireAuth,
  requireOwner,
  async (req, res): Promise<void> => {
    const providerSlug = String(req.params.providerSlug);

    const keyResult = await getProviderKey(providerSlug);
    if ("error" in keyResult) {
      res.status(keyResult.status).json({ error: keyResult.error });
      return;
    }

    let entries;
    try {
      entries = await fetchProviderCatalog(providerSlug, keyResult.apiKey);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : "Provider catalog request failed",
      });
      return;
    }

    // Look up which provider model paths are already in our DB
    const paths = entries.map((e) => e.providerModelPath);
    const existing = await db
      .select({ id: modelsTable.id, modelId: modelsTable.modelId, providerModelPath: modelsTable.providerModelPath })
      .from(modelsTable)
      .where(inArray(modelsTable.providerModelPath, paths));

    const existingByPath = new Map(existing.map((m) => [m.providerModelPath, m]));

    const result = entries.map((e) => {
      const lib = existingByPath.get(e.providerModelPath);
      return {
        providerModelPath: e.providerModelPath,
        name: e.name,
        description: e.description,
        category: e.category,
        providerBasePriceUsd: e.providerBasePriceUsd,
        paramsSchema: e.paramsSchema,
        inLibrary: !!lib,
        libraryId: lib?.id ?? null,
        libraryModelId: lib?.modelId ?? null,
      };
    });

    res.json(result);
  },
);

// ── POST /admin/models/add-from-catalog ───────────────────────────────────────
// Inserts one model from the provider's live catalog.
// Guarantees: isActive = false, creditCost = null (per hard rule: human sets
// price before activation). Returns 409 if the providerModelPath is already
// in the DB.
router.post(
  "/admin/models/add-from-catalog",
  requireAuth,
  requireOwner,
  async (req, res): Promise<void> => {
    const { providerSlug, providerModelPath, category } = req.body as {
      providerSlug?: string;
      providerModelPath?: string;
      category?: string;
    };

    if (!providerSlug || typeof providerSlug !== "string") {
      res.status(400).json({ error: "providerSlug is required" });
      return;
    }
    if (!providerModelPath || typeof providerModelPath !== "string") {
      res.status(400).json({ error: "providerModelPath is required" });
      return;
    }

    // Check if already in library
    const [existing] = await db
      .select({ id: modelsTable.id, modelId: modelsTable.modelId })
      .from(modelsTable)
      .where(eq(modelsTable.providerModelPath, providerModelPath));

    if (existing) {
      res.status(409).json({
        error: `This model is already in your library as "${existing.modelId}".`,
        existingModelId: existing.modelId,
      });
      return;
    }

    const keyResult = await getProviderKey(providerSlug);
    if ("error" in keyResult) {
      res.status(keyResult.status).json({ error: keyResult.error });
      return;
    }

    let entries;
    try {
      entries = await fetchProviderCatalog(providerSlug, keyResult.apiKey);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : "Provider catalog request failed",
      });
      return;
    }

    const entry = entries.find((e) => e.providerModelPath === providerModelPath);
    if (!entry) {
      res.status(404).json({
        error: `Model "${providerModelPath}" was not found in the live catalog for "${providerSlug}".`,
      });
      return;
    }

    const normalizedCategory =
      category === "video" || category === "audio" ? category : entry.category;

    const modelId = catalogSlugify(providerModelPath);
    const now = new Date();

    const [inserted] = await db
      .insert(modelsTable)
      .values({
        modelId,
        name: entry.name,
        category: normalizedCategory,
        description: entry.description,
        adapter: providerSlug,
        providerModelPath: entry.providerModelPath,
        basePriceUsd: entry.providerBasePriceUsd,
        creditCost: null,           // Human decision — must be set before activation
        paramsSchema: entry.paramsSchema,
        rawSchema: entry.rawSchema as Record<string, unknown> | null,
        providerBasePriceUsd: entry.providerBasePriceUsd,
        isSynced: true,
        isDelisted: false,
        isActive: false,            // Always inactive until admin enables it
        lastSyncedAt: now,
        updatedAt: now,
      })
      .returning();

    res.status(201).json(toAdminModel(inserted));
  },
);

// ── POST /admin/models/sync/:providerSlug ────────────────────────────────────
// Syncs all models in the library that belong to this provider against the
// live catalog.
//
// WHAT IT NEVER TOUCHES (Hard Rules 4 & 5):
//   isActive, creditCost, sortOrder, thumbnailUrl, badge, name, isFeatured
//   — those are human decisions layered on top of the provider's raw data.
//
// WHAT IT DOES:
//   - Updates providerBasePriceUsd, lastSyncedAt, updatedAt for still-live models.
//   - Updates rawSchema.
//   - For models NOT in use by any feature_app: also updates paramsSchema.
//   - For models IN USE by a feature_app where paramsSchema differs:
//       stores incoming paramsSchema in pendingSchemaUpdate for human review.
//   - Models that vanish from the catalog: sets isDelisted=true, delistedAt=now.
//   - Models that reappear: clears isDelisted, delistedAt=null.
//
// Returns a summary: { synced, delisted, pendingReview, unchanged }.
router.post(
  "/admin/models/sync/:providerSlug",
  requireAuth,
  requireOwner,
  async (req, res): Promise<void> => {
    const providerSlug = String(req.params.providerSlug);

    const keyResult = await getProviderKey(providerSlug);
    if ("error" in keyResult) {
      res.status(keyResult.status).json({ error: keyResult.error });
      return;
    }

    let catalogEntries;
    try {
      catalogEntries = await fetchProviderCatalog(providerSlug, keyResult.apiKey);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : "Provider catalog request failed",
      });
      return;
    }

    // Load all DB models for this provider
    const dbModels = await db
      .select()
      .from(modelsTable)
      .where(eq(modelsTable.adapter, providerSlug));

    if (dbModels.length === 0) {
      res.json({ synced: 0, delisted: 0, pendingReview: [], unchanged: 0, message: `No models found in library for provider "${providerSlug}".` });
      return;
    }

    // Find feature_app model_ids to know which models are "in use"
    const dbModelIds = dbModels.map((m) => m.id);
    const usedByFeatureApp = await db
      .select({ modelId: featureAppsTable.modelId })
      .from(featureAppsTable)
      .where(
        and(
          inArray(featureAppsTable.modelId, dbModelIds),
        ),
      );
    const usedModelIds = new Set(usedByFeatureApp.map((r) => r.modelId).filter((id): id is number => id !== null));

    const catalogByPath = new Map(catalogEntries.map((e) => [e.providerModelPath, e]));
    const livePaths = new Set(catalogEntries.map((e) => e.providerModelPath));

    const now = new Date();
    let synced = 0;
    let delisted = 0;
    let unchanged = 0;
    const pendingReview: { modelId: string; name: string }[] = [];

    for (const model of dbModels) {
      const liveEntry = catalogByPath.get(model.providerModelPath);

      if (!liveEntry) {
        // Model no longer in live catalog — flag as delisted (never delete)
        if (!model.isDelisted) {
          await db
            .update(modelsTable)
            .set({ isDelisted: true, delistedAt: now, updatedAt: now })
            .where(eq(modelsTable.id, model.id));
          delisted++;
        } else {
          unchanged++;
        }
        continue;
      }

      // Model is live — clear any delisting state
      const patch: Partial<typeof modelsTable.$inferInsert> = {
        isDelisted: false,
        delistedAt: null,
        providerBasePriceUsd: liveEntry.providerBasePriceUsd,
        rawSchema: liveEntry.rawSchema as Record<string, unknown> | null,
        isSynced: true,
        lastSyncedAt: now,
        updatedAt: now,
      };

      const incomingSchema = JSON.stringify(liveEntry.paramsSchema);
      const currentSchema = JSON.stringify(model.paramsSchema);
      const schemaChanged = incomingSchema !== currentSchema;

      if (!schemaChanged) {
        // Schema unchanged — just update sync metadata
        await db.update(modelsTable).set(patch).where(eq(modelsTable.id, model.id));
        synced++;
        continue;
      }

      if (usedModelIds.has(model.id)) {
        // Model is in use by a feature app — do NOT silently overwrite paramsSchema
        // Store the incoming schema for human review via approve-schema endpoint
        await db
          .update(modelsTable)
          .set({ ...patch, pendingSchemaUpdate: liveEntry.paramsSchema })
          .where(eq(modelsTable.id, model.id));
        pendingReview.push({ modelId: model.modelId, name: model.name });
        synced++;
      } else {
        // Model not in use — safe to update paramsSchema directly
        await db
          .update(modelsTable)
          .set({ ...patch, paramsSchema: liveEntry.paramsSchema })
          .where(eq(modelsTable.id, model.id));
        synced++;
      }
    }

    res.json({ synced, delisted, pendingReview, unchanged });
  },
);

// ── POST /admin/models/:modelId/approve-schema ───────────────────────────────
// Resolves a pending schema diff for a model that was in use by a feature app.
// action = "approve": overwrites paramsSchema with pendingSchemaUpdate
// action = "dismiss": discards pendingSchemaUpdate, keeps current paramsSchema
//
// Both actions ALWAYS clear pendingSchemaUpdate (set to null) — a decision,
// once made, is never left stale.
router.post(
  "/admin/models/:modelId/approve-schema",
  requireAuth,
  requireOwner,
  async (req, res): Promise<void> => {
    const modelId = String(req.params.modelId);
    const { action } = req.body as { action?: string };

    if (action !== "approve" && action !== "dismiss") {
      res.status(400).json({ error: "action must be \"approve\" or \"dismiss\"" });
      return;
    }

    const [model] = await db
      .select()
      .from(modelsTable)
      .where(eq(modelsTable.modelId, modelId));

    if (!model) {
      res.status(404).json({ error: `Model "${modelId}" not found` });
      return;
    }

    if (!model.pendingSchemaUpdate) {
      res.status(409).json({ error: `Model "${modelId}" has no pending schema update to resolve.` });
      return;
    }

    const now = new Date();

    if (action === "approve") {
      // Apply the pending schema update, then clear it
      await db
        .update(modelsTable)
        .set({
          paramsSchema: model.pendingSchemaUpdate,
          pendingSchemaUpdate: null,
          updatedAt: now,
        })
        .where(eq(modelsTable.id, model.id));
    } else {
      // Dismiss: discard the incoming schema, keep current — clear pendingSchemaUpdate
      await db
        .update(modelsTable)
        .set({ pendingSchemaUpdate: null, updatedAt: now })
        .where(eq(modelsTable.id, model.id));
    }

    const [updated] = await db.select().from(modelsTable).where(eq(modelsTable.id, model.id));
    res.json(toAdminModel(updated));
  },
);

export default router;
