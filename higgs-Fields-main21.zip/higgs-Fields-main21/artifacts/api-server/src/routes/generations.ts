import { Router, type IRouter } from "express";
import { desc, eq, and } from "drizzle-orm";
import { db, generationsTable, modelsTable, usersTable, creditLedgerTable, type Model } from "@workspace/db";
import {
  CreateGenerationBody,
  CreateGenerationResponse,
  ListGenerationsResponse,
  GetGenerationParams,
  GetGenerationResponse,
  DeleteGenerationParams,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { generationsRateLimit } from "../middlewares/rateLimit";
import { getAdapter } from "../lib/media/registry";
import { ProviderError } from "../lib/media/types";
import { enhancePrompt, autoSelectModel } from "../lib/llm/planner";
import { resolveGenerationKey } from "../lib/generation/keyRouting";
import { computeCreditsCharged } from "../lib/generation/pricing";
import { syncGenerationStatus, finalizeGeneration } from "../lib/generation/statusSync";

// User-safe copy for a provider-side failure when we're using the *platform*
// key. Never includes `providerMessage` (WaveSpeed account/billing details,
// raw validation text) — that's for logs only, since the end user has no
// account/key of their own to fix here.
const GENERATION_UNAVAILABLE_MESSAGE = "Generation temporarily unavailable — please try again later.";

// When the caller used their own BYOK key, *any* provider failure is about
// that user's own account/key/plan (there's no shared platform secret to
// protect) — e.g. ElevenLabs: "The API key you used is missing the
// permission voices_read" (a restricted-key scope issue) or "Free users
// cannot use library voices via the API" (a plan restriction). Both of these
// come back with ElevenLabs' generic 401 status, which classifyError() buckets
// as "unknown" — so gating on `kind === "validation"` alone hid exactly the
// messages BYOK users most need to see. Surface the provider's own message
// for every kind when it's a BYOK generation; only platform-key failures
// (WaveSpeed account/billing internals) stay on the generic message, since
// the user has no account of their own to fix there.
function userFacingErrorMessage(err: unknown, usedOwnKey: boolean): string {
  if (err instanceof ProviderError && usedOwnKey) {
    return err.providerMessage;
  }
  return GENERATION_UNAVAILABLE_MESSAGE;
}

const router: IRouter = Router();

function toGenerationResponse(row: typeof generationsTable.$inferSelect, model: Model) {
  return {
    id: row.id,
    modelId: model.modelId,
    modelName: model.name,
    category: model.category,
    prompt: row.prompt,
    params: row.params,
    status: row.status,
    outputType: row.outputType,
    outputUrls: row.outputUrls,
    creditsCharged: row.creditsCharged,
    usedOwnKey: row.usedOwnKey,
    errorMessage: row.errorMessage,
    createdAt: row.createdAt,
    completedAt: row.completedAt,
  };
}

router.get("/generations", requireAuth, async (req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(generationsTable)
    .innerJoin(modelsTable, eq(generationsTable.modelId, modelsTable.id))
    .where(eq(generationsTable.userId, req.appUser!.id))
    .orderBy(desc(generationsTable.createdAt));

  const results = rows.map((r) => toGenerationResponse(r.generations, r.models));
  res.json(ListGenerationsResponse.parse(results));
});

router.post("/generations", requireAuth, generationsRateLimit(), async (req, res): Promise<void> => {
  const body = CreateGenerationBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  const { modelId, prompt, params, autoSelect, useOwnKey, skipEnhance } = body.data;

  const allModels = await db.select().from(modelsTable);
  if (allModels.length === 0) {
    res.status(400).json({ error: "No models are configured." });
    return;
  }

  let model: Model | undefined;
  if (autoSelect || !modelId) {
    try {
      const picked = await autoSelectModel(prompt, allModels);
      model = allModels.find((m) => m.modelId === picked.modelId);
    } catch (err) {
      req.log.error({ err }, "Auto model selection failed");
      res.status(400).json({ error: "Could not auto-select a model. Please choose one explicitly." });
      return;
    }
  } else {
    model = allModels.find((m) => m.modelId === modelId);
  }

  if (!model) {
    res.status(400).json({ error: "Unknown model." });
    return;
  }

  const user = req.appUser!;

  // Routing ("which key?") and billing ("what does it cost?") are resolved
  // by separate, independently swappable helpers — see lib/generation/.
  const { apiKey, usedOwnKey, rejected } = await resolveGenerationKey(user.id, model, useOwnKey);

  if (rejected) {
    res.status(403).json({ error: rejected.reason });
    return;
  }

  if (model.creditCost === null) {
    res.status(400).json({ error: "This model is not ready yet: credit cost has not been set." });
    return;
  }

  if (!usedOwnKey && user.creditsBalance < model.creditCost) {
    res.status(402).json({ error: "Insufficient credits. Upgrade your plan or add your own API key." });
    return;
  }

  if (!apiKey) {
    res.status(500).json({ error: "No API key available to submit this generation." });
    return;
  }

  const finalPrompt = skipEnhance ? prompt : await enhancePrompt(prompt, model.category);
  const providerParams = { prompt: finalPrompt, ...(params ?? {}) };

  const adapter = getAdapter(model.adapter);
  let submitted: Awaited<ReturnType<typeof adapter.submit>>;
  try {
    submitted = await adapter.submit(model.providerModelPath, providerParams, apiKey, { executionConfig: model.executionConfig });
  } catch (err) {
    if (err instanceof ProviderError) {
      // Full detail (which provider, which model, capacity vs validation,
      // and the raw provider message) goes to server logs only — grep for
      // `"kind":"capacity"` to find provider account/billing issues, or
      // `"kind":"validation"` to find a model's paramsSchema drifting from
      // what the provider actually accepts.
      req.log.error(
        { adapter: model.adapter, modelId: model.modelId, kind: err.kind, providerMessage: err.providerMessage },
        "Provider submit failed",
      );
    } else {
      req.log.error({ err }, "Provider submit failed (unexpected error shape)");
    }
    res.status(502).json({ error: userFacingErrorMessage(err, usedOwnKey) });
    return;
  }

  const creditsCharged = computeCreditsCharged(usedOwnKey, model);

  // Insert the generation row. For async adapters (WaveSpeed, Kling) we store
  // the opaque provider job ID so the poller can call poll() later. For sync
  // adapters (OpenAI, ElevenLabs) submit() already returned the completed
  // result — no job ID exists, so providerTaskId stays null and the poller
  // will skip this row entirely (guard: !generation.providerTaskId).
  const [generation] = await db
    .insert(generationsTable)
    .values({
      userId: user.id,
      modelId: model.id,
      prompt: finalPrompt,
      params: providerParams,
      status: "processing",
      outputType: model.category,
      outputUrls: [],
      creditsCharged,
      usedOwnKey,
      providerTaskId: submitted.kind === "async" ? submitted.providerTaskId : null,
    })
    .returning();

  if (creditsCharged > 0) {
    const newBalance = user.creditsBalance - creditsCharged;
    await db.update(usersTable).set({ creditsBalance: newBalance }).where(eq(usersTable.id, user.id));
    await db.insert(creditLedgerTable).values({
      userId: user.id,
      delta: -creditsCharged,
      reason: "generation",
      balanceAfter: newBalance,
      generationId: generation.id,
    });
  }

  // Sync adapters: finalise immediately using the same finalizeGeneration()
  // function the background poller uses for async adapters. Both paths share
  // identical completion bookkeeping — asset persistence, DB write, completedAt,
  // credit refund on failure — differing only in whether polling was required.
  const finalGeneration =
    submitted.kind === "completed"
      ? await finalizeGeneration(
          generation,
          { status: "completed", outputUrls: submitted.outputUrls },
          req.log,
        )
      : generation;

  res.status(201).json(CreateGenerationResponse.parse(toGenerationResponse(finalGeneration, model)));
});

router.get("/generations/:id", requireAuth, async (req, res): Promise<void> => {
  const params = GetGenerationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [row] = await db
    .select()
    .from(generationsTable)
    .innerJoin(modelsTable, eq(generationsTable.modelId, modelsTable.id))
    .where(and(eq(generationsTable.id, params.data.id), eq(generationsTable.userId, req.appUser!.id)));

  if (!row) {
    res.status(404).json({ error: "Generation not found" });
    return;
  }

  const model = row.models;
  // The real source of truth for completion is the background poller
  // (lib/generation/backgroundPoller.ts), which keeps checking the provider
  // even if no client is open. This on-demand sync just gives an open tab a
  // snappy result instead of waiting up to one poller interval.
  const generation = await syncGenerationStatus(row.generations, model, req.log);

  res.json(GetGenerationResponse.parse(toGenerationResponse(generation, model)));
});

router.delete("/generations/:id", requireAuth, async (req, res): Promise<void> => {
  const params = DeleteGenerationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const deleted = await db
    .delete(generationsTable)
    .where(and(eq(generationsTable.id, params.data.id), eq(generationsTable.userId, req.appUser!.id)))
    .returning();

  if (deleted.length === 0) {
    res.status(404).json({ error: "Generation not found" });
    return;
  }

  res.status(204).end();
});

export default router;
