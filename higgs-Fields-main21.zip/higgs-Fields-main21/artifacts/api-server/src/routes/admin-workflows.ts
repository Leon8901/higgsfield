import { Router, type IRouter } from "express";
import { asc, eq } from "drizzle-orm";
import { db, featureAppsTable, generationsTable, modelsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { requireOwner } from "../middlewares/requireOwner";

const router: IRouter = Router();
const inputTypes = new Set(["prompt", "image", "video", "audio", "text", "textarea", "number", "toggle"]);
const categories = new Set(["image", "video", "audio"]);

function validateBody(body: Record<string, unknown>) {
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const modelId = typeof body.modelId === "string" ? body.modelId.trim() : "";
  const category = body.category;
  const workflowId = typeof body.workflowId === "string" ? body.workflowId.trim() : "";
  const basePriceUsd = body.basePriceUsd;
  const inputs = body.inputs;
  const errors: string[] = [];
  if (!name) errors.push("Display name is required.");
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(modelId)) errors.push("Internal slug must use lowercase letters, numbers, and hyphens.");
  if (typeof category !== "string" || !categories.has(category)) errors.push("Choose a valid category.");
  if (!workflowId) errors.push("Workflow ID is required.");
  if (typeof basePriceUsd !== "number" || !Number.isFinite(basePriceUsd) || basePriceUsd < 0) errors.push("Enter the provider base price in USD.");
  if (!Array.isArray(inputs) || inputs.length === 0) errors.push("Add at least one input mapping.");
  if (Array.isArray(inputs)) {
    inputs.forEach((raw, index) => {
      const input = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
      if (typeof input.nodeId !== "string" || !input.nodeId.trim()) errors.push(`Input ${index + 1}: node ID is required.`);
      if (typeof input.fieldName !== "string" || !input.fieldName.trim()) errors.push(`Input ${index + 1}: field name is required.`);
      if (typeof input.label !== "string" || !input.label.trim()) errors.push(`Input ${index + 1}: label is required.`);
      if (typeof input.type !== "string" || !inputTypes.has(input.type)) errors.push(`Input ${index + 1}: choose a valid input type.`);
    });
    const targets = inputs.map((raw) => {
      const input = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
      return `${typeof input.nodeId === "string" ? input.nodeId.trim() : ""}\u0000${typeof input.fieldName === "string" ? input.fieldName.trim() : ""}`;
    });
    if (new Set(targets).size !== targets.length) errors.push("Each node and field mapping must be unique.");
  }
  const normalizedInputs = Array.isArray(inputs) ? inputs.map((input) => {
    const mapping = input as Record<string, unknown>;
    return {
      nodeId: typeof mapping.nodeId === "string" ? mapping.nodeId.trim() : "",
      fieldName: typeof mapping.fieldName === "string" ? mapping.fieldName.trim() : "",
      label: typeof mapping.label === "string" ? mapping.label.trim() : "",
      type: typeof mapping.type === "string" ? mapping.type : "",
    };
  }) : [];
  return { errors, name, modelId, category: category as string, workflowId, basePriceUsd: basePriceUsd as number, inputs: normalizedInputs };
}

function toWorkflow(model: typeof modelsTable.$inferSelect) {
  const config = model.executionConfig as { workflowId?: string; inputs?: unknown[] } | null;
  return {
    id: model.id,
    modelId: model.modelId,
    name: model.name,
    category: model.category,
    isActive: model.isActive,
    creditCost: model.creditCost,
    basePriceUsd: model.basePriceUsd,
    executionConfig: config,
    paramsSchema: model.paramsSchema,
  };
}

function createParamsSchema(inputs: Array<{ nodeId: string; fieldName: string; label: string; type: string }>) {
  return { fields: inputs.flatMap((input, index) => input.type === "prompt" ? [] : [{ key: `input_${index}`, label: input.label, type: input.type, required: true }]) };
}

router.get("/admin/workflows", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const rows = await db.select().from(modelsTable).where(eq(modelsTable.adapter, "runninghub")).orderBy(asc(modelsTable.sortOrder), asc(modelsTable.id));
  res.json(rows.map(toWorkflow));
});

router.post("/admin/workflows", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const parsed = validateBody(req.body as Record<string, unknown>);
  if (parsed.errors.length) {
    res.status(400).json({ error: parsed.errors.join(" ") });
    return;
  }
  const [existing] = await db.select({ id: modelsTable.id }).from(modelsTable).where(eq(modelsTable.modelId, parsed.modelId));
  if (existing) {
    res.status(409).json({ error: "That internal slug is already in use." });
    return;
  }
  const now = new Date();
  const [created] = await db.insert(modelsTable).values({
    modelId: parsed.modelId,
    name: parsed.name,
    category: parsed.category,
    description: parsed.name,
    adapter: "runninghub",
    providerModelPath: parsed.workflowId,
    basePriceUsd: parsed.basePriceUsd,
    creditCost: null,
    paramsSchema: createParamsSchema(parsed.inputs),
    executionConfig: { workflowId: parsed.workflowId, inputs: parsed.inputs },
    isActive: false,
    isSynced: false,
    isDelisted: false,
    updatedAt: now,
  }).returning();
  res.status(201).json(toWorkflow(created));
});

router.patch("/admin/workflows/:modelId", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const modelId = String(req.params.modelId);
  const [existing] = await db.select().from(modelsTable).where(eq(modelsTable.modelId, modelId));
  if (!existing || existing.adapter !== "runninghub") {
    res.status(404).json({ error: "Workflow not found." });
    return;
  }
  const parsed = validateBody(req.body as Record<string, unknown>);
  if (parsed.errors.length) {
    res.status(400).json({ error: parsed.errors.join(" ") });
    return;
  }
  const [conflict] = await db.select({ id: modelsTable.id }).from(modelsTable).where(eq(modelsTable.modelId, parsed.modelId));
  if (conflict && conflict.id !== existing.id) {
    res.status(409).json({ error: "That internal slug is already in use." });
    return;
  }
  const body = req.body as Record<string, unknown>;
  const hasCreditCost = Object.prototype.hasOwnProperty.call(body, "creditCost");
  if (hasCreditCost && body.creditCost !== null && (typeof body.creditCost !== "number" || !Number.isInteger(body.creditCost) || body.creditCost < 0)) {
    res.status(400).json({ error: "Credit cost must be null or a non-negative integer." });
    return;
  }
  const hasIsActive = Object.prototype.hasOwnProperty.call(body, "isActive");
  if (hasIsActive && typeof body.isActive !== "boolean") {
    res.status(400).json({ error: "Active status must be a boolean." });
    return;
  }
  const creditCost = hasCreditCost ? body.creditCost as number | null : existing.creditCost;
  const isActive = hasIsActive ? body.isActive as boolean : existing.isActive;
  if (isActive && creditCost === null) {
    res.status(400).json({ error: "Set a credit cost before activating this workflow." });
    return;
  }
  const now = new Date();
  const [updated] = await db.update(modelsTable).set({
    modelId: parsed.modelId,
    name: parsed.name,
    category: parsed.category,
    description: parsed.name,
    providerModelPath: parsed.workflowId,
    basePriceUsd: parsed.basePriceUsd,
    paramsSchema: createParamsSchema(parsed.inputs),
    executionConfig: { workflowId: parsed.workflowId, inputs: parsed.inputs },
    creditCost,
    isActive,
    updatedAt: now,
  }).where(eq(modelsTable.id, existing.id)).returning();
  res.json(toWorkflow(updated));
});

router.delete("/admin/workflows/:modelId", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const modelId = String(req.params.modelId);
  const [existing] = await db.select().from(modelsTable).where(eq(modelsTable.modelId, modelId));
  if (!existing || existing.adapter !== "runninghub") {
    res.status(404).json({ error: "Workflow not found." });
    return;
  }

  const body = req.body as Record<string, unknown> | undefined;
  const confirmation = typeof body?.confirmation === "string" ? body.confirmation : "";
  if (confirmation !== existing.name && confirmation !== existing.modelId) {
    res.status(400).json({ error: "Type the workflow's exact display name or slug to confirm deletion." });
    return;
  }

  const featureApps = await db
    .select({ name: featureAppsTable.name, slug: featureAppsTable.slug })
    .from(featureAppsTable)
    .where(eq(featureAppsTable.modelId, existing.id))
    .orderBy(asc(featureAppsTable.name), asc(featureAppsTable.slug));
  if (featureApps.length > 0) {
    const names = featureApps.map((app) => `${app.name} (${app.slug})`).join(", ");
    res.status(409).json({
      error: `Cannot delete "${existing.name}" because these feature apps depend on it: ${names}. Change each feature app to another model first.`,
    });
    return;
  }

  const [generationReference] = await db
    .select({ id: generationsTable.id })
    .from(generationsTable)
    .where(eq(generationsTable.modelId, existing.id))
    .limit(1);
  if (generationReference) {
    res.status(409).json({ error: "This workflow has generation history. Keep the model row to preserve those records." });
    return;
  }

  const [deleted] = await db.delete(modelsTable).where(eq(modelsTable.id, existing.id)).returning({ id: modelsTable.id });
  if (!deleted) {
    res.status(404).json({ error: "Workflow not found." });
    return;
  }
  res.json({ deleted: true });
});
export default router;
