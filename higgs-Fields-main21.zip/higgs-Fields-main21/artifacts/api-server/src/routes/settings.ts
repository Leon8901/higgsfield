import { Router, type IRouter } from "express";
import { sql, eq } from "drizzle-orm";
import { GetPublicSettingsResponse, GetAdminSettingsResponse, UpdateAdminSettingsBody, UpdateAdminSettingsResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { requireOwner } from "../middlewares/requireOwner";
import { getPublicSettings, getAdminSettings, updateSettings } from "../lib/settings";
import { db, siteSettingsTable, settingsMetaTable, generationsTable } from "@workspace/db";
import { SETTINGS_REGISTRY } from "@workspace/db/settingsRegistry";
import { importAssetFromUrl } from "../lib/media/assetImport";

import { getSupabaseStorageClient, getStorageBucket } from '../lib/supabaseClient';

/** Real functional probe of Supabase Storage connectivity — the actual step that fails
 *  in production if credentials or the bucket name are wrong.
 *  Does NOT write any object to storage; it only calls list() (read-only, cheap).
 *  Returns a three-state result:
 *    connected    — bucket is reachable and credentials are valid
 *    disconnected — Supabase responded with a confirmed error (bad key, missing bucket, etc.)
 *    warning      — could not reach a conclusive answer (timeout, DNS failure, etc.)
 */
async function probeObjectStorage(): Promise<{
  status: 'connected' | 'disconnected' | 'warning';
  message?: string;
}> {
  let bucket: string;
  try {
    bucket = getStorageBucket();
  } catch (err) {
    return {
      status: 'disconnected',
      message: err instanceof Error ? err.message : String(err),
    };
  }

  let supabase: ReturnType<typeof getSupabaseStorageClient>;
  try {
    supabase = getSupabaseStorageClient();
  } catch (err) {
    return {
      status: 'disconnected',
      message: err instanceof Error ? err.message : String(err),
    };
  }

  try {
    const { error } = await supabase.storage
      .from(bucket)
      .list('', { limit: 1, offset: 0 });

    if (error) {
      return { status: 'disconnected', message: error.message };
    }
    return { status: 'connected' };
  } catch (err) {
    // Timeout, DNS failure, or other network error — couldn't get a conclusive answer.
    const message = err instanceof Error ? err.message : String(err);
    return { status: 'warning', message };
  }
}


const router: IRouter = Router();

router.get("/settings", async (_req, res): Promise<void> => {
  const settings = await getPublicSettings();
  res.json(GetPublicSettingsResponse.parse(settings));
});

router.get("/admin/settings", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const settings = await getAdminSettings();
  res.json(GetAdminSettingsResponse.parse(settings));
});

router.patch("/admin/settings", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const body = UpdateAdminSettingsBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const result = await updateSettings(body.data);
  if (!result.ok) {
    res.status(400).json({ error: "Validation failed", fields: result.errors });
    return;
  }

  const settings = await getAdminSettings();
  res.json(UpdateAdminSettingsResponse.parse(settings));
});

// Shared asset-import endpoint — fetches an external URL server-side,
// validates it's a real image under 5 MB, re-hosts it on our own storage,
// and returns the owned path. Used by the Logos & Icons branding tab and
// provider icon management so raw external URLs never reach the DB directly.
router.post("/admin/settings/import-asset", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const { url } = req.body as { url?: string };
  if (typeof url !== "string" || !url.trim()) {
    res.status(400).json({ error: "url is required" });
    return;
  }
  try {
    const path = await importAssetFromUrl(url.trim());
    res.json({ path });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : "Asset import failed" });
  }
});

// Export all settings as a flat key→value JSON file download.
router.get("/admin/settings/export", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const settings = await getAdminSettings();
  const flat: Record<string, unknown> = {};
  for (const s of settings) flat[s.key] = s.value;
  const date = new Date().toISOString().split("T")[0];
  res.setHeader("Content-Disposition", `attachment; filename="site-settings-${date}.json"`);
  res.json(flat);
});

// Import settings from a flat key→value object — same all-or-nothing semantics as PATCH.
// Unknown keys are rejected by updateSettings() which checks against SETTINGS_BY_KEY.
router.post("/admin/settings/import", requireAuth, requireOwner, async (req, res): Promise<void> => {
  const body = req.body;
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    res.status(400).json({ error: "Body must be a flat JSON object" });
    return;
  }
  const result = await updateSettings(body as Record<string, unknown>);
  if (!result.ok) {
    res.status(400).json({ error: "Validation failed", fields: result.errors });
    return;
  }
  const settings = await getAdminSettings();
  res.json(GetAdminSettingsResponse.parse(settings));
});

// Reset every setting to its registry default — one updateSettings() call, same validation path.
router.post("/admin/settings/reset-defaults", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  const patch: Record<string, unknown> = {};
  for (const def of SETTINGS_REGISTRY) patch[def.key] = def.default;
  const result = await updateSettings(patch);
  if (!result.ok) {
    res.status(500).json({ error: "Reset failed", fields: result.errors });
    return;
  }
  const settings = await getAdminSettings();
  res.json(GetAdminSettingsResponse.parse(settings));
});

// Real infrastructure health checks for the admin settings panel.
// Database: runs a real query against settings_meta.
// Object Storage: real functional sidecar signing probe — three states:
//   connected / disconnected (confirmed error) / warning (couldn't determine).
// providerHostedCount: rows in generations with is_provider_hosted = true.
// lastSavedAt: MAX(updated_at) across all site_settings rows.
router.get("/admin/settings/health", requireAuth, requireOwner, async (_req, res): Promise<void> => {
  // Run all checks concurrently
  const [dbResult, storageResult, providerHostedResult, lastSavedAtResult] = await Promise.allSettled([
    db.select().from(settingsMetaTable).where(eq(settingsMetaTable.id, 1)),
    probeObjectStorage(),
    db.select({ count: sql<number>`COUNT(*)::int` }).from(generationsTable).where(eq(generationsTable.isProviderHosted, true)),
    db.select({ maxUpdatedAt: sql<string>`MAX(updated_at)` }).from(siteSettingsTable),
  ]);

  const dbConnected = dbResult.status === 'fulfilled';

  const storage = storageResult.status === 'fulfilled'
    ? storageResult.value
    : { status: 'warning' as const, message: storageResult.reason instanceof Error ? storageResult.reason.message : String(storageResult.reason) };

  const providerHostedCount = providerHostedResult.status === 'fulfilled'
    ? (providerHostedResult.value[0]?.count ?? 0)
    : 0;

  const lastSavedAt = lastSavedAtResult.status === 'fulfilled'
    ? (lastSavedAtResult.value[0]?.maxUpdatedAt ?? null)
    : null;

  res.json({
    database: { connected: dbConnected },
    objectStorage: {
      status: storage.status,
      message: storage.message ?? null,
      providerHostedCount,
    },
    lastSavedAt,
  });
});

export default router;
