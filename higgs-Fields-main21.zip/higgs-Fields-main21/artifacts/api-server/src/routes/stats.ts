import { Router, type IRouter } from "express";
import { sql, eq, and } from "drizzle-orm";
import { db, generationsTable, usersTable, appsTable, modelsTable } from "@workspace/db";
import { GetPlatformStatsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const [videosRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(generationsTable)
    .where(and(eq(generationsTable.status, "completed"), eq(generationsTable.outputType, "video")));

  const [creatorsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(usersTable);

  const [appsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(appsTable);

  const [modelsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(modelsTable)
    .where(eq(modelsTable.isActive, true));

  res.json(
    GetPlatformStatsResponse.parse({
      videosGenerated: videosRow?.count ?? 0,
      activeCreators: creatorsRow?.count ?? 0,
      communityApps: appsRow?.count ?? 0,
      modelsAvailable: modelsRow?.count ?? 0,
    }),
  );
});

export default router;
