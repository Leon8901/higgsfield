import type { MediaAdapter, MediaSubmitContext, PollResult, SubmitResult } from "../types";
import { ProviderError } from "../types";

interface RunningHubInput {
  nodeId: string;
  fieldName: string;
  label: string;
  type: string;
}

interface RunningHubConfig {
  workflowId: string;
  inputs: RunningHubInput[];
}

type ApiRecord = Record<string, unknown>;

const API_ROOT = "https://www.runninghub.ai/task/openapi";

function asRecord(value: unknown): ApiRecord | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as ApiRecord
    : undefined;
}

function responseText(value: unknown): string | undefined {
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function responseMessage(body: ApiRecord | undefined, fallback: string): string {
  return responseText(body?.msg) ?? responseText(body?.message) ?? fallback;
}

function readConfig(value: unknown): RunningHubConfig {
  if (!value || typeof value !== "object") throw new ProviderError("validation", "Workflow execution configuration is missing.");
  const config = value as Partial<RunningHubConfig>;
  if (typeof config.workflowId !== "string" || !config.workflowId.trim() || !Array.isArray(config.inputs)) {
    throw new ProviderError("validation", "Workflow execution configuration is invalid.");
  }
  if (config.inputs.some((input) => !input || typeof input.nodeId !== "string" || typeof input.fieldName !== "string" || typeof input.label !== "string" || typeof input.type !== "string")) {
    throw new ProviderError("validation", "Workflow input mappings are invalid.");
  }
  return config as RunningHubConfig;
}

async function responseJson(response: Response): Promise<ApiRecord> {
  const raw: unknown = await response.json().catch(() => null);
  const body = asRecord(raw);
  if (!response.ok || !body) {
    throw new ProviderError("unknown", responseMessage(body, `RunningHub request failed with status ${response.status}`));
  }
  const code = body.code;
  if (typeof code === "number" && code !== 0 && code !== 804 && code !== 813 && code !== 805) {
    throw new ProviderError("unknown", responseMessage(body, `RunningHub returned code ${code}`));
  }
  return body;
}

async function uploadInput(value: unknown, type: string, apiKey: string): Promise<string> {
  if (typeof value !== "string" || value.length === 0) {
    throw new ProviderError("validation", "A required workflow input is missing.");
  }
  const source = await fetch(value);
  if (!source.ok) throw new ProviderError("validation", `Unable to read the uploaded ${type} input.`);
  const bytes = await source.arrayBuffer();
  const filename = new URL(value).pathname.split("/").pop();
  if (!filename) throw new ProviderError("validation", `The uploaded ${type} input has no file name.`);
  const form = new FormData();
  form.append("apiKey", apiKey);
  form.append("fileType", "input");
  form.append("file", new Blob([bytes], { type: source.headers.get("content-type") || "application/octet-stream" }), filename);

  const response = await fetch(`${API_ROOT}/upload`, { method: "POST", body: form });
  const body = await responseJson(response);
  const fileName = asRecord(body.data)?.fileName;
  if (typeof fileName !== "string" || !fileName) throw new ProviderError("unknown", "RunningHub upload response did not include a file name.");
  return fileName;
}

export const runninghubAdapter: MediaAdapter = {
  async submit(_providerModelPath: string, params: Record<string, unknown>, apiKey: string, context?: MediaSubmitContext): Promise<SubmitResult> {
    const config = readConfig(context?.executionConfig);
    const orderedInputs = Array.isArray(params.orderedInputs) ? params.orderedInputs : null;
    const nodeInfoList = [];
    for (const [index, input] of config.inputs.entries()) {
      const value = input.type === "prompt"
        ? params.prompt
        : orderedInputs
          ? orderedInputs[index]
          : params[`input_${index}`];
      const fieldValue = input.type === "image" || input.type === "video" || input.type === "audio"
        ? await uploadInput(value, input.type, apiKey)
        : value;
      if (fieldValue === undefined || fieldValue === null || fieldValue === "") {
        throw new ProviderError("validation", `Missing value for ${input.label}.`);
      }
      nodeInfoList.push({ nodeId: input.nodeId, fieldName: input.fieldName, fieldValue });
    }

    const response = await fetch(`${API_ROOT}/create`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ apiKey, workflowId: config.workflowId, nodeInfoList }),
    });
    const body = await responseJson(response);
    const taskId = asRecord(body.data)?.taskId;
    if (typeof taskId !== "string" || !taskId) throw new ProviderError("unknown", "RunningHub create response did not include a task ID.");
    return { kind: "async", providerTaskId: taskId };
  },

  async poll(providerTaskId: string, apiKey: string): Promise<PollResult> {
    const response = await fetch(`${API_ROOT}/outputs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ apiKey, taskId: providerTaskId }),
    });
    const body = await responseJson(response);
    const data = asRecord(body.data);
    if (body.code === 805) {
      const failedReason = asRecord(data?.failedReason);
      return {
        status: "failed",
        outputUrls: [],
        errorMessage: responseText(failedReason?.exception_message) ?? responseText(body.msg) ?? "Workflow failed.",
      };
    }
    if (body.code === 804 || body.code === 813) return { status: "processing", outputUrls: [] };
    const outputs = Array.isArray(body.data) ? body.data : [];
    const outputUrls = outputs
      .map((item: unknown) => asRecord(item)?.fileUrl)
      .filter((url): url is string => typeof url === "string" && url.length > 0);
    if (outputUrls.length) return { status: "completed", outputUrls };
    const taskStatus = data?.taskStatus;
    if (typeof taskStatus === "string") {
      const status = taskStatus.toLowerCase();
      if (status === "failed" || status === "error") {
        return { status: "failed", outputUrls: [], errorMessage: responseText(data?.errorMessage) ?? responseText(body.msg) ?? "Workflow failed." };
      }
      if (status === "success" || status === "completed") return { status: "completed", outputUrls: [] };
    }
    return { status: "processing", outputUrls: [] };
  },
};
