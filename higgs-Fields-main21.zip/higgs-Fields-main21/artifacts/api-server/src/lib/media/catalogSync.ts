// Provider catalog sync service. Handles three operations:
//
//   fetchProviderCatalog(adapter, apiKey)
//     → calls the provider's live model-list endpoint and returns raw items
//
//   normalizeWavespeedItem(item)
//     → converts one raw WaveSpeed catalog item into the internal paramsSchema
//        { fields: [...] } shape used by the frontend generation form
//
//   catalogSlugify(providerModelPath, adapter)
//     → derives a deterministic stable modelId slug from the provider path
//
// The sync engine (in admin-models.ts) owns all DB decisions. This file only
// knows how to talk to providers and how to normalize their response shapes.

const WAVESPEED_CATALOG_URL = "https://api.wavespeed.ai/api/v3/models";

// ── Raw WaveSpeed catalog types ───────────────────────────────────────────────

interface WavespeedCatalogProperty {
  type?: string | string[];
  description?: string;
  enum?: string[];
  default?: unknown;
  minimum?: number;
  maximum?: number;
}

interface WavespeedApiSchema {
  type?: string;
  method?: string;
  api_path?: string;
  request_schema?: {
    type?: string;
    required?: string[];
    properties?: Record<string, WavespeedCatalogProperty>;
  };
}

export interface WavespeedCatalogItem {
  id?: string;
  model_id?: string;
  name: string;
  description?: string;
  type?: string;           // "image" | "video" | "audio"
  base_price?: number;
  api_schema?: {
    api_schemas?: WavespeedApiSchema[];
    // Some older catalog entries have properties directly on api_schema
    properties?: Record<string, WavespeedCatalogProperty>;
    required?: string[];
  };
}

// ── Public types returned to route handlers ───────────────────────────────────

export interface CatalogEntry {
  /** Exact provider-side path — used as providerModelPath in DB */
  providerModelPath: string;
  name: string;
  description: string;
  /** Normalised to "image" | "video" | "audio", defaults to "image" */
  category: "image" | "video" | "audio";
  providerBasePriceUsd: number;
  rawSchema: WavespeedCatalogItem["api_schema"] | null;
  paramsSchema: ParamsSchema;
}

export interface ParamsField {
  key: string;
  label: string;
  type: "text" | "select" | "number" | "toggle" | "image";
  options?: string[];
  default?: unknown;
  required?: boolean;
}

export interface ParamsSchema {
  fields: ParamsField[];
}

// ── Category normalizer ───────────────────────────────────────────────────────

function normalizeCategory(raw: string | undefined): "image" | "video" | "audio" {
  const v = (raw ?? "").toLowerCase();
  if (v === "video") return "video";
  if (v === "audio") return "audio";
  return "image";
}

// ── Stable slug from providerModelPath ───────────────────────────────────────
// "wavespeed-ai/image-face-swap" → "wavespeed-ai-image-face-swap"
// "google/nano-banana-pro/edit"  → "google-nano-banana-pro-edit"

export function catalogSlugify(providerModelPath: string): string {
  return providerModelPath.replace(/\//g, "-").toLowerCase();
}

// ── Label humanizer (key → "Image Field Name") ───────────────────────────────

function humanizeKey(key: string): string {
  return key
    .replace(/_/g, " ")
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

// ── WaveSpeed property → ParamsField ─────────────────────────────────────────

function normalizeProperty(
  key: string,
  prop: WavespeedCatalogProperty,
  required: boolean,
): ParamsField | null {
  const rawType = Array.isArray(prop.type) ? prop.type[0] : prop.type;

  // Determine our internal type
  let fieldType: ParamsField["type"];
  if (prop.enum && prop.enum.length > 0) {
    fieldType = "select";
  } else if (rawType === "boolean") {
    fieldType = "toggle";
  } else if (rawType === "integer" || rawType === "number") {
    fieldType = "number";
  } else if (rawType === "string") {
    // Heuristic: keys that semantically represent image/file inputs
    if (/image|photo|file|video|face|avatar/.test(key.toLowerCase())) {
      fieldType = "image";
    } else {
      fieldType = "text";
    }
  } else {
    // Skip unknown / object / array types (e.g. internal-only provider params)
    return null;
  }

  const field: ParamsField = {
    key,
    label: humanizeKey(key),
    type: fieldType,
    required,
  };

  if (prop.enum && prop.enum.length > 0) {
    field.options = prop.enum;
  }
  if (prop.default !== undefined && prop.default !== null) {
    field.default = typeof prop.default === "number" ? String(prop.default) : prop.default;
  }

  return field;
}

// ── Normalize one WaveSpeed catalog item ──────────────────────────────────────

export function normalizeWavespeedItem(item: WavespeedCatalogItem): CatalogEntry {
  // Extract the canonical request_schema — prefer the first model_run api_schema
  let properties: Record<string, WavespeedCatalogProperty> = {};
  let requiredKeys: string[] = [];

  const apiSchemas = item.api_schema?.api_schemas ?? [];
  const modelRun = apiSchemas.find((s) => s.type === "model_run") ?? apiSchemas[0];

  if (modelRun?.request_schema?.properties) {
    properties = modelRun.request_schema.properties;
    requiredKeys = modelRun.request_schema.required ?? [];
  } else if (item.api_schema?.properties) {
    // Fallback: some older catalog items have properties directly on api_schema
    properties = item.api_schema.properties;
    requiredKeys = item.api_schema.required ?? [];
  }

  const fields: ParamsField[] = [];
  for (const [key, prop] of Object.entries(properties)) {
    // Omit prompt — it's managed by the platform, not shown in the params form
    if (key === "prompt") continue;
    const field = normalizeProperty(key, prop, requiredKeys.includes(key));
    if (field) fields.push(field);
  }

  const modelPath = item.model_id || item.id || item.name;
  return {
    providerModelPath: modelPath,
    name: item.name ?? modelPath,
    description: item.description ?? "",
    category: normalizeCategory(item.type),
    providerBasePriceUsd: item.base_price ?? 0,
    rawSchema: item.api_schema ?? null,
    paramsSchema: { fields },
  };
}

// ── WaveSpeed catalog fetch ───────────────────────────────────────────────────

export async function fetchWavespeedCatalog(
  apiKey: string,
): Promise<CatalogEntry[]> {
  const res = await fetch(WAVESPEED_CATALOG_URL, {
    headers: { Authorization: `Bearer ${apiKey}` },
  });

  if (res.status === 401 || res.status === 403) {
    throw new Error("WaveSpeed catalog: invalid or expired API key.");
  }
  if (!res.ok) {
    throw new Error(`WaveSpeed catalog request failed: HTTP ${res.status}`);
  }

  const body = (await res.json()) as { code?: number; data?: WavespeedCatalogItem[] };
  const items = body?.data;
  if (!Array.isArray(items)) {
    throw new Error("WaveSpeed catalog: unexpected response shape (missing data array)");
  }

  return items.map(normalizeWavespeedItem);
}

// ── Provider catalog dispatch ─────────────────────────────────────────────────
// Extend here as more providers add documented catalog endpoints.

export async function fetchProviderCatalog(
  providerSlug: string,
  apiKey: string,
): Promise<CatalogEntry[]> {
  switch (providerSlug) {
    case "wavespeed":
      return fetchWavespeedCatalog(apiKey);
    default:
      throw new Error(
        `No catalog endpoint is implemented for provider "${providerSlug}". ` +
          `Only providers with a documented, stable model-list API are supported.`,
      );
  }
}
