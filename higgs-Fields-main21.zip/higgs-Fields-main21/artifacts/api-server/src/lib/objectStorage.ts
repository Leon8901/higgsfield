import { randomUUID } from 'crypto';
import { getSupabaseStorageClient, getStorageBucket } from './supabaseClient';

import {
  canAccessObject,
  getObjectAclPolicy,
  ObjectAclPolicy,
  ObjectPermission,
  setObjectAclPolicy,
  type StorageFile,
} from './objectAcl';

export { getSupabaseStorageClient, getStorageBucket };




// ---------------------------------------------------------------------------
// Error types
// ---------------------------------------------------------------------------

export class ObjectNotFoundError extends Error {
  constructor() {
    super('Object not found');
    this.name = 'ObjectNotFoundError';
    Object.setPrototypeOf(this, ObjectNotFoundError.prototype);
  }
}

// ---------------------------------------------------------------------------
// ObjectStorageService
// All public method signatures are preserved from the GCS implementation so
// callers (routes/storage.ts, lib/media/assetPersistence.ts,
// lib/media/assetImport.ts) require zero changes.
// ---------------------------------------------------------------------------

/** Expiry (seconds) for signed download URLs sent to external providers. */
export const SIGNED_URL_EXPIRY_SECONDS = 3600;

export class ObjectStorageService {
  constructor() {}

  // -------------------------------------------------------------------------
  // Uploads a buffer directly (server-side, no presigned URL round-trip) into
  // the storage bucket under `generations/<filename>`. Used to re-host
  // provider-returned generation assets on our own storage — see
  // lib/media/assetPersistence.ts. Returns `/objects/generations/<filename>`,
  // the same internal path shape that getObjectEntityFile() expects, so the
  // existing /storage/objects/* route serves it with no changes.
  // -------------------------------------------------------------------------
  async uploadGeneratedAsset(
    buffer: Buffer,
    filename: string,
    contentType: string,
  ): Promise<string> {
    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();
    const objectPath = `generations/${filename}`;

    const { error } = await supabase.storage
      .from(bucket)
      .upload(objectPath, buffer, {
        contentType,
        upsert: true,
      });

    if (error) {
      throw new Error(
        `Failed to upload asset "${filename}" to Supabase Storage: ${error.message}`,
      );
    }

    return `/objects/generations/${filename}`;
  }

  // -------------------------------------------------------------------------
  // Returns a Supabase signed upload URL for direct client-to-storage uploads.
  // The client PUTs the file to this URL, then stores the objectPath for later
  // serving via /storage/objects/*. When userId is passed, scopes the path under
  // uploads/<userId>/... for verified ownership.
  // -------------------------------------------------------------------------
  async getObjectEntityUploadURL(userId?: number | string): Promise<string> {
    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();
    const objectId = randomUUID();
    const objectPath = userId !== undefined ? `uploads/${userId}/${objectId}` : `uploads/${objectId}`;

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUploadUrl(objectPath);

    if (error || !data?.signedUrl) {
      throw new Error(
        `Failed to create signed upload URL: ${error?.message ?? 'no URL returned'}`,
      );
    }

    return data.signedUrl;
  }

  // -------------------------------------------------------------------------
  // Returns a signed download URL for an existing object entity.
  // The expiry is controlled by the named constant SIGNED_URL_EXPIRY_SECONDS.
  // -------------------------------------------------------------------------
  async getObjectEntitySignedURL(
    rawPath: string,
    expiresInSec: number = SIGNED_URL_EXPIRY_SECONDS,
  ): Promise<string> {
    const normalized = this.normalizeObjectEntityPath(rawPath);
    const inBucketPath = normalized.startsWith('/objects/')
      ? normalized.slice('/objects/'.length)
      : normalized;

    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();

    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(inBucketPath, expiresInSec);

    if (error || !data?.signedUrl) {
      throw new Error(
        `Failed to generate signed download URL for "${inBucketPath}": ${error?.message ?? 'no URL returned'}`,
      );
    }

    return data.signedUrl;
  }

  // -------------------------------------------------------------------------
  // Checks if an object path belongs to a specific user by verifying
  // uploads/<userId>/... path ownership.
  // -------------------------------------------------------------------------
  isUserUploadedObject(rawPath: string, userId: number | string): boolean {
    const normalized = this.normalizeObjectEntityPath(rawPath);
    const inBucketPath = normalized.startsWith('/objects/')
      ? normalized.slice('/objects/'.length)
      : normalized;

    return inBucketPath.startsWith(`uploads/${userId}/`);
  }

  // -------------------------------------------------------------------------
  // Resolves an /objects/<entityId> internal path to a StorageFile descriptor.
  // Throws ObjectNotFoundError if the object doesn't exist in the bucket.
  // -------------------------------------------------------------------------
  async getObjectEntityFile(objectPath: string): Promise<StorageFile> {
    if (!objectPath.startsWith('/objects/')) {
      throw new ObjectNotFoundError();
    }

    // Strip leading "/objects/" to get the in-bucket path.
    const entityId = objectPath.slice('/objects/'.length);
    if (!entityId) {
      throw new ObjectNotFoundError();
    }

    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();

    // Use list() with a search filter — the cheapest existence check available
    // on the Supabase JS client (no separate head/info endpoint).
    const dir = entityId.includes('/')
      ? entityId.split('/').slice(0, -1).join('/')
      : '';
    const filename = entityId.split('/').pop() ?? entityId;

    const { data, error } = await supabase.storage
      .from(bucket)
      .list(dir, { search: filename });

    if (error) {
      throw new Error(
        `Storage lookup failed for "${entityId}": ${error.message}`,
      );
    }

    const found = data?.find((f) => f.name === filename);
    if (!found) {
      throw new ObjectNotFoundError();
    }

    return {
      objectPath: entityId,
      contentType: (found.metadata as Record<string, unknown> | null)
        ?.['mimetype'] as string | undefined,
      size: (found.metadata as Record<string, unknown> | null)
        ?.['size'] as number | undefined,
    };
  }

  // -------------------------------------------------------------------------
  // Downloads an object and returns a web-compatible Response (same shape as
  // before so routes/storage.ts can pipe it unchanged).
  // -------------------------------------------------------------------------
  async downloadObject(
    file: StorageFile,
    cacheTtlSec: number = 3600,
  ): Promise<Response> {
    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();

    // Read ACL policy to determine cache visibility.
    const aclPolicy = await getObjectAclPolicy(file).catch(() => null);
    const isPublic = aclPolicy?.visibility === 'public';

    const { data, error } = await supabase.storage
      .from(bucket)
      .download(file.objectPath);

    if (error || !data) {
      throw new Error(
        `Failed to download "${file.objectPath}" from Supabase Storage: ${error?.message ?? 'no data returned'}`,
      );
    }

    // Supabase download() returns a Blob; convert to a streaming Response.
    const contentType =
      file.contentType ??
      data.type ??
      'application/octet-stream';

    const headers: Record<string, string> = {
      'Content-Type': contentType,
      'Cache-Control': `${isPublic ? 'public' : 'private'}, max-age=${cacheTtlSec}`,
    };
    if (file.size) {
      headers['Content-Length'] = String(file.size);
    }

    return new Response(data.stream(), { headers });
  }

  // -------------------------------------------------------------------------
  // Searches for a public object at the given filePath within the bucket
  // under a "public/" prefix — all public assets live under a single
  // well-known prefix in Supabase since we have one bucket. Returns null if not found.
  // -------------------------------------------------------------------------
  async searchPublicObject(filePath: string): Promise<StorageFile | null> {
    const supabase = getSupabaseStorageClient();
    const bucket = getStorageBucket();

    // Public objects are stored under "public/<filePath>" within the bucket.
    const objectPath = `public/${filePath}`;
    const dir = objectPath.includes('/')
      ? objectPath.split('/').slice(0, -1).join('/')
      : '';
    const filename = objectPath.split('/').pop() ?? objectPath;

    const { data, error } = await supabase.storage
      .from(bucket)
      .list(dir, { search: filename });

    if (error) {
      // Non-fatal: treat lookup errors as "not found" for public objects
      // to keep the existing route behaviour (returns 404, not 500).
      return null;
    }

    const found = data?.find((f) => f.name === filename);
    if (!found) return null;

    return {
      objectPath,
      contentType: (found.metadata as Record<string, unknown> | null)
        ?.['mimetype'] as string | undefined,
      size: (found.metadata as Record<string, unknown> | null)
        ?.['size'] as number | undefined,
    };
  }

  // -------------------------------------------------------------------------
  // Converts a Supabase signed upload URL or a raw Supabase Storage URL back
  // to the internal /objects/<path> form. Callers (routes/storage.ts) use the
  // returned value as the objectPath to store and later serve.
  // -------------------------------------------------------------------------
  normalizeObjectEntityPath(rawPath: string): string {
    // Already an internal path — nothing to do.
    if (rawPath.startsWith('/objects/')) return rawPath;

    // Supabase signed upload URL shape:
    //   https://<project>.supabase.co/storage/v1/object/upload/sign/<bucket>/<objectPath>?token=...
    // Supabase public/authenticated URL shape:
    //   https://<project>.supabase.co/storage/v1/object/public/<bucket>/<objectPath>
    //   https://<project>.supabase.co/storage/v1/object/authenticated/<bucket>/<objectPath>
    try {
      const url = new URL(rawPath);
      const pathname = url.pathname;

      const bucket = getStorageBucket();
      const prefixes = [
        `/storage/v1/object/upload/sign/${bucket}/`,
        `/storage/v1/object/public/${bucket}/`,
        `/storage/v1/object/authenticated/${bucket}/`,
        `/storage/v1/object/${bucket}/`,
      ];

      for (const prefix of prefixes) {
        if (pathname.startsWith(prefix)) {
          const objectPath = pathname.slice(prefix.length);
          return `/objects/${objectPath}`;
        }
      }
    } catch {
      // Not a URL — return as-is.
    }

    return rawPath;
  }

  // -------------------------------------------------------------------------
  // Sets the ACL policy on an object identified by its raw path (either a
  // Supabase URL or an internal /objects/... path). Returns the normalised
  // internal path. No-ops silently if the path can't be resolved to an object.
  // -------------------------------------------------------------------------
  async trySetObjectEntityAclPolicy(
    rawPath: string,
    aclPolicy: ObjectAclPolicy,
  ): Promise<string> {
    const normalizedPath = this.normalizeObjectEntityPath(rawPath);
    if (!normalizedPath.startsWith('/')) {
      return normalizedPath;
    }

    const objectFile = await this.getObjectEntityFile(normalizedPath);
    await setObjectAclPolicy(objectFile, aclPolicy);
    return normalizedPath;
  }

  // -------------------------------------------------------------------------
  // ACL access check — same signature as before; callers unchanged.
  // -------------------------------------------------------------------------
  async canAccessObjectEntity({
    userId,
    objectFile,
    requestedPermission,
  }: {
    userId?: string;
    objectFile: StorageFile;
    requestedPermission?: ObjectPermission;
  }): Promise<boolean> {
    return canAccessObject({
      userId,
      objectFile,
      requestedPermission: requestedPermission ?? ObjectPermission.READ,
    });
  }
}
