﻿import { createClient, type SupabaseClient } from '@supabase/supabase-js';

// ---------------------------------------------------------------------------
// Supabase client singleton — lives in its own module so both objectStorage.ts
// and objectAcl.ts can import it without creating a circular dependency.
// ---------------------------------------------------------------------------

let _client: SupabaseClient | null = null;

/** Returns the singleton Supabase client, throwing early if env vars are missing. */
export function getSupabaseStorageClient(): SupabaseClient {
  if (_client) return _client;

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !key) {
    throw new Error(
      'Supabase Storage is not configured. ' +
        'Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY environment variables.',
    );
  }

  // Service-role key: unrestricted server-side access. NEVER expose to clients.
  _client = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return _client;
}

/** Returns the storage bucket name from the environment, throwing if not set. */
export function getStorageBucket(): string {
  const bucket = process.env.SUPABASE_STORAGE_BUCKET;
  if (!bucket) {
    throw new Error(
      'Supabase Storage bucket is not configured. ' +
        'Set SUPABASE_STORAGE_BUCKET environment variable.',
    );
  }
  return bucket;
}
