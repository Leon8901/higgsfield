import { getSupabaseStorageClient, getStorageBucket } from './supabaseClient';

const ACL_POLICY_METADATA_KEY = 'aclPolicy';

// Lightweight descriptor passed between objectStorage.ts and objectAcl.ts.
// Replaces the GCS `File` type — callers never construct these directly.
export interface StorageFile {
  /** Supabase object path within the bucket, e.g. "generations/uuid.jpg" */
  objectPath: string;
  /** Content-Type, if known at construction time */
  contentType?: string;
  /** Byte size, if known at construction time */
  size?: number;
}

// Can be flexibly defined according to the use case.
//
// Examples:
// - USER_LIST: the users from a list stored in the database;
// - EMAIL_DOMAIN: the users whose email is in a specific domain;
// - GROUP_MEMBER: the users who are members of a specific group;
// - SUBSCRIBER: the users who are subscribers of a specific service / content
//   creator.
export enum ObjectAccessGroupType {}

export interface ObjectAccessGroup {
  type: ObjectAccessGroupType;
  // The logic id that identifies qualified group members. Format depends on the
  // ObjectAccessGroupType — e.g. a user-list DB id, an email domain, a group id.
  id: string;
}

export enum ObjectPermission {
  READ = 'read',
  WRITE = 'write',
}

export interface ObjectAclRule {
  group: ObjectAccessGroup;
  permission: ObjectPermission;
}

// Stored as Supabase object metadata under the key "aclPolicy" (JSON string).
// This mirrors the previous GCS custom:aclPolicy metadata field exactly.
export interface ObjectAclPolicy {
  owner: string;
  visibility: 'public' | 'private';
  aclRules?: Array<ObjectAclRule>;
}

function isPermissionAllowed(
  requested: ObjectPermission,
  granted: ObjectPermission,
): boolean {
  if (requested === ObjectPermission.READ) {
    return [ObjectPermission.READ, ObjectPermission.WRITE].includes(granted);
  }
  return granted === ObjectPermission.WRITE;
}

abstract class BaseObjectAccessGroup implements ObjectAccessGroup {
  constructor(
    public readonly type: ObjectAccessGroupType,
    public readonly id: string,
  ) {}

  public abstract hasMember(userId: string): Promise<boolean>;
}

function createObjectAccessGroup(
  group: ObjectAccessGroup,
): BaseObjectAccessGroup {
  switch (group.type) {
    // Implement per access group type, e.g.:
    // case "USER_LIST":
    //   return new UserListAccessGroup(group.id);
    default:
      throw new Error(`Unknown access group type: ${group.type}`);
  }
}

export async function setObjectAclPolicy(
  objectFile: StorageFile,
  aclPolicy: ObjectAclPolicy,
): Promise<void> {
  const supabase = getSupabaseStorageClient();
  const bucket = getStorageBucket();

  // Read the existing file bytes so we can update its metadata
  const { data, error: downloadErr } = await supabase.storage
    .from(bucket)
    .download(objectFile.objectPath);

  if (downloadErr || !data) {
    throw new Error(
      `Object not found or failed to read before setting ACL policy: ${objectFile.objectPath} (${downloadErr?.message})`,
    );
  }

  // Supabase Storage stores per-file metadata as a free-form object in the
  // metadata column of storage.objects. We write the ACL policy as a JSON
  // string under the key "aclPolicy" — exactly mirroring the GCS
  // "custom:aclPolicy" custom metadata field.
  const { error } = await supabase.storage
    .from(bucket)
    .update(objectFile.objectPath, data, {
      upsert: true,
      contentType: objectFile.contentType ?? data.type,
      metadata: {
        [ACL_POLICY_METADATA_KEY]: JSON.stringify(aclPolicy),
      },
    });

  if (error) {
    throw new Error(`Failed to set ACL policy on ${objectFile.objectPath}: ${error.message}`);
  }
}

export async function getObjectAclPolicy(
  objectFile: StorageFile,
): Promise<ObjectAclPolicy | null> {
  const supabase = getSupabaseStorageClient();
  const bucket = getStorageBucket();

  // info() is not exposed on the Supabase JS client; the cheapest way to read
  // file-level metadata is list() with a search filter. The metadata column
  // is returned in the FileObject.metadata field.
  const dir = objectFile.objectPath.includes('/')
    ? objectFile.objectPath.split('/').slice(0, -1).join('/')
    : '';
  const filename = objectFile.objectPath.split('/').pop() ?? objectFile.objectPath;

  const { data, error } = await supabase.storage
    .from(bucket)
    .list(dir, { search: filename });

  if (error) {
    throw new Error(
      `Failed to read ACL metadata for ${objectFile.objectPath}: ${error.message}`,
    );
  }

  const fileObj = data?.find((f) => f.name === filename);
  if (!fileObj) {
    return null;
  }

  // Supabase FileObject.metadata is typed as Record<string, unknown> | null.
  const rawPolicy = (fileObj.metadata as Record<string, unknown> | null)?.[ACL_POLICY_METADATA_KEY];
  if (!rawPolicy || typeof rawPolicy !== 'string') {
    return null;
  }

  try {
    return JSON.parse(rawPolicy) as ObjectAclPolicy;
  } catch {
    return null;
  }
}

export async function canAccessObject({
  userId,
  objectFile,
  requestedPermission,
}: {
  userId?: string;
  objectFile: StorageFile;
  requestedPermission: ObjectPermission;
}): Promise<boolean> {
  const aclPolicy = await getObjectAclPolicy(objectFile);
  if (!aclPolicy) {
    return false;
  }

  if (
    aclPolicy.visibility === 'public' &&
    requestedPermission === ObjectPermission.READ
  ) {
    return true;
  }

  if (!userId) {
    return false;
  }

  if (aclPolicy.owner === userId) {
    return true;
  }

  for (const rule of aclPolicy.aclRules || []) {
    const accessGroup = createObjectAccessGroup(rule.group);
    if (
      (await accessGroup.hasMember(userId)) &&
      isPermissionAllowed(requestedPermission, rule.permission)
    ) {
      return true;
    }
  }

  return false;
}

