import type { Logger } from "pino";
import { and, eq, sql } from "drizzle-orm";
import {
  db,
  generationsTable,
  usersTable,
  creditLedgerTable,
  featureAppsTable,
  type Model,
  type Generation,
} from "@workspace/db";
import { resolveGenerationKey } from "./keyRouting";
import { computeCreditsCharged } from "./pricing";
import { finalizeGeneration } from "./statusSync";
import { getAdapter } from "../media/registry";
import { ProviderError } from "../media/types";


export class PipelineError extends Error {
  constructor(
    public readonly statusCode: number,
    message: string,
  ) {
    super(message);
    this.name = "PipelineError";
  }
}

export interface ExecutePipelineOptions {
  userId: number;
  model: Model;
  prompt: string;
  params: Record<string, unknown>;
  useOwnKey?: boolean;
  featureAppId?: number | null;
  creditCost?: number;
  log: Logger;
}

export async function executeGenerationPipeline(
  opts: ExecutePipelineOptions,
): Promise<Generation> {
  const { userId, model, prompt, params, useOwnKey, featureAppId, creditCost, log } = opts;

  // 1. Resolve API key
  const { apiKey, usedOwnKey, rejected } = await resolveGenerationKey(userId, model, useOwnKey);
  if (rejected) {
    throw new PipelineError(403, rejected.reason);
  }
  if (!apiKey) {
    throw new PipelineError(500, "No API key available to submit this generation.");
  }

  const providerParams = { prompt, ...params };
  const adapter = getAdapter(model.adapter);

  // 2. If this is a feature app, run in a transaction with an advisory lock
  // to guarantee atomicity of the free-use check and generation row insertion.
  if (featureAppId) {
    return await db.transaction(async (tx) => {
      // Postgres advisory lock per user and feature app
      await tx.execute(sql`SELECT pg_advisory_xact_lock(${userId}, ${featureAppId})`);

      // Count non-failed generations for this user and feature app
      const [countRow] = await tx
        .select({ count: sql<number>`count(*)::int` })
        .from(generationsTable)
        .where(
          and(
            eq(generationsTable.userId, userId),
            eq(generationsTable.featureAppId, featureAppId),
            sql`${generationsTable.status} != 'failed'`,
          ),
        );
      const usedCount = countRow?.count ?? 0;

      const [app] = await tx
        .select()
        .from(featureAppsTable)
        .where(eq(featureAppsTable.id, featureAppId));
      if (!app) {
        throw new PipelineError(404, "Feature app not found");
      }

      const hasFreeUse = usedCount < app.freeUsesPerUser;
      // Charging: a free swap charges 0. A paid swap always charges feature app's credit_cost,
      // never model.creditCost.
      const creditsCharged = hasFreeUse ? 0 : (creditCost ?? app.creditCost ?? 0);

      // Check balance if credits are charged
      const [user] = await tx.select().from(usersTable).where(eq(usersTable.id, userId));
      if (!user) {
        throw new PipelineError(404, "User not found");
      }

      if (!usedOwnKey && creditsCharged > 0 && user.creditsBalance < creditsCharged) {
        throw new PipelineError(402, "Insufficient credits. Please purchase credits to continue.");
      }

      // Submit to provider
      let submitted: Awaited<ReturnType<typeof adapter.submit>>;
      try {
        submitted = await adapter.submit(model.providerModelPath, providerParams, apiKey, { executionConfig: model.executionConfig });
      } catch (err) {
        if (err instanceof ProviderError) {
          log.error(
            { adapter: model.adapter, modelId: model.modelId, kind: err.kind, providerMessage: err.providerMessage },
            "Provider submit failed",
          );
        } else {
          log.error({ err }, "Provider submit failed (unexpected error shape)");
        }
        throw new PipelineError(502, "Generation temporarily unavailable — please try again later.");
      }

      // Insert generation row
      const [generation] = await tx
        .insert(generationsTable)
        .values({
          userId,
          modelId: model.id,
          featureAppId,
          prompt,
          params: providerParams,
          status: "processing",
          outputType: model.category,
          outputUrls: [],
          creditsCharged,
          usedOwnKey,
          providerTaskId: submitted.kind === "async" ? submitted.providerTaskId : null,
        })
        .returning();

      // Deduct credits if applicable
      if (creditsCharged > 0) {
        const newBalance = user.creditsBalance - creditsCharged;
        await tx.update(usersTable).set({ creditsBalance: newBalance }).where(eq(usersTable.id, userId));
        await tx.insert(creditLedgerTable).values({
          userId,
          delta: -creditsCharged,
          reason: "generation",
          balanceAfter: newBalance,
          generationId: generation.id,
        });
      }

      if (submitted.kind === "completed") {
        return await finalizeGeneration(
          generation,
          { status: "completed", outputUrls: submitted.outputUrls },
          log,
        );
      }

      return generation;
    });
  }

  // 3. Standard model generation (no feature app)
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
  if (!user) {
    throw new PipelineError(404, "User not found");
  }

  const creditsCharged = computeCreditsCharged(usedOwnKey, model);
  if (!usedOwnKey && user.creditsBalance < creditsCharged) {
    throw new PipelineError(402, "Insufficient credits. Upgrade your plan or add your own API key.");
  }

  let submitted: Awaited<ReturnType<typeof adapter.submit>>;
  try {
    submitted = await adapter.submit(model.providerModelPath, providerParams, apiKey, { executionConfig: model.executionConfig });
  } catch (err) {
    if (err instanceof ProviderError) {
      log.error(
        { adapter: model.adapter, modelId: model.modelId, kind: err.kind, providerMessage: err.providerMessage },
        "Provider submit failed",
      );
    } else {
      log.error({ err }, "Provider submit failed (unexpected error shape)");
    }
    throw new PipelineError(502, "Generation temporarily unavailable — please try again later.");
  }

  const [generation] = await db
    .insert(generationsTable)
    .values({
      userId,
      modelId: model.id,
      prompt,
      params: providerParams,
      status: "processing",
      outputType: model.category,
      outputUrls: [],
      creditsCharged,
      usedOwnKey,
      providerTaskId: submitted.kind === "async" ? submitted.providerTaskId : null,
    })
    .returning();

  if (creditsCharged > 0) {
    const newBalance = user.creditsBalance - creditsCharged;
    await db.update(usersTable).set({ creditsBalance: newBalance }).where(eq(usersTable.id, userId));
    await db.insert(creditLedgerTable).values({
      userId,
      delta: -creditsCharged,
      reason: "generation",
      balanceAfter: newBalance,
      generationId: generation.id,
    });
  }

  if (submitted.kind === "completed") {
    return await finalizeGeneration(
      generation,
      { status: "completed", outputUrls: submitted.outputUrls },
      log,
    );
  }

  return generation;
}
