import app from "./app";
import { logger } from "./lib/logger";
import { startGenerationBackgroundPoller } from "./lib/generation/backgroundPoller";

const rawPort = process.env["API_PORT"] ?? process.env["PORT"] ?? "8080";

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid API_PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Warn loudly if Supabase Storage isn't configured so misconfiguration is
  // obvious in logs rather than silently failing at generation-complete time.
  // Fix: set SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, and SUPABASE_STORAGE_BUCKET
  // in your environment and restart the server.
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY || !process.env.SUPABASE_STORAGE_BUCKET) {
    logger.warn(
      "Object storage is NOT configured (SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / SUPABASE_STORAGE_BUCKET missing). " +
      "Generated assets will use temporary provider URLs and may expire. " +
      "Set all three environment variables and restart to fix.",
    );
  }

  // Runs inside this same long-lived process, independent of any browser
  // tab — see backgroundPoller.ts for why this exists.
  startGenerationBackgroundPoller(logger);
});
