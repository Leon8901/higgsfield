import {
  db,
  toolsTable,
  appsTable,
  pricingPlansTable,
  waitlistTable,
  usersTable,
  modelsTable,
  generationsTable,
  creditLedgerTable,
  userApiKeysTable,
  providersTable,
  creditPacksTable,
  avatarsTable,
  siteSettingsTable,
  settingsMetaTable,
  featureAppsTable,
} from "./src/index";
import { sql } from "drizzle-orm";

async function main() {
  const tables = [
    { name: "tools", table: toolsTable },
    { name: "apps", table: appsTable },
    { name: "pricing_plans", table: pricingPlansTable },
    { name: "waitlist", table: waitlistTable },
    { name: "users", table: usersTable },
    { name: "models", table: modelsTable },
    { name: "generations", table: generationsTable },
    { name: "credit_ledger", table: creditLedgerTable },
    { name: "user_api_keys", table: userApiKeysTable },
    { name: "providers", table: providersTable },
    { name: "credit_packs", table: creditPacksTable },
    { name: "avatars", table: avatarsTable },
    { name: "site_settings", table: siteSettingsTable },
    { name: "settings_meta", table: settingsMetaTable },
    { name: "feature_apps", table: featureAppsTable },
  ];

  console.log("=== Table Row Counts ===");
  for (const { name, table } of tables) {
    const [res] = await db.select({ count: sql<number>`count(*)::int` }).from(table);
    console.log(`- ${name}: ${res.count} rows`);
  }

  const [fa] = await db.select().from(featureAppsTable);
  console.log("\n=== Seeded Feature App (Face Swap) ===");
  console.log(JSON.stringify(fa, null, 2));

  const [sampleModel] = await db.select().from(modelsTable).limit(1);
  console.log("\n=== Sample Model Row Structure ===");
  console.log(JSON.stringify(sampleModel, null, 2));

  process.exit(0);
}

main().catch((err) => {
  console.error("Verification failed:", err);
  process.exit(1);
});
