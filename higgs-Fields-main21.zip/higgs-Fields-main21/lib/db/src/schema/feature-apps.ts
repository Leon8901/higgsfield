import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { modelsTable } from "./models";

export const featureAppsTable = pgTable("feature_apps", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  menuCategory: text("menu_category"), // "image" | "video" | "audio" | null
  menuDescription: text("menu_description").notNull(),
  iconKey: text("icon_key").notNull().default("Sparkles"),
  isActive: boolean("is_active").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  modelId: integer("model_id").references(() => modelsTable.id),
  promptTemplate: text("prompt_template").notNull(),
  freeUsesPerUser: integer("free_uses_per_user").notNull().default(0),
  creditCost: integer("credit_cost"), // null = not ready / unconfigured
  heroTitle: text("hero_title").notNull(),
  heroSubtitle: text("hero_subtitle").notNull(),
  slot1Key: text("slot1_key").notNull().default("target_image"),
  slot1Label: text("slot1_label").notNull(),
  slot1Help: text("slot1_help").notNull(),
  slot2Key: text("slot2_key").notNull().default("face_image"),
  slot2Label: text("slot2_label").notNull(),
  slot2Help: text("slot2_help").notNull(),
  showcaseImageUrl: text("showcase_image_url"),
  showcaseInsetUrl: text("showcase_inset_url"),
  imageInputMode: text("image_input_mode").notNull().default("array"), // "array" | "separate"
  imageFieldName: text("image_field_name").notNull().default("images"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertFeatureAppSchema = createInsertSchema(featureAppsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertFeatureApp = z.infer<typeof insertFeatureAppSchema>;
export type FeatureApp = typeof featureAppsTable.$inferSelect;
