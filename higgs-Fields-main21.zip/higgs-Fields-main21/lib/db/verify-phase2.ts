/**
 * Phase 2 — Catalog Sync Live Verification.
 * Tests live provider catalog fetching, normalization, and sync guardrails.
 */

import { db, providersTable, modelsTable } from "./src/index";
import { eq } from "drizzle-orm";
import { createDecipheriv, createHash } from "crypto";

function deriveKey(): Buffer {
  const secret = process.env.SESSION_SECRET;
  if (!secret) throw new Error("SESSION_SECRET must be set");
  return createHash("sha256").update(`byok-api-key-encryption:${secret}`).digest();
}

function decryptSecret(stored: string): string {
  const key = deriveKey();
  const [ivHex, authTagHex, ciphertextHex] = stored.split(":");
  if (!ivHex || !authTagHex || !ciphertextHex) throw new Error("Malformed encrypted secret");
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivHex, "hex"));
  decipher.setAuthTag(Buffer.from(authTagHex, "hex"));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertextHex, "hex")),
    decipher.final(),
  ]).toString("utf8");
}

async function main() {
  console.log("=== Step 1: Check Provider & Decrypt API Key ===");
  const [provider] = await db
    .select()
    .from(providersTable)
    .where(eq(providersTable.slug, "wavespeed"));

  if (!provider || !provider.encryptedPlatformKey) {
    throw new Error("WaveSpeed provider or encrypted key missing in database.");
  }

  const apiKey = decryptSecret(provider.encryptedPlatformKey);
  console.log("✓ Successfully decrypted WaveSpeed platform key (masked last4:", provider.platformKeyLastFour, ")");

  console.log("\n=== Step 2: Fetch Live Provider Catalog ===");
  const res = await fetch("https://api.wavespeed.ai/api/v3/models", {
    headers: { Authorization: `Bearer ${apiKey}` },
  });
  if (!res.ok) throw new Error(`Catalog fetch failed: HTTP ${res.status}`);
  const json: any = await res.json();
  const catalogList: any[] = json.data || [];
  console.log(`✓ Fetched ${catalogList.length} live models from WaveSpeed API`);

  const faceMatches = catalogList.filter((m) => (m.id + " " + (m.name || "")).toLowerCase().includes("swap") || (m.id + " " + (m.name || "")).toLowerCase().includes("face"));
  console.log(`Found ${faceMatches.length} models matching 'face' or 'swap':`);
  for (const m of faceMatches) {
    console.log(`  - id: "${m.id}", name: "${m.name}", price: $${m.base_price}`);
  }
  const faceSwap = faceMatches[0];
  if (faceSwap) {
    console.log("  Name:", faceSwap.name);
    console.log("  Base Price USD:", faceSwap.base_price);
    const props = faceSwap.api_schema?.api_schemas?.[0]?.request_schema?.properties || {};
    console.log("  Raw Properties:", Object.keys(props));
  }

  console.log("\n=== Step 3: Test Add from Catalog Invariants ===");
  const testPath = faceSwap?.id || "wavespeed-ai/image-face-swap";
  const testSlug = testPath.replace(/\//g, "-").toLowerCase();

  // Clean up any previous test row
  await db.delete(modelsTable).where(eq(modelsTable.modelId, testSlug));

  // Insert candidate with catalog defaults
  const [inserted] = await db
    .insert(modelsTable)
    .values({
      modelId: testSlug,
      name: faceSwap?.name || "Image Face Swap",
      category: "image",
      description: faceSwap?.description || "High fidelity face swap",
      adapter: "wavespeed",
      providerModelPath: testPath,
      basePriceUsd: faceSwap?.base_price ?? 0.05,
      creditCost: null, // Hard Rule 1: must be null on insert
      paramsSchema: {
        fields: [
          { key: "image", label: "Image", type: "image", required: true },
          { key: "face_image", label: "Face Image", type: "image", required: true }
        ]
      },
      rawSchema: faceSwap?.api_schema || null,
      providerBasePriceUsd: faceSwap?.base_price ?? 0.05,
      isSynced: true,
      isDelisted: false,
      isActive: false,  // Hard Rule: must be false on insert
      lastSyncedAt: new Date(),
      updatedAt: new Date(),
    })
    .returning();

  console.log("✓ Model inserted into DB:");
  console.log("  id:", inserted.id);
  console.log("  modelId:", inserted.modelId);
  console.log("  isActive (MUST BE FALSE):", inserted.isActive === false ? "PASS (false)" : "FAIL");
  console.log("  creditCost (MUST BE NULL):", inserted.creditCost === null ? "PASS (null)" : "FAIL");
  console.log("  isSynced (MUST BE TRUE):", inserted.isSynced === true ? "PASS (true)" : "FAIL");
  console.log("  isDelisted (MUST BE FALSE):", inserted.isDelisted === false ? "PASS (false)" : "FAIL");
  console.log("  providerBasePriceUsd:", inserted.providerBasePriceUsd);

  console.log("\n=== Step 4: Test Pending Schema Update Resolution ===");
  const mockPendingSchema = {
    fields: [
      { key: "image", label: "Image", type: "image" },
      { key: "face_image", label: "Face Image", type: "image" },
      { key: "target_gender", label: "Target Gender", type: "select" }
    ]
  };

  // Set pendingSchemaUpdate
  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: mockPendingSchema })
    .where(eq(modelsTable.id, inserted.id));

  const [withPending] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ pendingSchemaUpdate set:", withPending.pendingSchemaUpdate !== null ? "PASS" : "FAIL");

  // Test "approve" action: overwrites paramsSchema AND clears pendingSchemaUpdate to null
  await db
    .update(modelsTable)
    .set({
      paramsSchema: withPending.pendingSchemaUpdate as any,
      pendingSchemaUpdate: null,
      updatedAt: new Date(),
    })
    .where(eq(modelsTable.id, inserted.id));

  const [afterApprove] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ After 'approve':");
  console.log("  pendingSchemaUpdate (MUST BE NULL):", afterApprove.pendingSchemaUpdate === null ? "PASS (null)" : "FAIL");
  console.log("  paramsSchema updated:", (afterApprove.paramsSchema as any).fields.some((f: any) => f.key === "target_gender") ? "PASS" : "FAIL");

  // Test "dismiss" action: clears pendingSchemaUpdate to null without overwriting paramsSchema
  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: mockPendingSchema })
    .where(eq(modelsTable.id, inserted.id));

  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: null, updatedAt: new Date() })
    .where(eq(modelsTable.id, inserted.id));

  const [afterDismiss] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ After 'dismiss':");
  console.log("  pendingSchemaUpdate (MUST BE NULL):", afterDismiss.pendingSchemaUpdate === null ? "PASS (null)" : "FAIL");

  // Clean up test row so database returns to original state
  await db.delete(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ Cleaned up test model row from database");

  console.log("\n=== Step 5: Verification Complete ===");
  process.exit(0);
}

main().catch((err) => {
  console.error("Verification failed:", err);
  process.exit(1);
});
