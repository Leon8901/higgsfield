/**
 * Phase 2 — Catalog Sync Live Verification.
 * Tests live provider catalog fetching, normalization, and sync guardrails.
 */

import { db, providersTable, modelsTable, featureAppsTable } from "../lib/db/src/index.js";
import { eq, and } from "drizzle-orm";
import { decryptSecret } from "../artifacts/api-server/src/lib/crypto.js";
import { fetchProviderCatalog, catalogSlugify } from "../artifacts/api-server/src/lib/media/catalogSync.js";

async function main() {
  console.log("=== Step 1: Check Provider & Decrypt API Key ===");
  const [provider] = await db
    .select()
    .from(providersTable)
    .where(eq(providersTable.slug, "wavespeed"));

  if (!provider || !provider.encryptedPlatformKey) {
    throw new Error("WaveSpeed provider or encrypted key missing in database.");
  }

  const apiKey = decryptSecret(provider.encryptedPlatformKey);
  console.log("✓ Successfully decrypted WaveSpeed platform key (masked last4:", provider.platformKeyLastFour, ")");

  console.log("\n=== Step 2: Fetch Live Provider Catalog ===");
  const catalog = await fetchProviderCatalog("wavespeed", apiKey);
  console.log(`✓ Fetched ${catalog.length} live models from WaveSpeed API`);

  const faceSwap = catalog.find((m) => m.providerModelPath === "wavespeed-ai/image-face-swap");
  if (!faceSwap) {
    console.warn("⚠️ wavespeed-ai/image-face-swap not found in catalog, searching for related face models...");
    const related = catalog.filter((m) => m.providerModelPath.includes("face") || m.providerModelPath.includes("swap"));
    console.log("Found related:", related.map((r) => r.providerModelPath));
  } else {
    console.log("✓ Found 'wavespeed-ai/image-face-swap' in live catalog:");
    console.log("  Name:", faceSwap.name);
    console.log("  Category:", faceSwap.category);
    console.log("  Base Price USD:", faceSwap.providerBasePriceUsd);
    console.log("  Normalized Fields:", faceSwap.paramsSchema.fields.map((f) => `${f.key} (${f.type}${f.required ? ", required" : ""})`));
  }

  console.log("\n=== Step 3: Test Add from Catalog Invariants ===");
  // Pick a catalog model not currently in DB for a clean add test, or verify against the first model
  const testCandidate = catalog.find((m) => m.providerModelPath.includes("face-swap")) || catalog[0];
  console.log(`Selected candidate for invariant test: ${testCandidate.providerModelPath}`);

  const testSlug = catalogSlugify(testCandidate.providerModelPath);
  console.log(`Derived slug: ${testSlug}`);

  // Ensure test row doesn't conflict
  await db.delete(modelsTable).where(eq(modelsTable.modelId, testSlug));

  // Insert candidate with catalog defaults
  const [inserted] = await db
    .insert(modelsTable)
    .values({
      modelId: testSlug,
      name: testCandidate.name,
      category: testCandidate.category,
      description: testCandidate.description,
      adapter: "wavespeed",
      providerModelPath: testCandidate.providerModelPath,
      basePriceUsd: testCandidate.providerBasePriceUsd,
      creditCost: null, // Hard Rule: must be null on insert
      paramsSchema: testCandidate.paramsSchema,
      rawSchema: testCandidate.rawSchema as any,
      providerBasePriceUsd: testCandidate.providerBasePriceUsd,
      isSynced: true,
      isDelisted: false,
      isActive: false,  // Hard Rule: must be false on insert
      lastSyncedAt: new Date(),
      updatedAt: new Date(),
    })
    .returning();

  console.log("✓ Model inserted into DB:");
  console.log("  id:", inserted.id);
  console.log("  modelId:", inserted.modelId);
  console.log("  isActive (MUST BE FALSE):", inserted.isActive === false ? "PASS (false)" : "FAIL");
  console.log("  creditCost (MUST BE NULL):", inserted.creditCost === null ? "PASS (null)" : "FAIL");
  console.log("  isSynced (MUST BE TRUE):", inserted.isSynced === true ? "PASS (true)" : "FAIL");
  console.log("  isDelisted (MUST BE FALSE):", inserted.isDelisted === false ? "PASS (false)" : "FAIL");
  console.log("  providerBasePriceUsd:", inserted.providerBasePriceUsd);

  console.log("\n=== Step 4: Test Pending Schema Update Resolution ===");
  // Test pendingSchemaUpdate behavior: simulate an incoming schema update on a locked model
  const mockPendingSchema = {
    fields: [
      ...testCandidate.paramsSchema.fields,
      { key: "custom_test_param", label: "Custom Test Param", type: "text" as const }
    ]
  };

  // Set pendingSchemaUpdate
  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: mockPendingSchema })
    .where(eq(modelsTable.id, inserted.id));

  const [withPending] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ pendingSchemaUpdate set:", withPending.pendingSchemaUpdate !== null ? "PASS" : "FAIL");

  // Test "approve" action: should overwrite paramsSchema AND clear pendingSchemaUpdate to null
  await db
    .update(modelsTable)
    .set({
      paramsSchema: withPending.pendingSchemaUpdate as any,
      pendingSchemaUpdate: null,
      updatedAt: new Date(),
    })
    .where(eq(modelsTable.id, inserted.id));

  const [afterApprove] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ After 'approve':");
  console.log("  pendingSchemaUpdate (MUST BE NULL):", afterApprove.pendingSchemaUpdate === null ? "PASS (null)" : "FAIL");
  console.log("  paramsSchema updated with new field:", (afterApprove.paramsSchema as any).fields.some((f: any) => f.key === "custom_test_param") ? "PASS" : "FAIL");

  // Test "dismiss" action: simulate another pending schema and dismiss it
  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: mockPendingSchema })
    .where(eq(modelsTable.id, inserted.id));

  await db
    .update(modelsTable)
    .set({ pendingSchemaUpdate: null, updatedAt: new Date() })
    .where(eq(modelsTable.id, inserted.id));

  const [afterDismiss] = await db.select().from(modelsTable).where(eq(modelsTable.id, inserted.id));
  console.log("✓ After 'dismiss':");
  console.log("  pendingSchemaUpdate (MUST BE NULL):", afterDismiss.pendingSchemaUpdate === null ? "PASS (null)" : "FAIL");

  console.log("\n=== Step 5: Verification Complete ===");
  process.exit(0);
}

main().catch((err) => {
  console.error("Verification failed:", err);
  process.exit(1);
});
