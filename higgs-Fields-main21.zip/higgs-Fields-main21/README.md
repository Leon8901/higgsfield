﻿# Higgsfield AI Studio

Higgsfield AI video & image creation platform with multi-provider model routing, Supabase object storage, Clerk authentication, and Drizzle ORM.

---

## Quick Start (Local Development)

### 1. Configure Environment

Copy the example environment file and fill in your credentials:

```bash
cp .env.example .env
```

*(On Windows PowerShell: `Copy-Item .env.example .env`)*

Fill in your database, Supabase, Clerk, and AI provider credentials in `.env`.

### 2. Start Everything with One Command

Run from the repository root:

```bash
pnpm dev
```

This single command:
- Automatically loads your `.env` configuration via `dotenv-cli`.
- Starts the Express API backend (`[API]`) on port **8080** (or your configured `API_PORT`).
- Starts the Vite React frontend (`[WEB]`) on port **25131** (or your configured `VITE_PORT`).
- Color-codes and labels logs in a single terminal.
- Automatically proxies frontend `/api` requests to the backend server.

Open **http://localhost:25131** in your browser to use the application.

---

## Environment Variables Reference

| Variable | Default | Purpose |
|---|---|---|
| `API_PORT` | `8080` | Express API server port |
| `VITE_PORT` | `25131` | Vite React frontend port |
| `BASE_PATH` | `/` | Web application base URL path |
| `DATABASE_URL` | — | PostgreSQL connection string (Supabase / Postgres) |
| `SUPABASE_URL` | — | Supabase project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | — | Supabase service-role secret key (server-side only) |
| `SUPABASE_STORAGE_BUCKET` | `generations` | Supabase storage bucket name for generated assets |
| `CLERK_SECRET_KEY` | — | Clerk authentication server secret key |
| `CLERK_PUBLISHABLE_KEY` | — | Clerk publishable key |
| `VITE_CLERK_PUBLISHABLE_KEY` | — | Clerk client-side publishable key |
| `WAVESPEED_API_KEY` | — | WaveSpeed AI generation API key |
| `OPENROUTER_API_KEY` | — | OpenRouter LLM API key |
| `SESSION_SECRET` | — | Express session encryption secret |
| `RAZORPAY_KEY_ID` | — | (Optional) Razorpay billing key ID |
| `RAZORPAY_KEY_SECRET` | — | (Optional) Razorpay billing secret |

---

## Manual Multi-Terminal Startup (Fallback)

If you need processes separated into distinct terminal windows (e.g. for attaching a debugger to the API server or isolated inspection):

### Terminal 1 — API Backend
```bash
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/api-server run start
```

### Terminal 2 — React Frontend
```bash
pnpm --filter @workspace/higgsfield dev
```

---

## Useful Commands

| Task | Command |
|---|---|
| Start Full Dev Stack | `pnpm dev` |
| Typecheck All Packages | `pnpm run typecheck` |
| Build All Packages | `pnpm run build` |
| Component Preview Sandbox | `pnpm --filter @workspace/mockup-sandbox dev` |
